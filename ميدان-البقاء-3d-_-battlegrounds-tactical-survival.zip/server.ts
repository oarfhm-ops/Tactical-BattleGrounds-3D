import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocket, WebSocketServer } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

type NetworkMode = 'online' | 'local' | 'offline';

interface PlayerVoiceState {
  id: string;
  name: string;
  networkMode: NetworkMode;
  roomKey: string;
  roomCode: string;
  hostingRoom: boolean;
  inMatch: boolean;
  joinedAt: number;
  mapId: string;
  mode: string;
  teamId: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  stance: 'stand' | 'crouch' | 'prone';
  weaponId: string;
  health: number;
  voiceChannel: 'all' | 'team' | 'off';
  speaking: boolean;
  alive: boolean;
}

interface DiscoveredLocalRoom {
  roomCode: string;
  hostName: string;
  mapId: string;
  mode: string;
  playerCount: number;
  inMatch: boolean;
  players: string[];
  createdAt: number;
}

interface ClientConn {
  ws: WebSocket;
  state: PlayerVoiceState;
}

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  const clients = new Map<string, ClientConn>();
  let idCounter = 1;

  function getOpenLocalRooms(searchQuery = ''): DiscoveredLocalRoom[] {
    const groups = new Map<
      string,
      {
        roomCode: string;
        members: PlayerVoiceState[];
      }
    >();

    for (const conn of clients.values()) {
      const st = conn.state;
      if (st.networkMode !== 'local') continue;
      const code = st.roomCode || st.roomKey.replace(/^local:/, '');
      if (!code) continue;
      let grp = groups.get(code);
      if (!grp) {
        grp = { roomCode: code, members: [] };
        groups.set(code, grp);
      }
      grp.members.push(st);
    }

    const q = searchQuery.trim().toLowerCase();
    const result: DiscoveredLocalRoom[] = [];
    for (const grp of groups.values()) {
      // Only advertise genuine open/hosted or active-match rooms (no ghost searchers)
      const isAdvertised = grp.members.some((m) => m.hostingRoom || m.inMatch);
      if (!isAdvertised) continue;

      const sorted = [...grp.members].sort((a, b) => a.joinedAt - b.joinedAt);
      const host = sorted.find((m) => m.hostingRoom) ?? sorted[0];
      const players = sorted.map((m) => m.name);
      const inMatch = sorted.some((m) => m.inMatch);

      if (q) {
        const matchesCode = grp.roomCode.toLowerCase().includes(q);
        const matchesHost = host.name.toLowerCase().includes(q);
        const matchesPlayer = players.some((p) => p.toLowerCase().includes(q));
        if (!matchesCode && !matchesHost && !matchesPlayer) continue;
      }

      result.push({
        roomCode: grp.roomCode,
        hostName: host.name,
        mapId: host.mapId,
        mode: host.mode,
        playerCount: sorted.length,
        inMatch,
        players,
        createdAt: sorted[0].joinedAt,
      });
    }

    result.sort((a, b) => b.createdAt - a.createdAt);
    return result;
  }

  function broadcastLocalRoomsUpdate() {
    const payload = JSON.stringify({
      type: 'local-rooms:update',
      rooms: getOpenLocalRooms(),
    });
    for (const conn of clients.values()) {
      if (conn.ws.readyState === WebSocket.OPEN) {
        conn.ws.send(payload);
      }
    }
  }

  function broadcastToRoom(roomKey: string, payload: unknown, excludeId?: string) {
    if (!roomKey || roomKey.startsWith('offline:')) return;
    const raw = JSON.stringify(payload);
    for (const [cid, client] of clients.entries()) {
      if (cid === excludeId) continue;
      if (client.state.roomKey === roomKey && client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(raw);
      }
    }
  }

  wss.on('connection', (ws) => {
    const clientId = `p_${Date.now().toString(36)}_${idCounter++}`;
    const initialState: PlayerVoiceState = {
      id: clientId,
      name: `مقاتل ${idCounter}`,
      networkMode: 'offline',
      roomKey: `offline:${clientId}`,
      roomCode: '',
      hostingRoom: false,
      inMatch: false,
      joinedAt: Date.now(),
      mapId: 'classic',
      mode: 'solo',
      teamId: idCounter,
      x: 0,
      y: 0,
      z: 0,
      yaw: 0,
      stance: 'stand',
      weaponId: '',
      health: 100,
      voiceChannel: 'all',
      speaking: false,
      alive: true,
    };

    clients.set(clientId, { ws, state: initialState });

    ws.send(
      JSON.stringify({
        type: 'welcome',
        id: clientId,
        peers: [],
        localRooms: getOpenLocalRooms(),
      }),
    );

    ws.on('message', (data) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(String(data));
      } catch {
        return;
      }

      const conn = clients.get(clientId);
      if (!conn) return;

      if (msg.type === 'join') {
        const prevRoom = conn.state.roomKey;
        const prevMode = conn.state.networkMode;
        const prevHost = conn.state.hostingRoom;
        const prevMatch = conn.state.inMatch;

        if (typeof msg.name === 'string' && msg.name.trim()) {
          conn.state.name = msg.name.trim().slice(0, 24);
        }
        if (typeof msg.mapId === 'string') conn.state.mapId = msg.mapId;
        if (typeof msg.mode === 'string') conn.state.mode = msg.mode;
        if (typeof msg.teamId === 'number') conn.state.teamId = msg.teamId;
        if (typeof msg.hostingRoom === 'boolean') conn.state.hostingRoom = msg.hostingRoom;
        if (typeof msg.inMatch === 'boolean') conn.state.inMatch = msg.inMatch;
        if (msg.voiceChannel === 'all' || msg.voiceChannel === 'team' || msg.voiceChannel === 'off') {
          conn.state.voiceChannel = msg.voiceChannel;
        }
        const netMode: NetworkMode =
          msg.networkMode === 'online' || msg.networkMode === 'local' ? msg.networkMode : 'offline';
        conn.state.networkMode = netMode;

        const cleanCode =
          typeof msg.roomCode === 'string'
            ? msg.roomCode.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 12)
            : '';

        if (netMode === 'online') {
          conn.state.roomCode = '';
          conn.state.roomKey = `online:${conn.state.mapId}:${conn.state.mode}`;
        } else if (netMode === 'local') {
          const finalCode = cleanCode || 'LAN1';
          conn.state.roomCode = finalCode;
          conn.state.roomKey = `local:${finalCode}`;
        } else {
          conn.state.roomCode = '';
          conn.state.hostingRoom = false;
          conn.state.inMatch = false;
          conn.state.roomKey = `offline:${clientId}`;
        }

        if (prevRoom && prevRoom !== conn.state.roomKey) {
          broadcastToRoom(prevRoom, { type: 'peer:left', id: clientId }, clientId);
        }

        const peers =
          netMode === 'offline'
            ? []
            : Array.from(clients.values())
                .filter((c) => c.state.id !== clientId && c.state.roomKey === conn.state.roomKey)
                .map((c) => c.state);

        ws.send(JSON.stringify({ type: 'peers:sync', peers, roomKey: conn.state.roomKey }));

        if (netMode !== 'offline') {
          broadcastToRoom(
            conn.state.roomKey,
            { type: 'peer:joined', peer: conn.state },
            clientId,
          );
        }

        if (
          prevMode === 'local' ||
          netMode === 'local' ||
          prevHost !== conn.state.hostingRoom ||
          prevMatch !== conn.state.inMatch
        ) {
          broadcastLocalRoomsUpdate();
        }
      } else if (msg.type === 'local-rooms:list') {
        const q = typeof msg.query === 'string' ? msg.query : '';
        ws.send(JSON.stringify({ type: 'local-rooms:update', rooms: getOpenLocalRooms(q) }));
      } else if (msg.type === 'state') {
        if (typeof msg.x === 'number') conn.state.x = msg.x;
        if (typeof msg.y === 'number') conn.state.y = msg.y;
        if (typeof msg.z === 'number') conn.state.z = msg.z;
        if (typeof msg.yaw === 'number') conn.state.yaw = msg.yaw;
        if (msg.stance === 'stand' || msg.stance === 'crouch' || msg.stance === 'prone') {
          conn.state.stance = msg.stance;
        }
        if (typeof msg.weaponId === 'string') conn.state.weaponId = msg.weaponId.slice(0, 24);
        if (typeof msg.health === 'number') conn.state.health = msg.health;
        if (typeof msg.speaking === 'boolean') conn.state.speaking = msg.speaking;
        if (typeof msg.alive === 'boolean') conn.state.alive = msg.alive;
        if (msg.voiceChannel === 'all' || msg.voiceChannel === 'team' || msg.voiceChannel === 'off') {
          conn.state.voiceChannel = msg.voiceChannel;
        }
        broadcastToRoom(
          conn.state.roomKey,
          { type: 'peer:state', peer: conn.state },
          clientId,
        );
      } else if (msg.type === 'combat:shoot') {
        if (conn.state.networkMode === 'offline') return;
        broadcastToRoom(
          conn.state.roomKey,
          {
            type: 'combat:shoot',
            fromId: clientId,
            fromName: conn.state.name,
            teamId: conn.state.teamId,
            origin: msg.origin,
            dir: msg.dir,
            weaponId: msg.weaponId,
          },
          clientId,
        );
      } else if (msg.type === 'combat:hit') {
        if (conn.state.networkMode === 'offline') return;
        const targetId = typeof msg.targetId === 'string' ? msg.targetId : '';
        const target = clients.get(targetId);
        if (
          target &&
          target.ws.readyState === WebSocket.OPEN &&
          target.state.roomKey === conn.state.roomKey
        ) {
          target.ws.send(
            JSON.stringify({
              type: 'combat:hit',
              fromId: clientId,
              fromName: conn.state.name,
              damage: Number(msg.damage ?? 20),
              weaponName: String(msg.weaponName ?? 'سلاح'),
              isHeadshot: Boolean(msg.isHeadshot),
            }),
          );
        }
      } else if (
        msg.type === 'rtc:offer' ||
        msg.type === 'rtc:answer' ||
        msg.type === 'rtc:ice'
      ) {
        const targetId = typeof msg.targetId === 'string' ? msg.targetId : '';
        const target = clients.get(targetId);
        if (
          target &&
          target.ws.readyState === WebSocket.OPEN &&
          target.state.roomKey === conn.state.roomKey
        ) {
          target.ws.send(
            JSON.stringify({
              ...msg,
              fromId: clientId,
            }),
          );
        }
      } else if (msg.type === 'voice:chunk') {
        const maxProximity = 48;
        const sender = conn.state;
        if (sender.networkMode === 'offline' || sender.voiceChannel === 'off' || !sender.alive) return;

        for (const [cid, target] of clients.entries()) {
          if (cid === clientId || target.ws.readyState !== WebSocket.OPEN) continue;
          if (target.state.roomKey !== sender.roomKey) continue;
          if (target.state.voiceChannel === 'off') continue;

          const sameTeam = sender.teamId === target.state.teamId && sender.mode !== 'solo';
          if ((sender.voiceChannel === 'team' || target.state.voiceChannel === 'team') && !sameTeam) {
            continue;
          }

          const dist = Math.hypot(
            sender.x - target.state.x,
            sender.y - target.state.y,
            sender.z - target.state.z,
          );
          if (!sameTeam && dist > maxProximity) continue;

          target.ws.send(
            JSON.stringify({
              type: 'voice:chunk',
              fromId: clientId,
              dist,
              sameTeam,
              pcm: msg.pcm,
              sampleRate: msg.sampleRate,
            }),
          );
        }
      }
    });

    ws.on('close', () => {
      const conn = clients.get(clientId);
      if (conn) {
        const wasLocal = conn.state.networkMode === 'local';
        clients.delete(clientId);
        broadcastToRoom(conn.state.roomKey, { type: 'peer:left', id: clientId }, clientId);
        if (wasLocal) {
          broadcastLocalRoomsUpdate();
        }
      }
    });
  });

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, connectedPlayers: clients.size });
  });

  app.get('/api/rooms', (_req, res) => {
    const onlineCount = Array.from(clients.values()).filter((c) => c.state.networkMode === 'online').length;
    const localCount = Array.from(clients.values()).filter((c) => c.state.networkMode === 'local').length;
    res.json({
      totalConnected: clients.size,
      onlineCount,
      localCount,
    });
  });

  app.get('/api/local-rooms', (req, res) => {
    const q = typeof req.query.q === 'string' ? req.query.q : '';
    const rooms = getOpenLocalRooms(q);
    res.json({
      rooms,
      totalConnected: clients.size,
      serverTime: Date.now(),
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const PORT = 3000;
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
