import type { AudioQuality, WeaponCategory } from './types';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private engineOsc: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  public muted = false;
  public quality: AudioQuality = 'ultra';

  private ensureContext(): AudioContext | null {
    if (this.muted) return null;
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.55;
      this.masterGain.connect(this.ctx.destination);
      this.createNoiseBuffer();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private createNoiseBuffer() {
    if (!this.ctx) return;
    const sampleRate = this.ctx.sampleRate;
    const length = sampleRate * 1.5;
    const buffer = this.ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    this.noiseBuffer = buffer;
  }

  public unlock() {
    this.ensureContext();
  }

  public setMuted(m: boolean) {
    this.muted = m;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(m ? 0 : 0.55, this.ctx.currentTime, 0.03);
    }
    if (m) {
      this.stopEngine();
    }
  }

  public playShot(category: WeaponCategory, suppressed: boolean, distance = 0) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || !this.noiseBuffer) return;

    const maxDist = suppressed ? 75 : 220;
    if (distance > maxDist) return;
    const distAtten = distance <= 1 ? 1 : Math.max(0.03, Math.pow(1 - distance / maxDist, 1.8));
    if (this.quality === 'low' && distance > 90) return;

    const now = ctx.currentTime;

    // Crossbow twang
    if (category === 'crossbow') {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(95, now + 0.11);
      g.gain.setValueAtTime(0.28 * distAtten, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      osc.connect(g).connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.13);
      return;
    }

    // Gunpowder transient noise burst
    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = suppressed ? 'lowpass' : 'bandpass';

    let dur = 0.14;
    let baseFreq = 1400;
    let vol = 0.42;

    if (category === 'sniper') {
      dur = 0.34;
      baseFreq = suppressed ? 520 : 1050;
      vol = 0.7;
    } else if (category === 'shotgun') {
      dur = 0.28;
      baseFreq = 880;
      vol = 0.65;
    } else if (category === 'lmg') {
      dur = 0.17;
      baseFreq = 1250;
      vol = 0.48;
    } else if (category === 'smg' || category === 'pistol') {
      dur = 0.1;
      baseFreq = suppressed ? 650 : 1850;
      vol = 0.32;
    } else if (category === 'dmr') {
      dur = 0.22;
      baseFreq = suppressed ? 560 : 1300;
      vol = 0.52;
    }

    if (suppressed) {
      vol *= 0.48;
      dur *= 0.65;
    }

    filter.frequency.setValueAtTime(baseFreq, now);
    filter.frequency.exponentialRampToValueAtTime(suppressed ? 240 : 320, now + dur);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(vol * distAtten, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);

    noise.connect(filter).connect(gain).connect(this.masterGain);
    noise.start(now);
    noise.stop(now + dur);

    // Low punch oscillator
    const punch = ctx.createOscillator();
    const pGain = ctx.createGain();
    punch.type = suppressed ? 'sine' : 'sawtooth';
    const startHz = category === 'sniper' || category === 'shotgun' ? 170 : 210;
    punch.frequency.setValueAtTime(startHz, now);
    punch.frequency.exponentialRampToValueAtTime(42, now + 0.09);
    pGain.gain.setValueAtTime((suppressed ? 0.14 : 0.3) * distAtten, now);
    pGain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    punch.connect(pGain).connect(this.masterGain);
    punch.start(now);
    punch.stop(now + 0.1);
  }

  public playPanClang() {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    const now = ctx.currentTime;
    const freqs = [780, 1190, 1840];
    freqs.forEach((f, idx) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = idx === 0 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(f, now);
      osc.frequency.exponentialRampToValueAtTime(f * 0.94, now + 0.35);
      g.gain.setValueAtTime(0.22 / (idx + 1), now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.connect(g).connect(this.masterGain!);
      osc.start(now);
      osc.stop(now + 0.36);
    });
  }

  public playHitmarker(headshot: boolean) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(headshot ? 1450 : 920, now);
    osc.frequency.exponentialRampToValueAtTime(headshot ? 2100 : 620, now + 0.06);
    g.gain.setValueAtTime(headshot ? 0.28 : 0.18, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
    osc.connect(g).connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.075);
  }

  public playReload() {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    const now = ctx.currentTime;
    [0, 0.25].forEach((offset, i) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(i === 0 ? 480 : 720, now + offset);
      osc.frequency.exponentialRampToValueAtTime(220, now + offset + 0.04);
      g.gain.setValueAtTime(0.11, now + offset);
      g.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.05);
      osc.connect(g).connect(this.masterGain!);
      osc.start(now + offset);
      osc.stop(now + offset + 0.055);
    });
  }

  public playPickup() {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(860, now + 0.07);
    g.gain.setValueAtTime(0.14, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    osc.connect(g).connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.085);
  }

  public playFootstep(isSprint: boolean) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || !this.noiseBuffer) return;
    const now = ctx.currentTime;
    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = isSprint ? 460 : 320;
    const g = ctx.createGain();
    g.gain.setValueAtTime(isSprint ? 0.12 : 0.07, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
    noise.connect(filter).connect(g).connect(this.masterGain);
    noise.start(now);
    noise.stop(now + 0.08);
  }

  public playExplosion(distance = 0) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || !this.noiseBuffer) return;
    const maxDist = 260;
    if (distance > maxDist) return;
    const atten = Math.max(0.05, Math.pow(1 - distance / maxDist, 1.5));
    const now = ctx.currentTime;

    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(620, now);
    filter.frequency.exponentialRampToValueAtTime(70, now + 0.9);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.75 * atten, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 1.0);
    noise.connect(filter).connect(g).connect(this.masterGain);
    noise.start(now);
    noise.stop(now + 1.05);

    const sub = ctx.createOscillator();
    const sG = ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(95, now);
    sub.frequency.exponentialRampToValueAtTime(24, now + 0.55);
    sG.gain.setValueAtTime(0.6 * atten, now);
    sG.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    sub.connect(sG).connect(this.masterGain);
    sub.start(now);
    sub.stop(now + 0.62);
  }

  public playSmokeHiss() {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || !this.noiseBuffer) return;
    const now = ctx.currentTime;
    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 1800;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.18, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 1.1);
    noise.connect(filter).connect(g).connect(this.masterGain);
    noise.start(now);
    noise.stop(now + 1.15);
  }

  public updateEngine(active: boolean, speedRatio: number) {
    if (!active || this.muted) {
      this.stopEngine();
      return;
    }
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    if (!this.engineOsc || !this.engineGain) {
      this.engineOsc = ctx.createOscillator();
      this.engineGain = ctx.createGain();
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 280;
      this.engineOsc.type = 'sawtooth';
      this.engineOsc.frequency.value = 48;
      this.engineGain.gain.value = 0.08;
      this.engineOsc.connect(filter).connect(this.engineGain).connect(this.masterGain);
      this.engineOsc.start();
    }
    const targetHz = 46 + Math.min(1.5, Math.abs(speedRatio)) * 78;
    this.engineOsc.frequency.setTargetAtTime(targetHz, ctx.currentTime, 0.08);
    this.engineGain.gain.setTargetAtTime(0.08 + Math.min(1, Math.abs(speedRatio)) * 0.06, ctx.currentTime, 0.08);
  }

  public stopEngine() {
    if (this.engineOsc) {
      try {
        this.engineOsc.stop();
        this.engineOsc.disconnect();
      } catch {
        // ignore
      }
      this.engineOsc = null;
    }
    if (this.engineGain) {
      this.engineGain.disconnect();
      this.engineGain = null;
    }
  }

  public playVictoryFanfare() {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    const notes = [523.25, 659.25, 783.99, 1046.5];
    const now = ctx.currentTime;
    notes.forEach((n, idx) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(n, now + idx * 0.13);
      g.gain.setValueAtTime(0.24, now + idx * 0.13);
      g.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.13 + 0.55);
      osc.connect(g).connect(this.masterGain!);
      osc.start(now + idx * 0.13);
      osc.stop(now + idx * 0.13 + 0.6);
    });
  }
}

export const soundEngine = new SoundEngine();
