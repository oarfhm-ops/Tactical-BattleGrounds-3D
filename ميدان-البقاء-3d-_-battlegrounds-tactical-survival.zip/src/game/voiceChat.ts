import type {
  DiscoveredLocalRoom,
  MicMode,
  MicPermission,
  NetworkMode,
  RemotePeerState,
  StanceMode,
  VoiceChannel,
} from './types';

interface PeerAudioPipeline {
  pc: RTCPeerConnection;
  panner: PannerNode;
  gain: GainNode;
  source: MediaStreamAudioSourceNode | null;
  hiddenAudio: HTMLAudioElement;
  iceConnected: boolean;
}

const MAX_PROXIMITY_METERS = 48;

export class ProximityVoiceManager {
  private ws: WebSocket | null = null;
  private reconnectTimer = 0;
  private disposed = false;

  public selfId = '';
  public selfName = 'مقاتل';
  public networkMode: NetworkMode = 'offline';
  public roomCode = 'ROOM1';
  public hostingRoom = false;
  public inMatch = false;
  public mapId = 'classic';
  public mode = 'solo';
  public teamId = 0;
  public localRooms: DiscoveredLocalRoom[] = [];

  public onRemoteShoot:
    | ((ev: {
        fromId: string;
        fromName: string;
        teamId: number;
        origin: { x: number; y: number; z: number };
        dir: { x: number; y: number; z: number };
        weaponId: string;
      }) => void)
    | null = null;
  public onRemoteHit:
    | ((ev: {
        fromId: string;
        fromName: string;
        damage: number;
        weaponName: string;
        isHeadshot: boolean;
      }) => void)
    | null = null;
  public onPeersChanged: (() => void) | null = null;
  public onLocalRoomsChanged: ((rooms: DiscoveredLocalRoom[]) => void) | null = null;

  public channel: VoiceChannel = 'all';
  public micMode: MicMode = 'ptt';
  public micPermission: MicPermission = 'idle';
  public isPttHeld = false;
  public testLoopback = false;

  private audioCtx: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  private micAnalyser: AnalyserNode | null = null;
  private micData = new Uint8Array(128);
  private loopbackGain: GainNode | null = null;
  private wsProcessor: ScriptProcessorNode | null = null;

  public micLevel = 0;
  public isSpeaking = false;

  public peers = new Map<string, RemotePeerState>();
  private peerAudio = new Map<string, PeerAudioPipeline>();

  private selfPos: {
    x: number;
    y: number;
    z: number;
    yaw: number;
    alive: boolean;
    stance: StanceMode;
    weaponId: string;
    health: number;
  } = { x: 0, y: 0, z: 0, yaw: 0, alive: true, stance: 'stand', weaponId: '', health: 100 };
  private lastStateSend = 0;
  private wsChunkSeq = 0;

  constructor() {
    this.connectWs();
  }

  private connectWs() {
    if (this.disposed || typeof window === 'undefined') return;
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${proto}//${window.location.host}/ws`;

    try {
      const ws = new WebSocket(url);
      this.ws = ws;

      ws.onopen = () => {
        this.sendJoin();
      };

      ws.onmessage = (ev) => {
        try {
          const msg = JSON.parse(String(ev.data));
          this.handleServerMessage(msg);
        } catch {
          // ignore malformed packet
        }
      };

      ws.onclose = () => {
        this.ws = null;
        if (!this.disposed) {
          this.reconnectTimer = window.setTimeout(() => this.connectWs(), 2000);
        }
      };

      ws.onerror = () => {
        ws.close();
      };
    } catch {
      this.reconnectTimer = window.setTimeout(() => this.connectWs(), 2500);
    }
  }

  private ensureAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return null;
      this.audioCtx = new Ctx();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }
    return this.audioCtx;
  }

  public async enableMic(): Promise<boolean> {
    if (this.micStream) {
      this.ensureAudioContext();
      return true;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      this.micPermission = 'denied';
      return false;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      this.micStream = stream;
      this.micPermission = 'granted';

      const ctx = this.ensureAudioContext();
      if (ctx) {
        this.micSource = ctx.createMediaStreamSource(stream);
        this.micAnalyser = ctx.createAnalyser();
        this.micAnalyser.fftSize = 256;
        this.micData = new Uint8Array(this.micAnalyser.frequencyBinCount);
        this.micSource.connect(this.micAnalyser);

        // Optional local test loopback
        this.loopbackGain = ctx.createGain();
        this.loopbackGain.gain.value = this.testLoopback ? 0.55 : 0;
        this.micSource.connect(this.loopbackGain).connect(ctx.destination);

        // WebSocket fallback audio streamer for peers where WebRTC ICE is restricted
        const proc = ctx.createScriptProcessor(2048, 1, 1);
        const silentSink = ctx.createGain();
        silentSink.gain.value = 0;
        proc.onaudioprocess = (e) => {
          this.handleMicAudioFrame(e.inputBuffer.getChannelData(0), ctx.sampleRate);
        };
        this.micSource.connect(proc);
        proc.connect(silentSink);
        silentSink.connect(ctx.destination);
        this.wsProcessor = proc;
      }

      // Attach mic track to existing WebRTC peer connections
      for (const [peerId, pipe] of this.peerAudio.entries()) {
        const track = stream.getAudioTracks()[0];
        if (track) {
          const senders = pipe.pc.getSenders();
          if (!senders.some((s) => s.track === track)) {
            pipe.pc.addTrack(track, stream);
            this.negotiateOffer(peerId, pipe.pc);
          }
        }
      }
      return true;
    } catch {
      this.micPermission = 'denied';
      return false;
    }
  }

  private handleMicAudioFrame(samples: Float32Array, sampleRate: number) {
    if (!this.isMicTransmitting() || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    if (this.peers.size === 0) return;

    // Only send fallback WS frames if at least one peer has not completed WebRTC ICE
    let needsWsRelay = false;
    for (const pid of this.peers.keys()) {
      const pipe = this.peerAudio.get(pid);
      if (!pipe || !pipe.iceConnected) {
        needsWsRelay = true;
        break;
      }
    }
    if (!needsWsRelay) return;

    // Downsample 2:1 and quantize to 8-bit mu-ish PCM base64 to keep WS bandwidth tiny
    this.wsChunkSeq++;
    const step = 3;
    const len = Math.floor(samples.length / step);
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      const v = Math.max(-1, Math.min(1, samples[i * step]));
      bytes[i] = Math.round((v + 1) * 127.5);
    }
    let bin = '';
    for (let i = 0; i < bytes.length; i++) {
      bin += String.fromCharCode(bytes[i]);
    }
    const b64 = btoa(bin);
    this.ws.send(
      JSON.stringify({
        type: 'voice:chunk',
        seq: this.wsChunkSeq,
        sampleRate: Math.round(sampleRate / step),
        pcm: b64,
      }),
    );
  }

  public isMicTransmitting(): boolean {
    if (this.channel === 'off' || !this.selfPos.alive) return false;
    if (this.micPermission !== 'granted') return false;
    if (this.micMode === 'ptt') return this.isPttHeld || this.testLoopback;
    return true;
  }

  public setChannel(ch: VoiceChannel) {
    this.channel = ch;
    this.syncTrackEnabled();
    this.sendStateImmediate();
  }

  public cycleChannel(): VoiceChannel {
    const order: VoiceChannel[] = ['all', 'team', 'off'];
    const next = order[(order.indexOf(this.channel) + 1) % order.length];
    this.setChannel(next);
    return next;
  }

  public setMicMode(mode: MicMode) {
    this.micMode = mode;
    if (mode === 'open' && this.micPermission === 'idle') {
      void this.enableMic();
    }
    this.syncTrackEnabled();
  }

  public setPttHeld(held: boolean) {
    if (held && this.micPermission === 'idle') {
      void this.enableMic();
    }
    this.isPttHeld = held;
    this.syncTrackEnabled();
  }

  public toggleTestLoopback() {
    if (!this.testLoopback && this.micPermission === 'idle') {
      void this.enableMic();
    }
    this.testLoopback = !this.testLoopback;
    if (this.loopbackGain && this.audioCtx) {
      this.loopbackGain.gain.setTargetAtTime(
        this.testLoopback ? 0.55 : 0,
        this.audioCtx.currentTime,
        0.04,
      );
    }
  }

  private syncTrackEnabled() {
    if (!this.micStream) return;
    const active = this.isMicTransmitting();
    this.micStream.getAudioTracks().forEach((t) => {
      t.enabled = active;
    });
  }

  public joinMatch(
    mapId: string,
    mode: string,
    teamId: number,
    name = 'مقاتل',
    networkMode: NetworkMode = 'offline',
    roomCode = 'ROOM1',
    hostingRoom = false,
  ) {
    this.mapId = mapId;
    this.mode = mode;
    this.teamId = teamId;
    this.selfName = name;
    this.networkMode = networkMode;
    this.roomCode = roomCode;
    this.hostingRoom = hostingRoom;
    this.inMatch = true;
    if (networkMode === 'offline') {
      this.syncPeerList([]);
    }
    this.sendJoin();
  }

  public joinLobbyRoom(
    networkMode: NetworkMode,
    roomCode: string,
    mapId: string,
    mode: string,
    name = 'مقاتل',
    hostingRoom = false,
  ) {
    this.networkMode = networkMode;
    this.roomCode = roomCode;
    this.mapId = mapId;
    this.mode = mode;
    this.selfName = name;
    this.hostingRoom = hostingRoom;
    this.inMatch = false;
    if (networkMode === 'offline') {
      this.syncPeerList([]);
    }
    this.sendJoin();
  }

  public requestLocalRooms(query = '') {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'local-rooms:list', query }));
  }

  private sendJoin() {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(
      JSON.stringify({
        type: 'join',
        name: this.selfName,
        networkMode: this.networkMode,
        roomCode: this.roomCode,
        hostingRoom: this.hostingRoom,
        inMatch: this.inMatch,
        mapId: this.mapId,
        mode: this.mode,
        teamId: this.teamId,
        voiceChannel: this.channel,
      }),
    );
  }

  public sendShoot(
    origin: { x: number; y: number; z: number },
    dir: { x: number; y: number; z: number },
    weaponId: string,
  ) {
    if (this.networkMode === 'offline' || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(
      JSON.stringify({
        type: 'combat:shoot',
        origin,
        dir,
        weaponId,
      }),
    );
  }

  public sendHit(targetId: string, damage: number, weaponName: string, isHeadshot: boolean) {
    if (this.networkMode === 'offline' || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(
      JSON.stringify({
        type: 'combat:hit',
        targetId,
        damage,
        weaponName,
        isHeadshot,
      }),
    );
  }

  public updateSelfSpatial(
    x: number,
    y: number,
    z: number,
    yaw: number,
    alive: boolean,
    nowSec: number,
    stance: StanceMode = 'stand',
    weaponId = '',
    health = 100,
  ) {
    this.selfPos = { x, y, z, yaw, alive, stance, weaponId, health };

    // Update Web Audio 3D Listener orientation
    if (this.audioCtx && this.audioCtx.listener) {
      const l = this.audioCtx.listener;
      const fx = -Math.sin(yaw);
      const fz = -Math.cos(yaw);
      if (l.positionX) {
        l.positionX.setValueAtTime(x, this.audioCtx.currentTime);
        l.positionY.setValueAtTime(y + 1.6, this.audioCtx.currentTime);
        l.positionZ.setValueAtTime(z, this.audioCtx.currentTime);
        l.forwardX.setValueAtTime(fx, this.audioCtx.currentTime);
        l.forwardY.setValueAtTime(0, this.audioCtx.currentTime);
        l.forwardZ.setValueAtTime(fz, this.audioCtx.currentTime);
        l.upX.setValueAtTime(0, this.audioCtx.currentTime);
        l.upY.setValueAtTime(1, this.audioCtx.currentTime);
        l.upZ.setValueAtTime(0, this.audioCtx.currentTime);
      }
    }

    // Measure live mic level
    if (this.micAnalyser && this.isMicTransmitting()) {
      this.micAnalyser.getByteTimeDomainData(this.micData);
      let sum = 0;
      for (let i = 0; i < this.micData.length; i++) {
        const d = (this.micData[i] - 128) / 128;
        sum += d * d;
      }
      const rms = Math.sqrt(sum / this.micData.length);
      this.micLevel = Math.min(1, rms * 4.5);
      this.isSpeaking = this.micLevel > 0.08;
    } else {
      this.micLevel = 0;
      this.isSpeaking = false;
    }

    this.syncTrackEnabled();

    // Update remote peer panner positions & proximity gain
    for (const [pid, peer] of this.peers.entries()) {
      const pipe = this.peerAudio.get(pid);
      if (!pipe || !this.audioCtx) continue;
      this.updatePeerSpatialGain(peer, pipe);
    }

    // Throttle state broadcasts (~10Hz)
    if (nowSec - this.lastStateSend >= 0.1) {
      this.lastStateSend = nowSec;
      this.sendStateImmediate();
    }
  }

  private updatePeerSpatialGain(peer: RemotePeerState, pipe: PeerAudioPipeline) {
    if (!this.audioCtx) return;
    const now = this.audioCtx.currentTime;
    const sameTeam = peer.teamId === this.teamId && this.mode !== 'solo';

    // Update 3D panner coordinates
    if (pipe.panner.positionX) {
      pipe.panner.positionX.setTargetAtTime(peer.x, now, 0.05);
      pipe.panner.positionY.setTargetAtTime(peer.y + 1.6, now, 0.05);
      pipe.panner.positionZ.setTargetAtTime(peer.z, now, 0.05);
    }

    let targetGain = 0;
    if (this.channel !== 'off' && peer.voiceChannel !== 'off' && peer.alive) {
      if (this.channel === 'team' || peer.voiceChannel === 'team') {
        targetGain = sameTeam ? 1.0 : 0;
      } else {
        const dist = Math.hypot(
          peer.x - this.selfPos.x,
          peer.y - this.selfPos.y,
          peer.z - this.selfPos.z,
        );
        if (sameTeam) {
          // Team radio stays audible even when far away
          targetGain = dist <= MAX_PROXIMITY_METERS ? 1.0 : 0.45;
        } else if (dist <= MAX_PROXIMITY_METERS) {
          targetGain = Math.max(0, 1 - dist / MAX_PROXIMITY_METERS);
        }
      }
    }
    pipe.gain.gain.setTargetAtTime(targetGain, now, 0.06);
  }

  private sendStateImmediate() {
    if (this.networkMode === 'offline' || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(
      JSON.stringify({
        type: 'state',
        x: this.selfPos.x,
        y: this.selfPos.y,
        z: this.selfPos.z,
        yaw: this.selfPos.yaw,
        stance: this.selfPos.stance,
        weaponId: this.selfPos.weaponId,
        health: this.selfPos.health,
        speaking: this.isSpeaking,
        alive: this.selfPos.alive,
        voiceChannel: this.channel,
      }),
    );
  }

  private handleServerMessage(msg: Record<string, unknown>) {
    if (msg.type === 'welcome') {
      this.selfId = String(msg.id ?? '');
      const peers = (msg.peers as RemotePeerState[]) ?? [];
      this.syncPeerList(peers);
      if (Array.isArray(msg.localRooms)) {
        this.localRooms = msg.localRooms as DiscoveredLocalRoom[];
        this.onLocalRoomsChanged?.(this.localRooms);
      }
      this.sendJoin();
    } else if (msg.type === 'local-rooms:update') {
      this.localRooms = Array.isArray(msg.rooms) ? (msg.rooms as DiscoveredLocalRoom[]) : [];
      this.onLocalRoomsChanged?.(this.localRooms);
    } else if (msg.type === 'peers:sync') {
      const peers = (msg.peers as RemotePeerState[]) ?? [];
      this.syncPeerList(peers);
      this.onPeersChanged?.();
    } else if (msg.type === 'peer:joined') {
      const peer = msg.peer as RemotePeerState;
      if (peer && peer.id !== this.selfId) {
        this.peers.set(peer.id, peer);
        this.ensurePeerPipeline(peer.id, this.selfId < peer.id);
        this.onPeersChanged?.();
      }
    } else if (msg.type === 'peer:state') {
      const peer = msg.peer as RemotePeerState;
      if (peer && peer.id !== this.selfId) {
        this.peers.set(peer.id, peer);
      }
    } else if (msg.type === 'peer:left') {
      const id = String(msg.id ?? '');
      this.peers.delete(id);
      this.disposePeerPipeline(id);
      this.onPeersChanged?.();
    } else if (msg.type === 'combat:shoot') {
      this.onRemoteShoot?.({
        fromId: String(msg.fromId ?? ''),
        fromName: String(msg.fromName ?? 'مقاتل'),
        teamId: Number(msg.teamId ?? 99),
        origin: msg.origin as { x: number; y: number; z: number },
        dir: msg.dir as { x: number; y: number; z: number },
        weaponId: String(msg.weaponId ?? 'm416'),
      });
    } else if (msg.type === 'combat:hit') {
      this.onRemoteHit?.({
        fromId: String(msg.fromId ?? ''),
        fromName: String(msg.fromName ?? 'مقاتل'),
        damage: Number(msg.damage ?? 20),
        weaponName: String(msg.weaponName ?? 'سلاح'),
        isHeadshot: Boolean(msg.isHeadshot),
      });
    } else if (msg.type === 'rtc:offer') {
      const fromId = String(msg.fromId ?? '');
      const sdp = msg.sdp as RTCSessionDescriptionInit;
      void this.handleOffer(fromId, sdp);
    } else if (msg.type === 'rtc:answer') {
      const fromId = String(msg.fromId ?? '');
      const sdp = msg.sdp as RTCSessionDescriptionInit;
      const pipe = this.peerAudio.get(fromId);
      if (pipe) {
        void pipe.pc.setRemoteDescription(new RTCSessionDescription(sdp));
      }
    } else if (msg.type === 'rtc:ice') {
      const fromId = String(msg.fromId ?? '');
      const candidate = msg.candidate as RTCIceCandidateInit;
      const pipe = this.peerAudio.get(fromId);
      if (pipe && candidate) {
        void pipe.pc.addIceCandidate(new RTCIceCandidate(candidate)).catch(() => {});
      }
    } else if (msg.type === 'voice:chunk') {
      this.playWsFallbackChunk(
        String(msg.fromId ?? ''),
        String(msg.pcm ?? ''),
        Number(msg.sampleRate ?? 16000),
        Number(msg.dist ?? 0),
        Boolean(msg.sameTeam),
      );
    }
  }

  private playWsFallbackChunk(
    fromId: string,
    pcmBase64: string,
    sampleRate: number,
    dist: number,
    sameTeam: boolean,
  ) {
    const ctx = this.ensureAudioContext();
    if (!ctx || this.channel === 'off' || !pcmBase64) return;
    const pipe = this.peerAudio.get(fromId);
    if (pipe?.iceConnected) return; // WebRTC already delivering crisp stream

    try {
      const bin = atob(pcmBase64);
      const len = bin.length;
      if (len === 0) return;
      const buf = ctx.createBuffer(1, len, Math.max(8000, Math.min(48000, sampleRate)));
      const ch = buf.getChannelData(0);
      for (let i = 0; i < len; i++) {
        ch[i] = bin.charCodeAt(i) / 127.5 - 1;
      }
      const src = ctx.createBufferSource();
      src.buffer = buf;

      const gain = ctx.createGain();
      const atten =
        sameTeam && dist > MAX_PROXIMITY_METERS
          ? 0.4
          : Math.max(0, 1 - dist / MAX_PROXIMITY_METERS);
      gain.gain.value = atten * 0.85;

      if (pipe) {
        src.connect(gain).connect(pipe.panner);
      } else {
        src.connect(gain).connect(ctx.destination);
      }
      src.start();
    } catch {
      // ignore decode error
    }
  }

  private syncPeerList(list: RemotePeerState[]) {
    const nextIds = new Set(list.map((p) => p.id));
    for (const existingId of Array.from(this.peers.keys())) {
      if (!nextIds.has(existingId)) {
        this.peers.delete(existingId);
        this.disposePeerPipeline(existingId);
      }
    }
    for (const p of list) {
      if (p.id === this.selfId) continue;
      this.peers.set(p.id, p);
      this.ensurePeerPipeline(p.id, this.selfId < p.id);
    }
  }

  private ensurePeerPipeline(peerId: string, shouldOffer: boolean) {
    if (this.peerAudio.has(peerId)) return;
    const ctx = this.ensureAudioContext();
    if (!ctx) return;

    const pc = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
    });

    const panner = ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    panner.refDistance = 5;
    panner.maxDistance = MAX_PROXIMITY_METERS;
    panner.rolloffFactor = 1.6;

    const gain = ctx.createGain();
    gain.gain.value = 1;
    panner.connect(gain).connect(ctx.destination);

    const hiddenAudio = document.createElement('audio');
    hiddenAudio.autoplay = true;
    hiddenAudio.muted = true; // Routed through Web Audio PannerNode!

    const pipe: PeerAudioPipeline = {
      pc,
      panner,
      gain,
      source: null,
      hiddenAudio,
      iceConnected: false,
    };
    this.peerAudio.set(peerId, pipe);

    if (this.micStream) {
      const track = this.micStream.getAudioTracks()[0];
      if (track) pc.addTrack(track, this.micStream);
    }

    pc.onicecandidate = (e) => {
      if (e.candidate && this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(
          JSON.stringify({
            type: 'rtc:ice',
            targetId: peerId,
            candidate: e.candidate,
          }),
        );
      }
    };

    pc.oniceconnectionstatechange = () => {
      pipe.iceConnected =
        pc.iceConnectionState === 'connected' || pc.iceConnectionState === 'completed';
    };

    pc.ontrack = (e) => {
      const stream = e.streams[0] ?? new MediaStream([e.track]);
      hiddenAudio.srcObject = stream;
      if (pipe.source) pipe.source.disconnect();
      pipe.source = ctx.createMediaStreamSource(stream);
      pipe.source.connect(panner);
    };

    if (shouldOffer) {
      void this.negotiateOffer(peerId, pc);
    }
  }

  private async negotiateOffer(peerId: string, pc: RTCPeerConnection) {
    try {
      const offer = await pc.createOffer({ offerToReceiveAudio: true });
      await pc.setLocalDescription(offer);
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(
          JSON.stringify({
            type: 'rtc:offer',
            targetId: peerId,
            sdp: offer,
          }),
        );
      }
    } catch {
      // ignore negotiation race
    }
  }

  private async handleOffer(fromId: string, sdp: RTCSessionDescriptionInit) {
    this.ensurePeerPipeline(fromId, false);
    const pipe = this.peerAudio.get(fromId);
    if (!pipe) return;
    try {
      await pipe.pc.setRemoteDescription(new RTCSessionDescription(sdp));
      const answer = await pipe.pc.createAnswer();
      await pipe.pc.setLocalDescription(answer);
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(
          JSON.stringify({
            type: 'rtc:answer',
            targetId: fromId,
            sdp: answer,
          }),
        );
      }
    } catch {
      // ignore
    }
  }

  private disposePeerPipeline(peerId: string) {
    const pipe = this.peerAudio.get(peerId);
    if (!pipe) return;
    pipe.source?.disconnect();
    pipe.panner.disconnect();
    pipe.gain.disconnect();
    pipe.pc.close();
    pipe.hiddenAudio.srcObject = null;
    this.peerAudio.delete(peerId);
  }

  public getNearbySpeakers() {
    const result: Array<{
      id: string;
      name: string;
      distance: number;
      isAlly: boolean;
      speaking: boolean;
      volume: number;
    }> = [];

    for (const peer of this.peers.values()) {
      const sameTeam = peer.teamId === this.teamId && this.mode !== 'solo';
      const dist = Math.round(
        Math.hypot(
          peer.x - this.selfPos.x,
          peer.y - this.selfPos.y,
          peer.z - this.selfPos.z,
        ),
      );
      if (!peer.alive || peer.voiceChannel === 'off' || this.channel === 'off') continue;
      if ((this.channel === 'team' || peer.voiceChannel === 'team') && !sameTeam) continue;
      if (!sameTeam && dist > MAX_PROXIMITY_METERS) continue;

      const vol =
        sameTeam && dist > MAX_PROXIMITY_METERS
          ? 0.45
          : Math.max(0, 1 - dist / MAX_PROXIMITY_METERS);
      if (peer.speaking || dist <= MAX_PROXIMITY_METERS || sameTeam) {
        result.push({
          id: peer.id,
          name: peer.name,
          distance: dist,
          isAlly: sameTeam,
          speaking: peer.speaking,
          volume: vol,
        });
      }
    }

    result.sort((a, b) => a.distance - b.distance);
    return result;
  }

  public dispose() {
    this.disposed = true;
    clearTimeout(this.reconnectTimer);
    for (const pid of Array.from(this.peerAudio.keys())) {
      this.disposePeerPipeline(pid);
    }
    this.wsProcessor?.disconnect();
    this.micSource?.disconnect();
    this.loopbackGain?.disconnect();
    this.micStream?.getTracks().forEach((t) => t.stop());
    this.ws?.close();
    void this.audioCtx?.close();
  }
}
