export type MapId = 'classic' | 'desert' | 'snow' | 'jungle';
export type GameMode = 'solo' | 'duo' | 'squad';
export type NetworkMode = 'online' | 'local' | 'offline';
export type ControlScheme = 'auto' | 'touch' | 'pc';
export type PerspectiveMode = 'tpp' | 'fpp';
export type StanceMode = 'stand' | 'crouch' | 'prone';

export type GraphicsQuality = 'smooth' | 'balanced' | 'hd' | 'hdr' | 'ultra';
export type GraphicsStyle = 'classic' | 'colorful' | 'realistic' | 'soft' | 'movie';
export type TargetFps = 30 | 60 | 90 | 120;
export type AudioQuality = 'low' | 'high' | 'ultra';

export interface GameSettings {
  quality: GraphicsQuality;
  style: GraphicsStyle;
  targetFps: TargetFps;
  audioQuality: AudioQuality;
  muted: boolean;
  antiAliasing: boolean;
  mouseSensitivity: number;
  controlScheme?: ControlScheme;
}

export interface DiscoveredLocalRoom {
  roomCode: string;
  hostName: string;
  mapId: MapId;
  mode: GameMode;
  playerCount: number;
  inMatch: boolean;
  players: string[];
  createdAt: number;
}

export type GamePhase =
  | 'menu'
  | 'plane'
  | 'skydiving'
  | 'playing'
  | 'paused'
  | 'victory'
  | 'gameover';

export type WeaponCategory =
  | 'ar'
  | 'sniper'
  | 'dmr'
  | 'smg'
  | 'shotgun'
  | 'lmg'
  | 'pistol'
  | 'crossbow';

export type AmmoType = '5.56mm' | '7.62mm' | '9mm' | '.45' | '12G' | '.300' | 'bolt' | 'flare';

export type ScopeType = 'iron' | 'reddot' | '2x' | '4x' | '8x';
export type MuzzleType = 'none' | 'compensator' | 'suppressor';

export interface WeaponDef {
  id: string;
  name: string;
  nameAr: string;
  category: WeaponCategory;
  ammoType: AmmoType;
  damage: number;
  headshotMult: number;
  fireRateMs: number;
  magSize: number;
  extendedMagSize: number;
  reloadTimeSec: number;
  bulletSpeed: number;
  baseSpread: number;
  recoilKick: number;
  pellets?: number;
  range: number;
  auto: boolean;
  airdropOnly?: boolean;
  builtInScope?: ScopeType;
  builtInSuppressor?: boolean;
  color: number;
  accentColor: number;
}

export interface WeaponInstance {
  defId: string;
  ammoInMag: number;
  scope: ScopeType;
  muzzle: MuzzleType;
  extendedMag: boolean;
}

export type ThrowableType = 'frag' | 'smoke' | 'molotov' | 'stun';

export type MedType = 'bandage' | 'firstaid' | 'medkit' | 'energy' | 'painkiller';

export interface LootItem {
  id: string;
  kind:
    | 'weapon'
    | 'ammo'
    | 'helmet'
    | 'vest'
    | 'backpack'
    | 'pan'
    | 'ghillie'
    | 'med'
    | 'scope'
    | 'muzzle'
    | 'extmag'
    | 'throwable';
  labelAr: string;
  subLabel?: string;
  weaponId?: string;
  ammoType?: AmmoType;
  ammoAmount?: number;
  level?: 1 | 2 | 3;
  medType?: MedType;
  scopeType?: ScopeType;
  muzzleType?: MuzzleType;
  throwableType?: ThrowableType;
  x: number;
  y: number;
  z: number;
  pickedUp: boolean;
}

export interface KillfeedEntry {
  id: number;
  killer: string;
  victim: string;
  weaponName: string;
  isPlayerKiller: boolean;
  isAllyKiller?: boolean;
  isPlayerVictim: boolean;
  isHeadshot: boolean;
  timestamp: number;
}

export interface MinimapBlip {
  x: number;
  z: number;
  type: 'ally' | 'vehicle' | 'airdrop' | 'enemy_ping';
}

export interface HudSnapshot {
  phase: GamePhase;
  mapId: MapId;
  mode: GameMode;
  networkMode: NetworkMode;
  roomCode: string;
  perspective: PerspectiveMode;
  stance: StanceMode;
  lean: -1 | 0 | 1;
  isAds: boolean;
  activeScope: ScopeType;
  health: number;
  maxHealth: number;
  boost: number;
  helmetLevel: 0 | 1 | 2 | 3;
  helmetDurability: number;
  vestLevel: 0 | 1 | 2 | 3;
  vestDurability: number;
  backpackLevel: 0 | 1 | 2 | 3;
  hasPan: boolean;
  hasGhillie: boolean;
  aliveCount: number;
  totalCount: number;
  kills: number;
  headshots: number;
  damageDealt: number;
  distanceTraveledMeters: number;
  lootCollected: {
    total: number;
    weapons: number;
    armor: number;
    meds: number;
    ammoAndMods: number;
  };
  survivalTimeSec: number;
  rank: number;
  liveFps: number;
  planeProgress: number;
  canJumpFromPlane: boolean;
  altitude: number;
  isParachuteOpen: boolean;
  inVehicle: boolean;
  vehicleName: string;
  vehicleSpeedKmh: number;
  vehicleFuel: number;
  vehicleHp: number;
  weapons: [WeaponInstance | null, WeaponInstance | null, WeaponInstance | null];
  activeSlot: 0 | 1 | 2;
  ammoBag: Record<AmmoType, number>;
  meds: Record<MedType, number>;
  throwables: Record<ThrowableType, number>;
  activeThrowable: ThrowableType;
  spareAttachments: {
    scopes: ScopeType[];
    muzzles: MuzzleType[];
    extMags: number;
  };
  isReloading: boolean;
  reloadProgress: number;
  isUsingMed: boolean;
  medUseLabel: string;
  medUseProgress: number;
  promptText: string | null;
  compassDeg: number;
  crosshairSpread: number;
  hitmarkerTime: number;
  hitmarkerHeadshot: boolean;
  damageFlashTime: number;
  stunFlashAlpha: number;
  zonePhase: number;
  zoneTimerSec: number;
  zoneShrinking: boolean;
  outsideZone: boolean;
  redzoneActive: boolean;
  inRedzone: boolean;
  airdropAnnounce: string | null;
  weatherLabel: string;
  playerX: number;
  playerZ: number;
  playerYaw: number;
  worldRadius: number;
  safeZone: { x: number; z: number; r: number };
  nextZone: { x: number; z: number; r: number };
  redZone: { x: number; z: number; r: number } | null;
  blips: MinimapBlip[];
  buildings: Array<{ x: number; z: number; w: number; d: number }>;
  killfeed: KillfeedEntry[];
  teammates: Array<{ name: string; health: number; alive: boolean }>;
  pointerLocked: boolean;
  renderResolution: {
    width: number;
    height: number;
    is4k: boolean;
  };
  multiplayer: {
    connected: boolean;
    networkMode: NetworkMode;
    roomCode: string;
    roomPeers: Array<{ id: string; name: string; alive: boolean }>;
  };
  voice: {
    connected: boolean;
    peerCount: number;
    channel: 'all' | 'team' | 'off';
    micMode: 'ptt' | 'open';
    micPermission: 'idle' | 'granted' | 'denied';
    isMicActive: boolean;
    isPttHeld: boolean;
    micLevel: number;
    testLoopback: boolean;
    nearbySpeakers: Array<{
      id: string;
      name: string;
      distance: number;
      isAlly: boolean;
      speaking: boolean;
      volume: number;
    }>;
  };
}

export type VoiceChannel = 'all' | 'team' | 'off';
export type MicMode = 'ptt' | 'open';
export type MicPermission = 'idle' | 'granted' | 'denied';

export interface RemotePeerState {
  id: string;
  name: string;
  networkMode: NetworkMode;
  roomKey: string;
  mapId: string;
  mode: string;
  teamId: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  stance: StanceMode;
  weaponId: string;
  health: number;
  voiceChannel: VoiceChannel;
  speaking: boolean;
  alive: boolean;
}

