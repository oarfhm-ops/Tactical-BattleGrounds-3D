import * as THREE from 'three';
import { getHumanCharacterTextures } from './humanTextures';
import type { MapId, ScopeType, WeaponCategory } from './types';
import { WEAPONS } from './weaponsData';

export interface CharacterVisualRefs {
  root: THREE.Group;
  bodyPivot: THREE.Group;
  headGroup: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  weaponMount: THREE.Group;
  helmet1: THREE.Mesh;
  helmet2: THREE.Mesh;
  helmet3: THREE.Group;
  vestMesh: THREE.Mesh;
  backpack1: THREE.Mesh;
  backpack2: THREE.Mesh;
  backpack3: THREE.Group;
  panGroup: THREE.Group;
  ghillieGroup: THREE.Group;
  parachuteGroup: THREE.Group;
}

export function buildWeaponMesh(
  weaponId: string,
  scope: ScopeType = 'iron',
  hasSuppressor = false,
): THREE.Group {
  const def = WEAPONS[weaponId] ?? WEAPONS.m416;
  const g = new THREE.Group();

  const metalMat = new THREE.MeshStandardMaterial({
    color: def.color,
    roughness: 0.34,
    metalness: 0.78,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: def.accentColor,
    roughness: 0.72,
    metalness: 0.15,
  });
  const darkMat = new THREE.MeshStandardMaterial({
    color: 0x16181b,
    roughness: 0.52,
    metalness: 0.55,
  });

  const cat: WeaponCategory = def.category;
  const lenScale =
    cat === 'sniper'
      ? 1.38
      : cat === 'dmr'
        ? 1.18
        : cat === 'lmg'
          ? 1.24
          : cat === 'smg'
            ? 0.72
            : cat === 'pistol'
              ? 0.42
              : 1.0;

  // Receiver
  const receiver = new THREE.Mesh(
    new THREE.BoxGeometry(0.08, 0.1, 0.36 * lenScale),
    metalMat,
  );
  receiver.position.set(0, 0, 0);
  g.add(receiver);

  // Barrel
  const barrelLen = cat === 'pistol' ? 0.16 : 0.42 * lenScale;
  const barrel = new THREE.Mesh(
    new THREE.CylinderGeometry(0.016, 0.018, barrelLen, 8),
    darkMat,
  );
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0.02, -0.18 * lenScale - barrelLen * 0.5);
  g.add(barrel);

  // Handguard / Forend
  if (cat !== 'pistol') {
    const handguard = new THREE.Mesh(
      new THREE.BoxGeometry(0.068, 0.068, 0.24 * lenScale),
      accentMat,
    );
    handguard.position.set(0, 0.006, -0.22 * lenScale);
    g.add(handguard);
  }

  // Grip
  const grip = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.13, 0.06), accentMat);
  grip.position.set(0, -0.09, 0.09 * lenScale);
  grip.rotation.x = 0.26;
  g.add(grip);

  // Stock
  if (cat !== 'pistol') {
    const stock = new THREE.Mesh(
      new THREE.BoxGeometry(0.058, 0.085, 0.24 * (cat === 'smg' ? 0.7 : 1)),
      accentMat,
    );
    stock.position.set(0, -0.01, 0.26 * lenScale);
    g.add(stock);
  }

  // Magazine
  if (weaponId === 'dp28') {
    const panMag = new THREE.Mesh(
      new THREE.CylinderGeometry(0.11, 0.11, 0.032, 14),
      darkMat,
    );
    panMag.position.set(0, 0.07, -0.02);
    g.add(panMag);
  } else if (weaponId === 'bizon') {
    const drumTube = new THREE.Mesh(
      new THREE.CylinderGeometry(0.034, 0.034, 0.26, 10),
      darkMat,
    );
    drumTube.rotation.x = Math.PI / 2;
    drumTube.position.set(0, -0.045, -0.16);
    g.add(drumTube);
  } else if (cat === 'lmg') {
    const boxMag = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.13, 0.12), accentMat);
    boxMag.position.set(0, -0.1, -0.04);
    g.add(boxMag);
  } else if (cat === 'crossbow') {
    const limbGeo = new THREE.BoxGeometry(0.48, 0.022, 0.035);
    const limbs = new THREE.Mesh(limbGeo, accentMat);
    limbs.position.set(0, 0.02, -0.32);
    g.add(limbs);
    const prod = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.012, 0.44), metalMat);
    prod.position.set(0.18, 0.02, -0.18);
    prod.rotation.y = 0.55;
    g.add(prod);
    const prodL = prod.clone();
    prodL.position.x = -0.18;
    prodL.rotation.y = -0.55;
    g.add(prodL);
  } else {
    const mag = new THREE.Mesh(
      new THREE.BoxGeometry(0.044, cat === 'sniper' ? 0.09 : 0.17, 0.065),
      darkMat,
    );
    mag.position.set(0, -0.11, -0.03);
    mag.rotation.x = -0.18;
    g.add(mag);
  }

  // Scope / Optic
  const effectiveScope = def.builtInScope ?? scope;
  if (effectiveScope !== 'iron') {
    if (effectiveScope === 'reddot') {
      const frame = new THREE.Mesh(new THREE.BoxGeometry(0.046, 0.046, 0.06), darkMat);
      frame.position.set(0, 0.075, 0.01);
      g.add(frame);
      const lens = new THREE.Mesh(
        new THREE.SphereGeometry(0.008, 6, 6),
        new THREE.MeshBasicMaterial({ color: 0xff2b2b }),
      );
      lens.position.set(0, 0.078, 0.01);
      g.add(lens);
    } else {
      const scopeLen = effectiveScope === '8x' ? 0.24 : effectiveScope === '4x' ? 0.16 : 0.11;
      const scopeTube = new THREE.Mesh(
        new THREE.CylinderGeometry(0.024, 0.02, scopeLen, 10),
        darkMat,
      );
      scopeTube.rotation.x = Math.PI / 2;
      scopeTube.position.set(0, 0.082, 0.0);
      g.add(scopeTube);
      const bell = new THREE.Mesh(
        new THREE.CylinderGeometry(0.03, 0.024, 0.045, 10),
        metalMat,
      );
      bell.rotation.x = Math.PI / 2;
      bell.position.set(0, 0.082, -scopeLen * 0.5);
      g.add(bell);
    }
  }

  // Suppressor
  if (hasSuppressor || def.builtInSuppressor) {
    const sup = new THREE.Mesh(
      new THREE.CylinderGeometry(0.026, 0.026, 0.19, 10),
      darkMat,
    );
    sup.rotation.x = Math.PI / 2;
    sup.position.set(0, 0.02, -0.18 * lenScale - barrelLen - 0.08);
    g.add(sup);
  }

  g.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
    }
  });
  return g;
}

function buildSculptedHumanHeadGeo(): THREE.BufferGeometry {
  const geo = new THREE.SphereGeometry(0.116, 36, 28);
  // Put UV u=0.5 cleanly on front (-Z)
  geo.rotateY(Math.PI / 2);

  const pos = geo.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i);
    let y = pos.getY(i);
    let z = pos.getZ(i);

    // Cranial elongation & natural human skull width
    x *= 0.87;
    y *= 1.12;
    z *= 0.99;

    // Front face sculpting (z < 0)
    if (z < 0) {
      const f = Math.min(1, -z / 0.116);
      // Narrower temples above eyes
      if (y > 0.025) {
        x *= 1 - 0.08 * Math.min(1, (y - 0.025) / 0.06) * f;
      }
      // Subtle brow ridge above eyes (y ~ 0.028)
      const browW = Math.exp(-Math.pow((y - 0.026) / 0.018, 2)) * Math.exp(-Math.pow(x / 0.065, 2));
      z -= browW * 0.011;

      // Subtle eye socket recesses (x ~ +/-0.036, y ~ 0.008)
      const eyeSocket =
        (Math.exp(-Math.pow((x - 0.036) / 0.02, 2)) + Math.exp(-Math.pow((x + 0.036) / 0.02, 2))) *
        Math.exp(-Math.pow((y - 0.007) / 0.015, 2));
      z += eyeSocket * 0.009;

      // Sculpted nasal bridge & tip (x ~ 0, y from -0.025 to +0.012)
      const noseProfile =
        Math.exp(-Math.pow(x / 0.015, 2)) *
        Math.exp(-Math.pow((y + 0.012) / 0.022, 2));
      z -= noseProfile * 0.024;

      // Cheekbones (x ~ +/-0.052, y ~ -0.02)
      const cheek =
        (Math.exp(-Math.pow((x - 0.052) / 0.026, 2)) + Math.exp(-Math.pow((x + 0.052) / 0.026, 2))) *
        Math.exp(-Math.pow((y + 0.018) / 0.022, 2));
      z -= cheek * 0.008;

      // Sculpted tapering jawline & chin (y < -0.035)
      if (y < -0.035) {
        const jawT = Math.min(1, (-0.035 - y) / 0.085);
        x *= 1 - 0.34 * jawT;
        // Chin protrusion
        const chin = Math.exp(-Math.pow(x / 0.028, 2)) * Math.exp(-Math.pow((y + 0.092) / 0.026, 2));
        z -= chin * 0.016;
      }
    } else {
      // Back of skull slightly rounded toward nape
      if (y < -0.04) {
        z *= 0.85;
      }
    }

    pos.setXYZ(i, x, y, z);
  }
  geo.computeVertexNormals();
  return geo;
}

function buildSculptedTorsoGeo(): THREE.BufferGeometry {
  // Anatomical Lathe profile from waist-hip (y=0) to shoulder/collar (y=0.58)
  const profile = [
    new THREE.Vector2(0.0, 0.0),
    new THREE.Vector2(0.172, 0.0),
    new THREE.Vector2(0.16, 0.11),  // Tapered lower waist
    new THREE.Vector2(0.168, 0.22), // Mid torso / obliques
    new THREE.Vector2(0.194, 0.34), // Ribcage flare
    new THREE.Vector2(0.214, 0.44), // Broad chest & lats
    new THREE.Vector2(0.188, 0.51), // Deltoid/trapezius curve
    new THREE.Vector2(0.09, 0.56),  // Collar slope
    new THREE.Vector2(0.0, 0.56),
  ];
  const geo = new THREE.LatheGeometry(profile, 32);
  // Rotate so Lathe seam is in the back (+Z) and front center UV aligns to -Z
  geo.rotateY(-Math.PI / 2);

  const pos = geo.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i);
    const y = pos.getY(i);
    let z = pos.getZ(i);

    x *= 1.15;
    z *= 0.72;

    // Pectoral chest fullness & central sternum contour on front (-Z)
    if (z < 0 && y > 0.26 && y < 0.5) {
      const yBell = Math.exp(-Math.pow((y - 0.39) / 0.09, 2));
      const pec =
        (Math.exp(-Math.pow((x - 0.095) / 0.068, 2)) +
          Math.exp(-Math.pow((x + 0.095) / 0.068, 2))) *
        yBell;
      z -= pec * 0.022;
    }

    // Subtle upper back shoulder blades (+Z)
    if (z > 0 && y > 0.28 && y < 0.5) {
      const yBell = Math.exp(-Math.pow((y - 0.41) / 0.09, 2));
      const scap =
        (Math.exp(-Math.pow((x - 0.085) / 0.06, 2)) +
          Math.exp(-Math.pow((x + 0.085) / 0.06, 2))) *
        yBell;
      z += scap * 0.015;
    }

    pos.setXYZ(i, x, y, z);
  }
  geo.computeVertexNormals();
  return geo;
}

export function buildCharacterModel(
  shirtColor: number,
  isAlly = false,
  isHeroStyle = false,
): CharacterVisualRefs {
  const root = new THREE.Group();
  const bodyPivot = new THREE.Group();
  root.add(bodyPivot);

  const tex = getHumanCharacterTextures();

  const skinMat = new THREE.MeshPhysicalMaterial({
    color: 0xd09a78,
    roughness: 0.54,
    metalness: 0.02,
    sheen: 0.22,
    sheenRoughness: 0.65,
    sheenColor: new THREE.Color(0xf6c5aa),
  });

  const faceMat = new THREE.MeshPhysicalMaterial({
    map: tex.faceMap,
    bumpMap: tex.faceBumpMap,
    bumpScale: 0.0045,
    roughness: 0.54,
    metalness: 0.02,
    sheen: 0.2,
    sheenRoughness: 0.7,
    sheenColor: new THREE.Color(0xf4c2a8),
  });

  const clothMat = new THREE.MeshStandardMaterial({
    color: isHeroStyle ? 0xf2f0ea : shirtColor,
    map: tex.shirtMap,
    bumpMap: tex.shirtBumpMap,
    bumpScale: 0.006,
    roughness: 0.82,
    metalness: 0.02,
  });

  const pantsMat = new THREE.MeshStandardMaterial({
    color: isHeroStyle ? 0xffffff : 0xcbd5e1,
    map: tex.pantsMap,
    bumpMap: tex.pantsBumpMap,
    bumpScale: 0.005,
    roughness: 0.86,
    metalness: 0.04,
  });

  const leatherMat = new THREE.MeshStandardMaterial({
    color: 0x241c17,
    roughness: 0.48,
    metalness: 0.16,
  });

  const buckleMat = new THREE.MeshStandardMaterial({
    color: 0xc2c8cf,
    roughness: 0.24,
    metalness: 0.9,
  });

  const bootMat = new THREE.MeshStandardMaterial({
    color: 0x16171a,
    roughness: 0.52,
    metalness: 0.2,
  });

  const tieMat = new THREE.MeshStandardMaterial({
    color: 0x22262c,
    roughness: 0.68,
    metalness: 0.06,
  });

  // Sculpted Anatomical Human Legs (Lathe contours + sculpted combat boots + knee pads)
  const thighProfile = [
    new THREE.Vector2(0.064, -0.4),
    new THREE.Vector2(0.074, -0.26),
    new THREE.Vector2(0.092, -0.1),
    new THREE.Vector2(0.096, 0.0),
  ];
  const thighGeo = new THREE.LatheGeometry(thighProfile, 18);

  const calfProfile = [
    new THREE.Vector2(0.048, -0.76),
    new THREE.Vector2(0.056, -0.66),
    new THREE.Vector2(0.072, -0.53), // Gastrocnemius calf curve
    new THREE.Vector2(0.063, -0.4),
  ];
  const calfGeo = new THREE.LatheGeometry(calfProfile, 18);

  const buildHumanLeg = (sideSign: -1 | 1) => {
    const leg = new THREE.Group();
    leg.position.set(sideSign * 0.112, 0.89, 0);

    const hip = new THREE.Mesh(new THREE.SphereGeometry(0.094, 14, 10), pantsMat);
    hip.scale.set(1.02, 0.9, 0.96);
    leg.add(hip);

    const thigh = new THREE.Mesh(thighGeo, pantsMat);
    thigh.scale.set(1.0, 1.0, 1.06);
    leg.add(thigh);

    // Knee joint & curved tactical knee pad
    const knee = new THREE.Mesh(new THREE.SphereGeometry(0.064, 12, 10), pantsMat);
    knee.position.set(0, -0.4, -0.005);
    leg.add(knee);

    const kneePad = new THREE.Mesh(
      new THREE.SphereGeometry(0.068, 14, 10, 0, Math.PI, 0.4, Math.PI * 0.55),
      leatherMat,
    );
    kneePad.rotation.y = -Math.PI / 2;
    kneePad.position.set(0, -0.405, -0.022);
    kneePad.scale.set(1.05, 1.15, 0.72);
    leg.add(kneePad);

    const calf = new THREE.Mesh(calfGeo, pantsMat);
    calf.position.z = 0.008;
    leg.add(calf);

    // Combat Boot (contoured shaft + rounded toe box + tread sole)
    const bootShaft = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.064, 0.16, 14), bootMat);
    bootShaft.position.set(0, -0.75, 0.005);
    leg.add(bootShaft);

    const bootFoot = new THREE.Mesh(new THREE.CapsuleGeometry(0.052, 0.125, 8, 12), bootMat);
    bootFoot.rotation.x = Math.PI / 2;
    bootFoot.position.set(0, -0.83, -0.048);
    bootFoot.scale.set(1.12, 1.0, 0.74);
    leg.add(bootFoot);

    // Contoured Thigh Holster on Right Leg
    if (sideSign === 1) {
      const holsterStrap1 = new THREE.Mesh(
        new THREE.TorusGeometry(0.088, 0.011, 8, 22),
        leatherMat,
      );
      holsterStrap1.rotation.x = Math.PI / 2;
      holsterStrap1.position.set(0, -0.15, 0);

      const holsterStrap2 = holsterStrap1.clone();
      holsterStrap2.position.set(0, -0.24, 0);

      const holsterBody = new THREE.Mesh(new THREE.CapsuleGeometry(0.038, 0.11, 6, 10), leatherMat);
      holsterBody.position.set(0.095, -0.2, -0.01);
      holsterBody.rotation.z = -0.1;
      holsterBody.scale.set(0.75, 1.0, 1.15);
      leg.add(holsterStrap1, holsterStrap2, holsterBody);
    }

    return leg;
  };

  const leftLeg = buildHumanLeg(-1);
  const rightLeg = buildHumanLeg(1);
  bodyPivot.add(leftLeg, rightLeg);

  // Pelvis + Dual Crossed Tactical Leather Belts (matches reference silhouette)
  const pelvis = new THREE.Mesh(new THREE.SphereGeometry(0.168, 18, 12), pantsMat);
  pelvis.position.set(0, 0.91, 0);
  pelvis.scale.set(1.22, 0.72, 0.88);
  bodyPivot.add(pelvis);

  const beltUpper = new THREE.Mesh(
    new THREE.TorusGeometry(0.185, 0.022, 8, 28),
    leatherMat,
  );
  beltUpper.rotation.x = Math.PI / 2;
  beltUpper.rotation.y = 0.06;
  beltUpper.position.set(0, 0.97, 0);
  beltUpper.scale.set(1.08, 0.76, 1.1);
  bodyPivot.add(beltUpper);

  const beltLower = new THREE.Mesh(
    new THREE.TorusGeometry(0.194, 0.022, 8, 28),
    leatherMat,
  );
  beltLower.rotation.x = Math.PI / 2;
  beltLower.rotation.y = -0.05;
  beltLower.position.set(0, 0.91, 0);
  beltLower.scale.set(1.1, 0.78, 1.1);
  bodyPivot.add(beltLower);

  const buckle = new THREE.Mesh(new THREE.BoxGeometry(0.064, 0.052, 0.026), buckleMat);
  buckle.position.set(0.015, 0.925, -0.155);
  bodyPivot.add(buckle);

  // Sculpted Anatomical Torso
  const torso = new THREE.Mesh(buildSculptedTorsoGeo(), clothMat);
  torso.position.set(0, 0.94, 0);
  bodyPivot.add(torso);

  // Folded Shirt Collar (open V-neck curve)
  const collar = new THREE.Mesh(
    new THREE.TorusGeometry(0.088, 0.018, 8, 22),
    clothMat,
  );
  collar.rotation.x = Math.PI * 0.44;
  collar.position.set(0, 1.495, 0.005);
  collar.scale.set(1.06, 0.96, 1.25);
  bodyPivot.add(collar);

  if (isHeroStyle) {
    // Sculpted Necktie lying smoothly against the chest curve
    const tieCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 1.47, -0.112),
      new THREE.Vector3(0.004, 1.35, -0.154),
      new THREE.Vector3(-0.003, 1.21, -0.148),
      new THREE.Vector3(0.006, 1.07, -0.132),
    ]);
    const tieTube = new THREE.Mesh(new THREE.TubeGeometry(tieCurve, 16, 0.02, 8, false), tieMat);
    tieTube.scale.set(1.3, 1, 0.42);
    const tieKnot = new THREE.Mesh(new THREE.ConeGeometry(0.028, 0.05, 8), tieMat);
    tieKnot.rotation.x = Math.PI;
    tieKnot.position.set(0, 1.47, -0.118);
    tieKnot.scale.set(1.1, 1, 0.65);
    bodyPivot.add(tieTube, tieKnot);

    // Contoured Shoulder Harness Straps hugging chest & back via CatmullRomCurve3
    [-1, 1].forEach((side) => {
      const sx = side * 0.12;
      const strapCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(sx * 0.9, 1.0, -0.145),
        new THREE.Vector3(sx * 1.02, 1.25, -0.165),
        new THREE.Vector3(sx * 1.05, 1.47, -0.05),
        new THREE.Vector3(sx * 0.98, 1.45, 0.09),
        new THREE.Vector3(sx * 0.82, 1.22, 0.155),
        new THREE.Vector3(sx * 0.72, 1.0, 0.145),
      ]);
      const strapMesh = new THREE.Mesh(
        new THREE.TubeGeometry(strapCurve, 22, 0.017, 6, false),
        leatherMat,
      );
      strapMesh.scale.set(1.35, 1, 0.55);
      bodyPivot.add(strapMesh);
    });
  }

  // Tactical Vest (shows when equipped in match)
  const vestMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.215, 0.19, 0.4, 20),
    new THREE.MeshStandardMaterial({ color: 0x2c343d, roughness: 0.58, metalness: 0.24 }),
  );
  vestMesh.position.set(0, 1.22, 0);
  vestMesh.scale.set(1.16, 1, 0.78);
  vestMesh.visible = false;
  bodyPivot.add(vestMesh);

  // Backpacks (Lv1 / Lv2 / Lv3)
  const backpack1 = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.135, 0.22, 6, 12),
    new THREE.MeshStandardMaterial({ color: 0x5c533c, roughness: 0.82, metalness: 0.05 }),
  );
  backpack1.position.set(0, 1.21, 0.19);
  backpack1.scale.set(1.05, 1, 0.64);
  backpack1.visible = false;
  bodyPivot.add(backpack1);

  const backpack2 = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.155, 0.26, 6, 12),
    new THREE.MeshStandardMaterial({ color: 0x3f4c38, roughness: 0.78, metalness: 0.08 }),
  );
  backpack2.position.set(0, 1.22, 0.21);
  backpack2.scale.set(1.1, 1, 0.7);
  backpack2.visible = false;
  bodyPivot.add(backpack2);

  const backpack3 = new THREE.Group();
  const bp3Main = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.17, 0.29, 8, 14),
    new THREE.MeshStandardMaterial({ color: 0x252a30, roughness: 0.68, metalness: 0.18 }),
  );
  bp3Main.scale.set(1.12, 1, 0.74);
  const bp3Roll = new THREE.Mesh(
    new THREE.CylinderGeometry(0.06, 0.06, 0.34, 12),
    new THREE.MeshStandardMaterial({ color: 0x6f5b3a, roughness: 0.8 }),
  );
  bp3Roll.rotation.z = Math.PI / 2;
  bp3Roll.position.set(0, 0.24, 0);
  backpack3.add(bp3Main, bp3Roll);
  backpack3.position.set(0, 1.21, 0.22);
  backpack3.visible = false;
  bodyPivot.add(backpack3);

  // Slung Back Rifle for Lobby Hero Aesthetic
  if (isHeroStyle) {
    const slung = buildWeaponMesh('kar98k', 'iron', false);
    slung.scale.setScalar(0.84);
    slung.position.set(0.06, 1.28, 0.185);
    slung.rotation.set(Math.PI * 0.48, 0.18, 0.34);
    bodyPivot.add(slung);
  }

  // Iron Pan on hip
  const panGroup = new THREE.Group();
  const panDisc = new THREE.Mesh(
    new THREE.CylinderGeometry(0.17, 0.15, 0.04, 16),
    new THREE.MeshStandardMaterial({ color: 0x1b1d20, roughness: 0.42, metalness: 0.86 }),
  );
  panDisc.rotation.x = Math.PI / 2;
  const panHandle = new THREE.Mesh(
    new THREE.CylinderGeometry(0.018, 0.015, 0.2, 8),
    new THREE.MeshStandardMaterial({ color: 0x2a2d30, roughness: 0.5, metalness: 0.75 }),
  );
  panHandle.position.set(0, 0.22, 0);
  panGroup.add(panDisc, panHandle);
  panGroup.position.set(-0.2, 0.94, 0.16);
  panGroup.rotation.z = 0.22;
  panGroup.visible = false;
  bodyPivot.add(panGroup);

  // Ghillie Suit leaves overlay
  const ghillieGroup = new THREE.Group();
  const ghillieMat = new THREE.MeshStandardMaterial({ color: 0x45662b, roughness: 0.95, metalness: 0 });
  for (let i = 0; i < 14; i++) {
    const tuft = new THREE.Mesh(new THREE.DodecahedronGeometry(0.11, 0), ghillieMat);
    const angle = (i / 14) * Math.PI * 2;
    tuft.position.set(
      Math.cos(angle) * 0.22,
      1.0 + (i % 4) * 0.15,
      Math.sin(angle) * 0.16,
    );
    tuft.scale.set(1.2, 0.7, 1.1);
    ghillieGroup.add(tuft);
  }
  ghillieGroup.visible = false;
  bodyPivot.add(ghillieGroup);

  // Sculpted Human Neck (trapezius slope) & Vertex-Sculpted Textured Human Head
  const neckProfile = [
    new THREE.Vector2(0.088, 0.0),
    new THREE.Vector2(0.064, 0.045),
    new THREE.Vector2(0.056, 0.125),
  ];
  const neck = new THREE.Mesh(new THREE.LatheGeometry(neckProfile, 18), skinMat);
  neck.position.set(0, 1.48, 0.005);
  bodyPivot.add(neck);

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.665, -0.008);

  // Sculpted UV-mapped Human Head (realistic eyes, nose, lips, eyebrows, hairline, stubble)
  const sculptedHead = new THREE.Mesh(buildSculptedHumanHeadGeo(), faceMat);
  headGroup.add(sculptedHead);

  // Sculpted Ears hugging sides of skull
  [-1, 1].forEach((side) => {
    const ear = new THREE.Mesh(new THREE.CapsuleGeometry(0.015, 0.028, 6, 8), skinMat);
    ear.position.set(side * 0.104, -0.006, 0.012);
    ear.rotation.z = side * -0.14;
    ear.rotation.y = side * 0.22;
    ear.scale.set(0.52, 1.0, 0.85);
    headGroup.add(ear);
  });

  // Ally indicator visor sunglasses only for teammates
  if (isAlly) {
    const shades = new THREE.Mesh(
      new THREE.CylinderGeometry(0.108, 0.108, 0.032, 16, 1, true, Math.PI * 0.78, Math.PI * 0.44),
      new THREE.MeshStandardMaterial({ color: 0x3fa8ff, roughness: 0.18, metalness: 0.75 }),
    );
    shades.position.set(0, 0.01, -0.012);
    headGroup.add(shades);
  }

  // Helmet Lv.1
  const helmet1 = new THREE.Mesh(
    new THREE.SphereGeometry(0.136, 20, 14, 0, Math.PI * 2, 0, Math.PI * 0.56),
    new THREE.MeshStandardMaterial({ color: 0x4e5b43, roughness: 0.62, metalness: 0.22 }),
  );
  helmet1.position.set(0, 0.02, 0.008);
  helmet1.scale.set(0.95, 1.04, 1.06);
  helmet1.visible = false;
  headGroup.add(helmet1);

  // Helmet Lv.2
  const helmet2 = new THREE.Mesh(
    new THREE.SphereGeometry(0.142, 20, 14, 0, Math.PI * 2, 0, Math.PI * 0.6),
    new THREE.MeshStandardMaterial({ color: 0x353b42, roughness: 0.48, metalness: 0.45 }),
  );
  helmet2.position.set(0, 0.02, 0.008);
  helmet2.scale.set(0.96, 1.05, 1.08);
  helmet2.visible = false;
  headGroup.add(helmet2);

  // Level 3 Spetsnaz Helmet + Curved Hinged Face Shield + Tinted Visor + Chin Strap
  const helmet3 = new THREE.Group();
  const h3Mat = new THREE.MeshStandardMaterial({ color: 0x22262b, roughness: 0.38, metalness: 0.66 });
  const h3TrimMat = new THREE.MeshStandardMaterial({ color: 0x15181c, roughness: 0.45, metalness: 0.75 });
  const h3Dome = new THREE.Mesh(
    new THREE.SphereGeometry(0.148, 24, 18, 0, Math.PI * 2, 0, Math.PI * 0.62),
    h3Mat,
  );
  h3Dome.scale.set(0.96, 1.05, 1.08);
  helmet3.add(h3Dome);

  // Curved armored forehead brow shield (tilted up like reference photo)
  const h3ShieldArc = new THREE.Mesh(
    new THREE.CylinderGeometry(0.156, 0.154, 0.078, 22, 1, false, Math.PI * 0.68, Math.PI * 0.64),
    h3Mat,
  );
  h3ShieldArc.position.set(0, 0.055, -0.015);
  h3ShieldArc.rotation.x = -0.34;
  helmet3.add(h3ShieldArc);

  // Recessed armored eye viewport + dark visor lens
  const h3VisorLens = new THREE.Mesh(
    new THREE.CylinderGeometry(0.158, 0.158, 0.036, 20, 1, true, Math.PI * 0.74, Math.PI * 0.52),
    new THREE.MeshStandardMaterial({ color: 0x0b0f14, roughness: 0.12, metalness: 0.92 }),
  );
  h3VisorLens.position.set(0, 0.052, -0.018);
  h3VisorLens.rotation.x = -0.34;
  helmet3.add(h3VisorLens);

  // Side pivot bolts
  [-0.142, 0.142].forEach((bx) => {
    const bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.018, 10), h3TrimMat);
    bolt.rotation.z = Math.PI / 2;
    bolt.position.set(bx, 0.005, -0.01);
    helmet3.add(bolt);
  });

  // Curved chin strap
  const strapCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.102, -0.01, -0.01),
    new THREE.Vector3(-0.075, -0.082, -0.055),
    new THREE.Vector3(0, -0.105, -0.085),
    new THREE.Vector3(0.075, -0.082, -0.055),
    new THREE.Vector3(0.102, -0.01, -0.01),
  ]);
  const h3Strap = new THREE.Mesh(
    new THREE.TubeGeometry(strapCurve, 18, 0.009, 6, false),
    leatherMat,
  );
  helmet3.add(h3Strap);

  helmet3.position.set(0, 0.022, 0.008);
  helmet3.visible = false;
  headGroup.add(helmet3);

  bodyPivot.add(headGroup);

  // Sculpted Anatomical Arms + Articulated 5-Fingered Hands
  const sleeveProfile = [
    new THREE.Vector2(0.058, -0.22),
    new THREE.Vector2(0.062, -0.19), // Rolled sleeve cuff
    new THREE.Vector2(0.056, -0.12), // Bicep
    new THREE.Vector2(0.066, 0.0),   // Deltoid cap
  ];
  const sleeveGeo = new THREE.LatheGeometry(sleeveProfile, 16);

  const forearmProfile = [
    new THREE.Vector2(0.032, -0.43), // Wrist
    new THREE.Vector2(0.04, -0.35),
    new THREE.Vector2(0.048, -0.27), // Brachioradialis muscle
    new THREE.Vector2(0.044, -0.21), // Elbow
  ];
  const forearmGeo = new THREE.LatheGeometry(forearmProfile, 16);

  const buildHumanArm = (sideSign: -1 | 1) => {
    const arm = new THREE.Group();
    arm.position.set(sideSign * 0.255, 1.42, 0);

    const shoulder = new THREE.Mesh(new THREE.SphereGeometry(0.066, 14, 10), clothMat);
    shoulder.scale.set(1.02, 0.96, 0.96);
    arm.add(shoulder);

    const upperArm = new THREE.Mesh(sleeveGeo, clothMat);
    upperArm.position.set(sideSign * 0.012, 0, 0);
    upperArm.rotation.z = sideSign * 0.06;
    arm.add(upperArm);

    const forearm = new THREE.Mesh(forearmGeo, skinMat);
    forearm.position.set(sideSign * 0.025, 0, -0.01);
    forearm.rotation.x = -0.1;
    arm.add(forearm);

    // Sculpted Palm + Fingerless Tactical Glove + 5 Articulated Fingers
    const handGroup = new THREE.Group();
    handGroup.position.set(sideSign * 0.026, -0.45, -0.055);
    handGroup.rotation.x = -0.1;

    const palm = new THREE.Mesh(new THREE.CapsuleGeometry(0.03, 0.035, 6, 10), leatherMat);
    palm.scale.set(0.68, 1.0, 1.15);
    handGroup.add(palm);

    // Thumb
    const thumb = new THREE.Mesh(new THREE.CapsuleGeometry(0.009, 0.028, 4, 8), skinMat);
    thumb.position.set(-sideSign * 0.022, -0.01, -0.026);
    thumb.rotation.set(-0.35, 0, sideSign * 0.45);
    handGroup.add(thumb);

    // 4 Slightly Curled Organic Fingers
    [-0.021, -0.007, 0.007, 0.021].forEach((fz, idx) => {
      const len = idx === 1 || idx === 2 ? 0.032 : 0.027;
      const finger = new THREE.Mesh(new THREE.CapsuleGeometry(0.0075, len, 4, 8), skinMat);
      finger.position.set(-sideSign * 0.006, -0.045, fz);
      finger.rotation.z = sideSign * -0.26; // Natural curl
      handGroup.add(finger);
    });

    arm.add(handGroup);
    return arm;
  };

  const leftArm = buildHumanArm(-1);
  const rightArm = buildHumanArm(1);
  bodyPivot.add(leftArm);

  const weaponMount = new THREE.Group();
  weaponMount.position.set(-0.02, -0.49, -0.12);
  rightArm.add(weaponMount);
  bodyPivot.add(rightArm);

  // Parachute (hidden unless skydiving)
  const parachuteGroup = new THREE.Group();
  const canopyMat = new THREE.MeshStandardMaterial({
    color: 0xd95338,
    roughness: 0.78,
    side: THREE.DoubleSide,
  });
  const canopy = new THREE.Mesh(
    new THREE.SphereGeometry(2.4, 14, 8, 0, Math.PI * 2, 0, Math.PI * 0.45),
    canopyMat,
  );
  canopy.position.y = 3.8;
  canopy.scale.set(1.2, 0.65, 0.85);
  parachuteGroup.add(canopy);

  const lineMat = new THREE.MeshBasicMaterial({ color: 0xdddddd });
  [
    [-1.7, 4.1, -0.9],
    [1.7, 4.1, -0.9],
    [-1.7, 4.1, 0.9],
    [1.7, 4.1, 0.9],
  ].forEach(([lx, ly, lz]) => {
    const vec = new THREE.Vector3(lx, ly - 1.3, lz);
    const len = vec.length();
    const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, len, 4), lineMat);
    cord.position.set(lx * 0.5, 1.3 + (ly - 1.3) * 0.5, lz * 0.5);
    cord.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), vec.normalize());
    parachuteGroup.add(cord);
  });
  parachuteGroup.visible = false;
  root.add(parachuteGroup);

  root.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });

  return {
    root,
    bodyPivot,
    headGroup,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    weaponMount,
    helmet1,
    helmet2,
    helmet3,
    vestMesh,
    backpack1,
    backpack2,
    backpack3,
    panGroup,
    ghillieGroup,
    parachuteGroup,
  };
}

export interface VehicleVisualRefs {
  root: THREE.Group;
  wheels: THREE.Group[];
  kind: 'offroader' | 'motorcycle';
}

export function buildVehicleModel(kind: 'offroader' | 'motorcycle'): VehicleVisualRefs {
  const root = new THREE.Group();
  const wheels: THREE.Group[] = [];

  const tireMat = new THREE.MeshStandardMaterial({ color: 0x181a1c, roughness: 0.88, metalness: 0.08 });
  const rimMat = new THREE.MeshStandardMaterial({ color: 0x8e959c, roughness: 0.25, metalness: 0.85 });
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x8cb8d6,
    roughness: 0.12,
    metalness: 0.3,
    transparent: true,
    opacity: 0.55,
  });
  const headlightMat = new THREE.MeshStandardMaterial({
    color: 0xfff3c4,
    emissive: 0xffe49c,
    emissiveIntensity: 0.9,
  });

  const makeWheel = (radius: number, width: number) => {
    const wg = new THREE.Group();
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, width, 16), tireMat);
    tire.rotation.z = Math.PI / 2;
    const rim = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.55, radius * 0.55, width + 0.02, 10), rimMat);
    rim.rotation.z = Math.PI / 2;
    wg.add(tire, rim);
    return wg;
  };

  if (kind === 'offroader') {
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x4b583e,
      roughness: 0.42,
      metalness: 0.35,
    });
    const trimMat = new THREE.MeshStandardMaterial({ color: 0x202326, roughness: 0.65, metalness: 0.5 });

    // Lower chassis
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.72, 4.3), bodyMat);
    chassis.position.set(0, 0.78, 0);
    root.add(chassis);

    // Cabin / Roll cage
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.86, 0.72, 2.2), bodyMat);
    cabin.position.set(0, 1.48, 0.35);
    root.add(cabin);

    // Windshield
    const windshield = new THREE.Mesh(new THREE.BoxGeometry(1.74, 0.58, 0.08), glassMat);
    windshield.position.set(0, 1.46, -0.76);
    windshield.rotation.x = 0.24;
    root.add(windshield);

    // Front Bumper + Headlights
    const bumper = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.25, 0.28), trimMat);
    bumper.position.set(0, 0.56, -2.22);
    root.add(bumper);

    [-0.72, 0.72].forEach((hx) => {
      const hl = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.16, 0.08), headlightMat);
      hl.position.set(hx, 0.85, -2.16);
      root.add(hl);
    });

    // Spare wheel on back
    const spare = makeWheel(0.42, 0.24);
    spare.rotation.y = Math.PI / 2;
    spare.position.set(0, 1.0, 2.22);
    root.add(spare);

    // 4 Driving wheels
    const wheelPositions: Array<[number, number, number]> = [
      [-1.12, 0.46, -1.38],
      [1.12, 0.46, -1.38],
      [-1.12, 0.46, 1.38],
      [1.12, 0.46, 1.38],
    ];
    wheelPositions.forEach(([wx, wy, wz]) => {
      const w = makeWheel(0.46, 0.34);
      w.position.set(wx, wy, wz);
      root.add(w);
      wheels.push(w);
    });
  } else {
    // Motorcycle
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x9c3226, roughness: 0.32, metalness: 0.65 });
    const seatMat = new THREE.MeshStandardMaterial({ color: 0x1b1c1e, roughness: 0.85, metalness: 0.1 });

    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.42, 1.45), frameMat);
    frame.position.set(0, 0.65, 0);
    root.add(frame);

    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.14, 0.78), seatMat);
    seat.position.set(0, 0.9, 0.24);
    root.add(seat);

    const handlebar = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.86, 8), rimMat);
    handlebar.rotation.z = Math.PI / 2;
    handlebar.position.set(0, 1.06, -0.58);
    root.add(handlebar);

    const fork = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.8, 8), rimMat);
    fork.position.set(0, 0.72, -0.68);
    fork.rotation.x = 0.3;
    root.add(fork);

    const hl = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 10), headlightMat);
    hl.position.set(0, 0.94, -0.74);
    root.add(hl);

    [
      [0, 0.38, -0.82],
      [0, 0.38, 0.82],
    ].forEach(([wx, wy, wz]) => {
      const w = makeWheel(0.38, 0.2);
      w.position.set(wx, wy, wz);
      root.add(w);
      wheels.push(w);
    });
  }

  root.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });
  return { root, wheels, kind };
}

export function buildPlaneModel(): { root: THREE.Group; props: THREE.Group[] } {
  const root = new THREE.Group();
  const props: THREE.Group[] = [];

  const hullMat = new THREE.MeshStandardMaterial({ color: 0x525a52, roughness: 0.55, metalness: 0.45 });
  const trimMat = new THREE.MeshStandardMaterial({ color: 0x2c322e, roughness: 0.42, metalness: 0.65 });
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x1b2632, roughness: 0.15, metalness: 0.85 });

  // Fuselage
  const fuselage = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.3, 24, 14), hullMat);
  fuselage.rotation.x = Math.PI / 2;
  root.add(fuselage);

  // Nose cone
  const nose = new THREE.Mesh(new THREE.SphereGeometry(2.3, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.5), hullMat);
  nose.rotation.x = -Math.PI / 2;
  nose.position.z = -12;
  root.add(nose);

  // Cockpit canopy
  const cockpit = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.9, 2.2), glassMat);
  cockpit.position.set(0, 1.35, -10.8);
  cockpit.rotation.x = 0.2;
  root.add(cockpit);

  // Main High Wings
  const wing = new THREE.Mesh(new THREE.BoxGeometry(28, 0.42, 4.2), hullMat);
  wing.position.set(0, 1.6, -1.5);
  root.add(wing);

  // Tail Stabilizers
  const hStab = new THREE.Mesh(new THREE.BoxGeometry(10.5, 0.3, 2.2), hullMat);
  hStab.position.set(0, 0.8, 10.6);
  root.add(hStab);

  const vStab = new THREE.Mesh(new THREE.BoxGeometry(0.35, 5.2, 3.2), trimMat);
  vStab.position.set(0, 3.4, 10.2);
  root.add(vStab);

  // 4 Turboprop Engines + Spinning Propellers
  [-9.5, -5.2, 5.2, 9.5].forEach((ex) => {
    const nacelle = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.5, 2.6, 10), trimMat);
    nacelle.rotation.x = Math.PI / 2;
    nacelle.position.set(ex, 1.2, -3.2);
    root.add(nacelle);

    const propGroup = new THREE.Group();
    propGroup.position.set(ex, 1.2, -4.55);
    const blade1 = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.22, 0.06), trimMat);
    const blade2 = new THREE.Mesh(new THREE.BoxGeometry(0.22, 2.8, 0.06), trimMat);
    propGroup.add(blade1, blade2);
    root.add(propGroup);
    props.push(propGroup);
  });

  return { root, props };
}

export function buildAirdropCrate(crateMap: THREE.Texture): {
  root: THREE.Group;
  chute: THREE.Group;
} {
  const root = new THREE.Group();
  const box = new THREE.Mesh(
    new THREE.BoxGeometry(1.9, 1.7, 1.9),
    new THREE.MeshStandardMaterial({ map: crateMap, roughness: 0.52, metalness: 0.38 }),
  );
  box.position.y = 0.85;
  box.castShadow = true;
  box.receiveShadow = true;
  root.add(box);

  const cap = new THREE.Mesh(
    new THREE.BoxGeometry(2.02, 0.22, 2.02),
    new THREE.MeshStandardMaterial({ color: 0x1f2532, roughness: 0.45, metalness: 0.6 }),
  );
  cap.position.y = 1.72;
  root.add(cap);

  const chute = new THREE.Group();
  const dome = new THREE.Mesh(
    new THREE.SphereGeometry(3.2, 14, 8, 0, Math.PI * 2, 0, Math.PI * 0.46),
    new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.8, side: THREE.DoubleSide }),
  );
  dome.position.y = 4.5;
  chute.add(dome);
  root.add(chute);

  return { root, chute };
}

export interface BuildingCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  maxY: number;
}

export interface BuildingBuildResult {
  group: THREE.Group;
  colliders: BuildingCollider[];
}

export function buildCompoundBuilding(
  x: number,
  y: number,
  z: number,
  w: number,
  d: number,
  h: number,
  mapId: MapId,
  wallMap: THREE.Texture,
  roofMap: THREE.Texture,
  isCastle = false,
): BuildingBuildResult {
  const group = new THREE.Group();
  group.position.set(x, y, z);

  const wallMat = new THREE.MeshStandardMaterial({
    map: wallMap,
    roughness: 0.82,
    metalness: 0.05,
  });
  const roofMat = new THREE.MeshStandardMaterial({
    map: roofMap,
    roughness: 0.72,
    metalness: 0.12,
  });
  const floorMat = new THREE.MeshStandardMaterial({
    color: mapId === 'desert' ? 0x9b866a : 0x5c5852,
    roughness: 0.9,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: mapId === 'snow' ? 0x454f5a : 0x423326,
    roughness: 0.75,
  });

  const colliders: BuildingCollider[] = [];
  const wallT = 0.45;
  const doorW = 2.6;

  // Foundation slab
  const slab = new THREE.Mesh(new THREE.BoxGeometry(w + 0.5, 0.35, d + 0.5), floorMat);
  slab.position.y = 0.175;
  slab.receiveShadow = true;
  group.add(slab);

  const addWall = (lx: number, lz: number, lw: number, ld: number, lh = h, ly = 0.35) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(lw, lh, ld), wallMat);
    mesh.position.set(lx, ly + lh * 0.5, lz);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    group.add(mesh);
    colliders.push({
      minX: x + lx - lw * 0.5,
      maxX: x + lx + lw * 0.5,
      minZ: z + lz - ld * 0.5,
      maxZ: z + lz + ld * 0.5,
      maxY: y + ly + lh,
    });
  };

  // Back wall (North, solid)
  addWall(0, -d * 0.5 + wallT * 0.5, w, wallT);

  // Front wall (South, with centered doorway)
  const sideSegW = (w - doorW) * 0.5;
  if (sideSegW > 0.4) {
    addWall(-w * 0.5 + sideSegW * 0.5, d * 0.5 - wallT * 0.5, sideSegW, wallT);
    addWall(w * 0.5 - sideSegW * 0.5, d * 0.5 - wallT * 0.5, sideSegW, wallT);
  }
  // Lintel above front door
  const lintel = new THREE.Mesh(new THREE.BoxGeometry(doorW + 0.2, 0.9, wallT), wallMat);
  lintel.position.set(0, 0.35 + h - 0.45, d * 0.5 - wallT * 0.5);
  group.add(lintel);

  // Side walls (East & West with doorway/window openings)
  const sideDoorSeg = (d - doorW) * 0.5;
  if (sideDoorSeg > 0.5) {
    addWall(-w * 0.5 + wallT * 0.5, -d * 0.5 + sideDoorSeg * 0.5, wallT, sideDoorSeg);
    addWall(-w * 0.5 + wallT * 0.5, d * 0.5 - sideDoorSeg * 0.5, wallT, sideDoorSeg);
    addWall(w * 0.5 - wallT * 0.5, -d * 0.5 + sideDoorSeg * 0.5, wallT, sideDoorSeg);
    addWall(w * 0.5 - wallT * 0.5, d * 0.5 - sideDoorSeg * 0.5, wallT, sideDoorSeg);
  }

  // Roof + eaves
  const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 0.9, 0.35, d + 0.9), roofMat);
  roof.position.y = 0.35 + h + 0.175;
  roof.castShadow = true;
  roof.receiveShadow = true;
  group.add(roof);

  if (isCastle) {
    // 4 Corner castle turrets!
    [
      [-w * 0.5, -d * 0.5],
      [w * 0.5, -d * 0.5],
      [-w * 0.5, d * 0.5],
      [w * 0.5, d * 0.5],
    ].forEach(([tx, tz]) => {
      const tower = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 2.0, h + 3.2, 10), wallMat);
      tower.position.set(tx, (h + 3.2) * 0.5, tz);
      tower.castShadow = true;
      tower.receiveShadow = true;
      group.add(tower);
      const spire = new THREE.Mesh(new THREE.ConeGeometry(2.2, 2.6, 10), roofMat);
      spire.position.set(tx, h + 4.4, tz);
      group.add(spire);
      colliders.push({
        minX: x + tx - 1.9,
        maxX: x + tx + 1.9,
        minZ: z + tz - 1.9,
        maxZ: z + tz + 1.9,
        maxY: y + h + 3.5,
      });
    });
  } else {
    // Interior wooden crate / cover pillar
    const crate = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.2, 1.4), trimMat);
    crate.position.set(w * 0.22, 0.95, -d * 0.15);
    crate.castShadow = true;
    group.add(crate);
    colliders.push({
      minX: x + w * 0.22 - 0.7,
      maxX: x + w * 0.22 + 0.7,
      minZ: z - d * 0.15 - 0.7,
      maxZ: z - d * 0.15 + 0.7,
      maxY: y + 1.55,
    });
  }

  return { group, colliders };
}
