import * as THREE from 'three';
import type { MapId } from './types';
import { MAP_CONFIGS } from './weaponsData';
import type { BiomeTextures } from './textures';
import { buildCompoundBuilding, type BuildingCollider } from './models';

export interface WorldTerrainData {
  worldRadius: number;
  groundHeightAt: (x: number, z: number) => number;
  colliders: BuildingCollider[];
  buildingsMeta: Array<{ x: number; z: number; w: number; d: number }>;
  lootSpawnPoints: Array<{ x: number; y: number; z: number }>;
  vehicleSpawnPoints: Array<{ x: number; y: number; z: number; rot: number; kind: 'offroader' | 'motorcycle' }>;
  treePositions: Array<{ x: number; z: number; r: number }>;
  dispose: () => void;
}

function seededRand(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export function createGroundHeightFn(mapId: MapId, worldRadius: number) {
  return (x: number, z: number): number => {
    const distFromCenter = Math.hypot(x, z);
    const edgeFalloff = Math.max(0, (distFromCenter - (worldRadius - 38)) / 38);
    const islandDrop = edgeFalloff * edgeFalloff * 14;

    if (mapId === 'classic') {
      const h =
        Math.sin(x * 0.018) * Math.cos(z * 0.016) * 5.2 +
        Math.sin(x * 0.045 + 1.2) * Math.sin(z * 0.038) * 1.9 +
        Math.cos((x + z) * 0.01) * 3.0;
      return h - islandDrop;
    }
    if (mapId === 'desert') {
      const dune =
        Math.sin(x * 0.024 + z * 0.012) * 5.8 +
        Math.abs(Math.cos(x * 0.015 - z * 0.02)) * 4.2 +
        Math.sin(z * 0.05) * 1.1;
      return dune - islandDrop;
    }
    if (mapId === 'snow') {
      // Flat central castle plateau + surrounding alpine ridges
      const centerDist = Math.hypot(x, z);
      const plateauBlend = THREE.MathUtils.smoothstep(centerDist, 18, 52);
      const ridge =
        (Math.sin(x * 0.025) * Math.cos(z * 0.025) * 6.5 +
          Math.cos(x * 0.055) * Math.sin(z * 0.04) * 2.1) *
        plateauBlend;
      return 1.2 + ridge - islandDrop;
    }
    // jungle
    const h =
      Math.sin(x * 0.028) * Math.cos(z * 0.022) * 3.8 +
      Math.sin(x * 0.07) * Math.cos(z * 0.06) * 1.3;
    return h - islandDrop;
  };
}

export function buildMapWorld(
  scene: THREE.Scene,
  mapId: MapId,
  textures: BiomeTextures,
): WorldTerrainData {
  const cfg = MAP_CONFIGS[mapId];
  const worldRadius = mapId === 'classic' || mapId === 'desert' ? 240 : 190;
  const groundHeightAt = createGroundHeightFn(mapId, worldRadius);
  const rand = seededRand(
    mapId === 'classic' ? 101 : mapId === 'desert' ? 202 : mapId === 'snow' ? 303 : 404,
  );

  const disposables: Array<{ dispose: () => void }> = [];

  // 1. Extended Terrain Mesh (extends well beyond play radius for natural coastal horizon)
  const terrainSize = worldRadius * 2.55;
  const segs = 112;
  const terrainGeo = new THREE.PlaneGeometry(terrainSize, terrainSize, segs, segs);
  terrainGeo.rotateX(-Math.PI / 2);
  const posAttr = terrainGeo.attributes.position;
  for (let i = 0; i < posAttr.count; i++) {
    const vx = posAttr.getX(i);
    const vz = posAttr.getZ(i);
    posAttr.setY(i, groundHeightAt(vx, vz));
  }
  terrainGeo.computeVertexNormals();
  const terrainMat = new THREE.MeshStandardMaterial({
    map: textures.groundMap,
    roughness: mapId === 'snow' ? 0.62 : 0.92,
    metalness: 0.02,
  });
  const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
  terrainMesh.receiveShadow = true;
  scene.add(terrainMesh);
  disposables.push(terrainGeo, terrainMat);

  // 2. Surrounding Sea / Swamp Water Plane
  const waterGeo = new THREE.PlaneGeometry(terrainSize * 1.4, terrainSize * 1.4);
  waterGeo.rotateX(-Math.PI / 2);
  const waterMat = new THREE.MeshStandardMaterial({
    color: mapId === 'jungle' ? 0x2a4536 : mapId === 'snow' ? 0x3b6380 : 0x265b7d,
    roughness: 0.18,
    metalness: 0.38,
    transparent: true,
    opacity: 0.86,
  });
  const waterMesh = new THREE.Mesh(waterGeo, waterMat);
  waterMesh.position.y = cfg.waterLevel;
  waterMesh.receiveShadow = true;
  scene.add(waterMesh);
  disposables.push(waterGeo, waterMat);

  // 3. Cross-Island Roads (elevated slightly on Y via polygonOffset to eliminate Z-fighting)
  const roadMat = new THREE.MeshStandardMaterial({
    map: textures.roadMap,
    roughness: 0.86,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  disposables.push(roadMat);

  const buildRoadStrip = (isXAxis: boolean) => {
    const stripSegs = 64;
    const stripLen = worldRadius * 1.75;
    const roadGeo = new THREE.PlaneGeometry(7.2, stripLen, 2, stripSegs);
    roadGeo.rotateX(-Math.PI / 2);
    if (isXAxis) roadGeo.rotateY(Math.PI / 2);
    const rPos = roadGeo.attributes.position;
    for (let i = 0; i < rPos.count; i++) {
      const rx = rPos.getX(i);
      const rz = rPos.getZ(i);
      rPos.setY(i, groundHeightAt(rx, rz) + 0.08);
    }
    roadGeo.computeVertexNormals();
    const roadMesh = new THREE.Mesh(roadGeo, roadMat);
    roadMesh.receiveShadow = true;
    scene.add(roadMesh);
    disposables.push(roadGeo);
  };
  buildRoadStrip(false);
  buildRoadStrip(true);

  // 4. Compounds & Landmarks
  const colliders: BuildingCollider[] = [];
  const buildingsMeta: Array<{ x: number; z: number; w: number; d: number }> = [];
  const lootSpawnPoints: Array<{ x: number; y: number; z: number }> = [];

  const placeBuilding = (
    bx: number,
    bz: number,
    bw: number,
    bd: number,
    bh: number,
    isCastle = false,
  ) => {
    const by = groundHeightAt(bx, bz);
    if (by < cfg.waterLevel + 0.6) return;
    const built = buildCompoundBuilding(
      bx,
      by,
      bz,
      bw,
      bd,
      bh,
      mapId,
      textures.wallMap,
      textures.roofMap,
      isCastle,
    );
    scene.add(built.group);
    colliders.push(...built.colliders);
    buildingsMeta.push({ x: bx, z: bz, w: bw, d: bd });

    // Interior & perimeter loot points
    lootSpawnPoints.push(
      { x: bx - bw * 0.2, y: by + 0.38, z: bz - bd * 0.12 },
      { x: bx + bw * 0.15, y: by + 0.38, z: bz + bd * 0.18 },
      { x: bx, y: by + 0.38, z: bz },
    );
    if (isCastle) {
      lootSpawnPoints.push(
        { x: bx - 4, y: by + 0.38, z: bz - 4 },
        { x: bx + 4, y: by + 0.38, z: bz + 4 },
      );
    }
  };

  if (mapId === 'snow') {
    // Iconic central castle!
    placeBuilding(0, 0, 18, 18, 5.2, true);
  }

  // Generate scattered compounds/towns in concentric tactical rings
  const compoundAnchors: Array<[number, number, number, number]> = [
    [-46, -48, 10, 9],
    [-58, -36, 8, 8],
    [52, -44, 11, 8],
    [64, -56, 8, 7],
    [-48, 52, 10, 10],
    [48, 55, 9, 10],
    [0, -88, 12, 9],
    [14, -96, 8, 8],
    [0, 88, 11, 9],
    [-92, 12, 10, 8],
    [94, -10, 10, 9],
    [-115, -95, 9, 9],
    [118, -105, 10, 8],
    [-110, 108, 9, 10],
    [112, 102, 10, 9],
    [-145, 22, 8, 8],
    [148, -24, 9, 8],
  ];

  compoundAnchors.forEach(([ax, az, aw, ad]) => {
    if (Math.hypot(ax, az) < worldRadius - 26) {
      placeBuilding(
        ax + (rand() - 0.5) * 6,
        az + (rand() - 0.5) * 6,
        aw,
        ad,
        3.8 + rand() * 1.1,
      );
    }
  });

  // Extra field crates / ruins / jungle cave arches for cover + loot
  for (let i = 0; i < 22; i++) {
    const angle = rand() * Math.PI * 2;
    const dist = 24 + rand() * (worldRadius - 52);
    const rx = Math.cos(angle) * dist;
    const rz = Math.sin(angle) * dist;
    const ry = groundHeightAt(rx, rz);
    if (ry < cfg.waterLevel + 0.5) continue;

    if (mapId === 'jungle' && i % 3 === 0) {
      // Jungle stone cave / shelter arch
      const archGroup = new THREE.Group();
      archGroup.position.set(rx, ry, rz);
      archGroup.rotation.y = rand() * Math.PI;
      const rockMat = new THREE.MeshStandardMaterial({ color: 0x4b4e47, roughness: 0.92 });
      const leftP = new THREE.Mesh(new THREE.DodecahedronGeometry(2.2, 0), rockMat);
      leftP.position.set(-2.2, 1.5, 0);
      leftP.scale.set(0.9, 1.4, 1.3);
      const rightP = leftP.clone();
      rightP.position.x = 2.2;
      const cap = new THREE.Mesh(new THREE.DodecahedronGeometry(2.5, 0), rockMat);
      cap.position.set(0, 3.3, 0);
      cap.scale.set(2.1, 0.65, 1.4);
      archGroup.add(leftP, rightP, cap);
      scene.add(archGroup);
      disposables.push(rockMat);
      lootSpawnPoints.push({ x: rx, y: ry + 0.2, z: rz });
    } else {
      lootSpawnPoints.push({ x: rx, y: ry + 0.2, z: rz });
    }
  }

  // 5. Instanced Trees (composite 2-part InstancedMeshes: trunk + foliage canopy with ±15% scale & color tint variation!)
  const treePositions: Array<{ x: number; z: number; r: number }> = [];
  const validTreeCoords: Array<{ x: number; y: number; z: number; s: number; rot: number }> = [];

  for (let i = 0; i < cfg.treeCount * 2 && validTreeCoords.length < cfg.treeCount; i++) {
    const ang = rand() * Math.PI * 2;
    const rad = 16 + rand() * (worldRadius - 22);
    const tx = Math.cos(ang) * rad;
    const tz = Math.sin(ang) * rad;
    // Keep off roads & away from buildings
    if (Math.abs(tx) < 6.5 || Math.abs(tz) < 6.5) continue;
    const nearBuilding = buildingsMeta.some(
      (b) => Math.abs(tx - b.x) < b.w * 0.75 + 3 && Math.abs(tz - b.z) < b.d * 0.75 + 3,
    );
    if (nearBuilding) continue;
    const ty = groundHeightAt(tx, tz);
    if (ty < cfg.waterLevel + 0.7) continue;
    const scale = 0.85 + rand() * 0.3; // ±15%
    validTreeCoords.push({ x: tx, y: ty, z: tz, s: scale, rot: rand() * Math.PI * 2 });
    treePositions.push({ x: tx, z: tz, r: 0.65 * scale });
  }

  if (validTreeCoords.length > 0) {
    const trunkGeo = new THREE.CylinderGeometry(0.24, 0.42, 3.2, 7);
    trunkGeo.translate(0, 1.6, 0);
    const trunkMat = new THREE.MeshStandardMaterial({
      color: mapId === 'desert' ? 0x6b5842 : 0x4b382a,
      roughness: 0.92,
    });
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, validTreeCoords.length);
    trunks.castShadow = true;
    trunks.receiveShadow = true;

    const canopyGeo =
      mapId === 'snow' || mapId === 'classic'
        ? new THREE.ConeGeometry(2.1, 5.2, 7)
        : new THREE.DodecahedronGeometry(2.0, 0);
    canopyGeo.translate(0, mapId === 'snow' || mapId === 'classic' ? 4.8 : 4.2, 0);
    const canopyMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.85,
    });
    const canopies = new THREE.InstancedMesh(canopyGeo, canopyMat, validTreeCoords.length);
    canopies.castShadow = true;
    canopies.receiveShadow = true;

    const dummy = new THREE.Object3D();
    const tint = new THREE.Color();
    validTreeCoords.forEach((t, idx) => {
      dummy.position.set(t.x, t.y, t.z);
      dummy.rotation.set(0, t.rot, 0);
      dummy.scale.setScalar(t.s);
      dummy.updateMatrix();
      trunks.setMatrixAt(idx, dummy.matrix);
      canopies.setMatrixAt(idx, dummy.matrix);

      if (mapId === 'snow') {
        tint.setHSL(0.42, 0.22, 0.38 + rand() * 0.25);
      } else if (mapId === 'desert') {
        tint.setHSL(0.22, 0.35, 0.32 + rand() * 0.14);
      } else if (mapId === 'jungle') {
        tint.setHSL(0.32 + rand() * 0.05, 0.52, 0.22 + rand() * 0.14);
      } else {
        tint.setHSL(0.28 + rand() * 0.05, 0.45, 0.26 + rand() * 0.14);
      }
      canopies.setColorAt(idx, tint);
    });
    trunks.instanceMatrix.needsUpdate = true;
    canopies.instanceMatrix.needsUpdate = true;
    if (canopies.instanceColor) canopies.instanceColor.needsUpdate = true;
    trunks.computeBoundingSphere();
    canopies.computeBoundingSphere();
    scene.add(trunks, canopies);
    disposables.push(trunkGeo, trunkMat, canopyGeo, canopyMat);
  }

  // 6. Instanced Boulders / Tactical Cover Rocks
  const rockCoords: Array<{ x: number; y: number; z: number; sx: number; sy: number; sz: number; rot: number }> = [];
  for (let i = 0; i < cfg.rockCount * 2 && rockCoords.length < cfg.rockCount; i++) {
    const ang = rand() * Math.PI * 2;
    const rad = 14 + rand() * (worldRadius - 20);
    const rx = Math.cos(ang) * rad;
    const rz = Math.sin(ang) * rad;
    if (Math.abs(rx) < 5.5 || Math.abs(rz) < 5.5) continue;
    const ry = groundHeightAt(rx, rz);
    if (ry < cfg.waterLevel + 0.3) continue;
    const s = 0.85 + rand() * 1.45;
    rockCoords.push({
      x: rx,
      y: ry,
      z: rz,
      sx: s * (0.9 + rand() * 0.35),
      sy: s * (0.7 + rand() * 0.4),
      sz: s * (0.9 + rand() * 0.35),
      rot: rand() * Math.PI * 2,
    });
    treePositions.push({ x: rx, z: rz, r: s * 0.95 });
  }

  if (rockCoords.length > 0) {
    const rockGeo = new THREE.DodecahedronGeometry(1.1, 0);
    rockGeo.translate(0, 0.55, 0);
    const rockMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.92, metalness: 0.04 });
    const rocks = new THREE.InstancedMesh(rockGeo, rockMat, rockCoords.length);
    rocks.castShadow = true;
    rocks.receiveShadow = true;
    const dummy = new THREE.Object3D();
    const rTint = new THREE.Color();
    rockCoords.forEach((rk, idx) => {
      dummy.position.set(rk.x, rk.y, rk.z);
      dummy.rotation.set(0, rk.rot, 0);
      dummy.scale.set(rk.sx, rk.sy, rk.sz);
      dummy.updateMatrix();
      rocks.setMatrixAt(idx, dummy.matrix);
      if (mapId === 'desert') rTint.setHSL(0.08, 0.34, 0.45 + rand() * 0.14);
      else if (mapId === 'snow') rTint.setHSL(0.58, 0.12, 0.52 + rand() * 0.16);
      else rTint.setHSL(0.08, 0.08, 0.36 + rand() * 0.16);
      rocks.setColorAt(idx, rTint);
    });
    rocks.instanceMatrix.needsUpdate = true;
    if (rocks.instanceColor) rocks.instanceColor.needsUpdate = true;
    rocks.computeBoundingSphere();
    scene.add(rocks);
    disposables.push(rockGeo, rockMat);
  }

  // 7. Vehicle Spawns along main roads
  const vehicleSpawnPoints: Array<{
    x: number;
    y: number;
    z: number;
    rot: number;
    kind: 'offroader' | 'motorcycle';
  }> = [];
  const vCoords: Array<[number, number, number, 'offroader' | 'motorcycle']> = [
    [-3.8, -32, 0, 'offroader'],
    [3.8, 38, Math.PI, 'motorcycle'],
    [-54, 3.6, Math.PI / 2, 'offroader'],
    [58, -3.6, -Math.PI / 2, 'motorcycle'],
    [3.8, -82, 0.15, 'offroader'],
    [-3.8, 86, Math.PI - 0.1, 'offroader'],
    [-96, -3.6, Math.PI / 2, 'motorcycle'],
    [98, 3.6, -Math.PI / 2, 'offroader'],
  ];
  vCoords.forEach(([vx, vz, rot, kind]) => {
    const vy = groundHeightAt(vx, vz);
    if (vy >= cfg.waterLevel + 0.4) {
      vehicleSpawnPoints.push({ x: vx, y: vy, z: vz, rot, kind });
    }
  });

  return {
    worldRadius,
    groundHeightAt,
    colliders,
    buildingsMeta,
    lootSpawnPoints,
    vehicleSpawnPoints,
    treePositions,
    dispose: () => {
      disposables.forEach((d) => d.dispose());
    },
  };
}
