import * as THREE from 'three';

export interface HumanCharacterTextures {
  faceMap: THREE.CanvasTexture;
  faceBumpMap: THREE.CanvasTexture;
  shirtMap: THREE.CanvasTexture;
  shirtBumpMap: THREE.CanvasTexture;
  pantsMap: THREE.CanvasTexture;
  pantsBumpMap: THREE.CanvasTexture;
}

let cachedTextures: HumanCharacterTextures | null = null;

function createCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  return [c, ctx];
}

function makeTex(
  canvas: HTMLCanvasElement,
  isColor: boolean,
  repeatX = 1,
  repeatY = 1,
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = 4;
  tex.needsUpdate = true;
  return tex;
}

export function getHumanCharacterTextures(): HumanCharacterTextures {
  if (cachedTextures) return cachedTextures;

  // 1. Anatomically Aligned Human Face Map (UV u=0.5 is Front -Z when sphere rotated +PI/2)
  const [faceC, fCtx] = createCanvas(512, 512);
  const [faceBC, fbCtx] = createCanvas(512, 512);

  // Base warm human skin tone
  const skinGrad = fCtx.createLinearGradient(0, 60, 0, 480);
  skinGrad.addColorStop(0, '#c89270');
  skinGrad.addColorStop(0.5, '#d39b78');
  skinGrad.addColorStop(1, '#b67d5d');
  fCtx.fillStyle = skinGrad;
  fCtx.fillRect(0, 0, 512, 512);

  fbCtx.fillStyle = '#808080';
  fbCtx.fillRect(0, 0, 512, 512);

  // Subtle pore grain across skin
  for (let i = 0; i < 3500; i++) {
    const x = Math.random() * 512;
    const y = 140 + Math.random() * 320;
    const v = Math.random() > 0.5 ? 'rgba(255,230,210,0.06)' : 'rgba(95,55,35,0.06)';
    fCtx.fillStyle = v;
    fCtx.fillRect(x, y, 2, 2);
    fbCtx.fillStyle = Math.random() > 0.5 ? 'rgba(155,155,155,0.18)' : 'rgba(105,105,105,0.18)';
    fbCtx.fillRect(x, y, 2, 2);
  }

  // Cheek warmth & cheekbone contour (u = 0.5 +/- 0.085 -> x = 256 +/- 44)
  [-44, 44].forEach((dx) => {
    const cheek = fCtx.createRadialGradient(256 + dx, 290, 4, 256 + dx, 290, 36);
    cheek.addColorStop(0, 'rgba(195, 100, 82, 0.24)');
    cheek.addColorStop(1, 'rgba(195, 100, 82, 0)');
    fCtx.fillStyle = cheek;
    fCtx.beginPath();
    fCtx.arc(256 + dx, 290, 36, 0, Math.PI * 2);
    fCtx.fill();
  });

  // Eye socket subtle natural shadow
  [-28, 28].forEach((dx) => {
    const sock = fCtx.createRadialGradient(256 + dx, 244, 3, 256 + dx, 244, 26);
    sock.addColorStop(0, 'rgba(110, 65, 45, 0.34)');
    sock.addColorStop(1, 'rgba(110, 65, 45, 0)');
    fCtx.fillStyle = sock;
    fCtx.beginPath();
    fCtx.arc(256 + dx, 244, 26, 0, Math.PI * 2);
    fCtx.fill();
  });

  // Realistic Eyes (Sclera, Hazel/Dark Brown Iris, Pupil, Upper Eyelid & Catchlight)
  [-27, 27].forEach((dx) => {
    const ex = 256 + dx;
    const ey = 246;

    // Sclera almond
    fCtx.fillStyle = '#ede7e1';
    fCtx.beginPath();
    fCtx.ellipse(ex, ey, 11.5, 5.2, 0, 0, Math.PI * 2);
    fCtx.fill();

    // Iris
    fCtx.fillStyle = '#4a3122';
    fCtx.beginPath();
    fCtx.arc(ex, ey, 4.6, 0, Math.PI * 2);
    fCtx.fill();

    // Limbal ring
    fCtx.strokeStyle = '#241710';
    fCtx.lineWidth = 1.2;
    fCtx.stroke();

    // Pupil
    fCtx.fillStyle = '#0d0b0a';
    fCtx.beginPath();
    fCtx.arc(ex, ey, 2.3, 0, Math.PI * 2);
    fCtx.fill();

    // Catchlight
    fCtx.fillStyle = '#ffffff';
    fCtx.beginPath();
    fCtx.arc(ex - 1.4, ey - 1.4, 1.0, 0, Math.PI * 2);
    fCtx.fill();

    // Upper lash & eyelid crease
    fCtx.strokeStyle = '#2c1c14';
    fCtx.lineWidth = 2.4;
    fCtx.beginPath();
    fCtx.moveTo(ex - 12, ey + 0.5);
    fCtx.quadraticCurveTo(ex, ey - 6.8, ex + 12, ey + 0.5);
    fCtx.stroke();

    fCtx.strokeStyle = 'rgba(115, 70, 48, 0.55)';
    fCtx.lineWidth = 1.3;
    fCtx.beginPath();
    fCtx.moveTo(ex - 10, ey - 4.5);
    fCtx.quadraticCurveTo(ex, ey - 9.5, ex + 10, ey - 4.5);
    fCtx.stroke();

    // Natural Eyebrow
    const dir = dx < 0 ? -1 : 1;
    fCtx.strokeStyle = '#1e1814';
    fCtx.lineWidth = 4.2;
    fCtx.lineCap = 'round';
    fCtx.beginPath();
    fCtx.moveTo(ex - dir * 10, ey - 14);
    fCtx.quadraticCurveTo(ex + dir * 2, ey - 19, ex + dir * 15, ey - 13);
    fCtx.stroke();
  });

  // Nose bridge highlight & nostril shadows
  const noseHighlight = fCtx.createLinearGradient(250, 240, 262, 240);
  noseHighlight.addColorStop(0, 'rgba(140, 90, 65, 0.16)');
  noseHighlight.addColorStop(0.5, 'rgba(245, 208, 182, 0.25)');
  noseHighlight.addColorStop(1, 'rgba(140, 90, 65, 0.16)');
  fCtx.fillStyle = noseHighlight;
  fCtx.fillRect(249, 244, 14, 46);

  fCtx.fillStyle = 'rgba(92, 48, 32, 0.52)';
  fCtx.beginPath();
  fCtx.ellipse(250, 291, 3.2, 2.0, 0.2, 0, Math.PI * 2);
  fCtx.ellipse(262, 291, 3.2, 2.0, -0.2, 0, Math.PI * 2);
  fCtx.fill();

  // Philtrum & Lips
  fCtx.fillStyle = 'rgba(120, 72, 54, 0.25)';
  fCtx.fillRect(254, 294, 4, 14);

  // Upper lip
  fCtx.fillStyle = '#9b5c50';
  fCtx.beginPath();
  fCtx.moveTo(239, 315);
  fCtx.quadraticCurveTo(250, 309, 256, 312);
  fCtx.quadraticCurveTo(262, 309, 273, 315);
  fCtx.quadraticCurveTo(256, 317, 239, 315);
  fCtx.fill();

  // Lip parting line
  fCtx.strokeStyle = '#5c2d26';
  fCtx.lineWidth = 1.6;
  fCtx.beginPath();
  fCtx.moveTo(239, 315.5);
  fCtx.quadraticCurveTo(256, 317.5, 273, 315.5);
  fCtx.stroke();

  // Lower lip
  fCtx.fillStyle = '#ad6c5e';
  fCtx.beginPath();
  fCtx.moveTo(241, 316.5);
  fCtx.quadraticCurveTo(256, 326, 271, 316.5);
  fCtx.quadraticCurveTo(256, 318.5, 241, 316.5);
  fCtx.fill();

  // Subtle tactical jawline stubble / beard shadow
  const stubbleGrad = fCtx.createLinearGradient(0, 315, 0, 415);
  stubbleGrad.addColorStop(0, 'rgba(35, 26, 22, 0)');
  stubbleGrad.addColorStop(0.35, 'rgba(35, 26, 22, 0.14)');
  stubbleGrad.addColorStop(1, 'rgba(35, 26, 22, 0.22)');
  fCtx.fillStyle = stubbleGrad;
  fCtx.fillRect(185, 315, 142, 100);

  // Hair covering crown, back, and sideburns (top of texture & wrap edges u<0.31, u>0.69)
  fCtx.fillStyle = '#1b1714';
  fCtx.fillRect(0, 0, 512, 175);
  // Back of head hair extends further down
  fCtx.fillRect(0, 175, 152, 195);
  fCtx.fillRect(360, 175, 152, 195);
  // Natural irregular hairline on forehead
  fCtx.beginPath();
  fCtx.moveTo(150, 175);
  fCtx.quadraticCurveTo(256, 198, 362, 175);
  fCtx.lineTo(362, 155);
  fCtx.lineTo(150, 155);
  fCtx.closePath();
  fCtx.fill();

  // Hair strand bump lines
  fbCtx.strokeStyle = '#a8a8a8';
  fbCtx.lineWidth = 2;
  for (let i = 0; i < 400; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 185;
    fbCtx.beginPath();
    fbCtx.moveTo(x, y);
    fbCtx.lineTo(x + (Math.random() - 0.5) * 4, y + 14);
    fbCtx.stroke();
  }

  // 2. Crisp Tactical Shirt Fabric Map (cotton weave + folds + button placket + pockets)
  const [shirtC, sCtx] = createCanvas(512, 512);
  const [shirtBC, sbCtx] = createCanvas(512, 512);

  sCtx.fillStyle = '#e7e5de';
  sCtx.fillRect(0, 0, 512, 512);
  sbCtx.fillStyle = '#808080';
  sbCtx.fillRect(0, 0, 512, 512);

  // Subtle cotton weave grid
  sCtx.strokeStyle = 'rgba(180, 176, 168, 0.22)';
  sCtx.lineWidth = 1;
  sbCtx.strokeStyle = 'rgba(155, 155, 155, 0.35)';
  sbCtx.lineWidth = 1;
  for (let i = 0; i < 512; i += 4) {
    sCtx.beginPath();
    sCtx.moveTo(i, 0);
    sCtx.lineTo(i, 512);
    sCtx.stroke();
    sbCtx.beginPath();
    sbCtx.moveTo(0, i);
    sbCtx.lineTo(512, i);
    sbCtx.stroke();
  }

  // Diagonal fabric folds / tension creases
  for (let i = 0; i < 24; i++) {
    const y0 = 60 + i * 18;
    const x0 = Math.random() * 400;
    sCtx.strokeStyle = i % 2 === 0 ? 'rgba(150,145,135,0.22)' : 'rgba(255,255,255,0.38)';
    sCtx.lineWidth = 3 + Math.random() * 4;
    sCtx.beginPath();
    sCtx.moveTo(x0, y0);
    sCtx.quadraticCurveTo(x0 + 55, y0 + 10, x0 + 115, y0 - 8);
    sCtx.stroke();

    sbCtx.strokeStyle = i % 2 === 0 ? 'rgba(95,95,95,0.5)' : 'rgba(165,165,165,0.5)';
    sbCtx.lineWidth = 3;
    sbCtx.beginPath();
    sbCtx.moveTo(x0, y0);
    sbCtx.quadraticCurveTo(x0 + 55, y0 + 10, x0 + 115, y0 - 8);
    sbCtx.stroke();
  }

  // Center front button placket & chest pockets (aligned to front UV region)
  sCtx.fillStyle = 'rgba(215, 212, 204, 0.85)';
  sCtx.fillRect(247, 0, 18, 512);
  sCtx.strokeStyle = 'rgba(155, 150, 142, 0.6)';
  sCtx.lineWidth = 1.5;
  sCtx.strokeRect(247, 0, 18, 512);

  // Shirt buttons
  for (let by = 52; by < 460; by += 68) {
    sCtx.fillStyle = '#cbc7bd';
    sCtx.beginPath();
    sCtx.arc(256, by, 4.5, 0, Math.PI * 2);
    sCtx.fill();
    sCtx.strokeStyle = '#8b867d';
    sCtx.lineWidth = 1;
    sCtx.stroke();
  }

  // Two chest pockets with flaps
  [184, 286].forEach((px) => {
    sCtx.strokeStyle = 'rgba(150, 145, 136, 0.7)';
    sCtx.lineWidth = 2;
    sCtx.strokeRect(px, 145, 44, 54);
    sCtx.fillStyle = 'rgba(222, 219, 212, 0.85)';
    sCtx.fillRect(px - 1, 145, 46, 16);
    sCtx.strokeRect(px - 1, 145, 46, 16);
  });

  // Subtle lower-hem battle dust/grit gradient
  const grit = sCtx.createLinearGradient(0, 380, 0, 512);
  grit.addColorStop(0, 'rgba(92, 82, 68, 0)');
  grit.addColorStop(1, 'rgba(92, 82, 68, 0.24)');
  sCtx.fillStyle = grit;
  sCtx.fillRect(0, 380, 512, 132);

  // 3. Tactical Denim Jeans Texture
  const [pantsC, pCtx] = createCanvas(512, 512);
  const [pantsBC, pbCtx] = createCanvas(512, 512);

  pCtx.fillStyle = '#1f2b38';
  pCtx.fillRect(0, 0, 512, 512);
  pbCtx.fillStyle = '#808080';
  pbCtx.fillRect(0, 0, 512, 512);

  // Diagonal denim twill weave
  pCtx.strokeStyle = 'rgba(255, 255, 255, 0.045)';
  pCtx.lineWidth = 1;
  pbCtx.strokeStyle = 'rgba(152, 152, 152, 0.35)';
  pbCtx.lineWidth = 1;
  for (let i = -512; i < 1024; i += 5) {
    pCtx.beginPath();
    pCtx.moveTo(i, 0);
    pCtx.lineTo(i + 512, 512);
    pCtx.stroke();
    pbCtx.beginPath();
    pbCtx.moveTo(i, 0);
    pbCtx.lineTo(i + 512, 512);
    pbCtx.stroke();
  }

  // Worn thigh & knee wash highlights + creases
  const kneeWash = pCtx.createRadialGradient(256, 250, 20, 256, 250, 175);
  kneeWash.addColorStop(0, 'rgba(120, 148, 175, 0.16)');
  kneeWash.addColorStop(1, 'rgba(120, 148, 175, 0)');
  pCtx.fillStyle = kneeWash;
  pCtx.fillRect(0, 80, 512, 340);

  // Stitching seams
  pCtx.strokeStyle = 'rgba(186, 145, 88, 0.55)';
  pCtx.lineWidth = 2;
  pCtx.setLineDash([6, 4]);
  pCtx.beginPath();
  pCtx.moveTo(128, 0);
  pCtx.lineTo(128, 512);
  pCtx.moveTo(384, 0);
  pCtx.lineTo(384, 512);
  pCtx.stroke();
  pCtx.setLineDash([]);

  cachedTextures = {
    faceMap: makeTex(faceC, true),
    faceBumpMap: makeTex(faceBC, false),
    shirtMap: makeTex(shirtC, true),
    shirtBumpMap: makeTex(shirtBC, false),
    pantsMap: makeTex(pantsC, true),
    pantsBumpMap: makeTex(pantsBC, false),
  };

  return cachedTextures;
}
