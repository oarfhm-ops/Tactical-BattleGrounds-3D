import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { soundEngine } from './audio';
import { ProximityVoiceManager } from './voiceChat';
import {
  buildAirdropCrate,
  buildCharacterModel,
  buildPlaneModel,
  buildVehicleModel,
  buildWeaponMesh,
  type BuildingCollider,
  type CharacterVisualRefs,
  type VehicleVisualRefs,
} from './models';
import { buildMapWorld, type WorldTerrainData } from './terrain';
import { createBiomeTextures, createRadialShadowTexture, type BiomeTextures } from './textures';
import type {
  AmmoType,
  GameMode,
  GamePhase,
  GameSettings,
  HudSnapshot,
  KillfeedEntry,
  LootItem,
  MapId,
  MedType,
  MinimapBlip,
  MuzzleType,
  NetworkMode,
  PerspectiveMode,
  ScopeType,
  StanceMode,
  ThrowableType,
  WeaponInstance,
} from './types';
import {
  AMMO_LABELS,
  MAP_CONFIGS,
  MED_INFO,
  SCOPE_INFO,
  THROWABLE_INFO,
  WEAPONS,
  WORLD_SPAWN_WEAPON_IDS,
} from './weaponsData';

const BOT_NAMES = [
  'صقر الصحراء',
  'الذئب الأسود',
  'رعد الشمال',
  'شبح القمة',
  'فارس الليل',
  'نسر الجبال',
  'عاصفة الرمل',
  'قناص الوادي',
  'صائد الظلال',
  'ليث الميدان',
  'برق الجنوب',
  'حارس القلعة',
  'كاسر الحصار',
  'سيف البقاء',
  'نمر الأدغال',
  'طيف الجليد',
  'شهاب الغروب',
  'مقدام',
  'الرامي الحر',
  'باسل',
  'يزن التكتيكي',
  'طارق السريع',
  'راكان',
  'سالم',
  'نايف',
  'تميم',
  'مازن',
  'فيصل',
  'خالد',
  'عمران',
];

// Pre-allocated scratch math objects (Zero GC in render loop)
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _v4 = new THREE.Vector3();
const _q1 = new THREE.Quaternion();
const _euler = new THREE.Euler(0, 0, 0, 'YXZ');

interface Projectile {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  ownerId: string;
  teamId: number;
  weaponId: string;
  damage: number;
  headshotMult: number;
  life: number;
  isFlare: boolean;
  mesh: THREE.Mesh;
}

interface ThrownObject {
  type: ThrowableType;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  fuse: number;
  ownerId: string;
  mesh: THREE.Mesh;
}

interface SmokeCloud {
  pos: THREE.Vector3;
  radius: number;
  life: number;
  group: THREE.Group;
}

interface FirePool {
  pos: THREE.Vector3;
  radius: number;
  life: number;
  tickTimer: number;
  mesh: THREE.Mesh;
}

interface ParticleBurst {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  mesh: THREE.Mesh;
}

interface ActiveVehicle {
  id: string;
  kind: 'offroader' | 'motorcycle';
  nameAr: string;
  pos: THREE.Vector3;
  yaw: number;
  speed: number;
  hp: number;
  maxHp: number;
  fuel: number;
  driverId: string | null;
  vfxTimer: number;
  visual: VehicleVisualRefs;
}

interface MuzzleFlashBurst {
  mesh: THREE.Group;
  life: number;
  maxLife: number;
}

interface ImpactDecal {
  mesh: THREE.Mesh;
  life: number;
}

interface VehicleSmokePuff {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  startScale: number;
  endScale: number;
}

interface ShellCasing {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  spin: THREE.Vector3;
  life: number;
}

interface ActiveAirdrop {
  pos: THREE.Vector3;
  landed: boolean;
  looted: boolean;
  crate: { root: THREE.Group; chute: THREE.Group };
  smokeTimer: number;
}

interface Combatant {
  id: string;
  name: string;
  isPlayer: boolean;
  teamId: number;
  alive: boolean;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  yaw: number;
  pitch: number;
  health: number;
  maxHealth: number;
  boost: number;
  helmetLevel: 0 | 1 | 2 | 3;
  helmetDurability: number;
  vestLevel: 0 | 1 | 2 | 3;
  vestDurability: number;
  backpackLevel: 0 | 1 | 2 | 3;
  hasPan: boolean;
  hasGhillie: boolean;
  stance: StanceMode;
  lean: -1 | 0 | 1;
  weapons: [WeaponInstance | null, WeaponInstance | null, WeaponInstance | null];
  activeSlot: 0 | 1 | 2;
  fireCooldown: number;
  aiTargetPos: THREE.Vector3;
  aiThinkTimer: number;
  aiStrafeDir: number;
  aiBurstCount: number;
  visual: CharacterVisualRefs;
  contactShadow: THREE.Mesh;
  heldWeaponName: string;
}

interface LootVisualEntry {
  item: LootItem;
  mesh: THREE.Group;
}

export class BattleRoyaleEngine {
  private container: HTMLElement;
  private onHudUpdate: (snap: HudSnapshot) => void;

  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private composer: EffectComposer | null = null;
  private bloomPass: UnrealBloomPass | null = null;
  private isSoftwareGl = false;
  private maxAnisotropy = 1;
  private currentShadowRes = 0;
  private renderResolution = { width: 1280, height: 720, is4k: false };

  private frameId = 0;
  private clock = new THREE.Clock();
  private disposed = false;
  private lastFrameAt = 0;
  private fpsFrames = 0;
  private fpsAccum = 0;
  private liveFps = 60;

  private mapId: MapId = 'classic';
  private mode: GameMode = 'solo';
  private networkMode: NetworkMode = 'offline';
  private roomCode = 'ROOM1';
  private hostingRoom = false;
  private playerName = 'أنت';
  private fillWithBots = true;
  private hadRemoteOpponent = false;
  private settings: GameSettings;
  private phase: GamePhase = 'menu';

  private world: WorldTerrainData | null = null;
  private textures: BiomeTextures | null = null;
  private shadowTex!: THREE.CanvasTexture;
  private impactDecalTex!: THREE.CanvasTexture;
  private smokePuffTex!: THREE.CanvasTexture;
  private envRT: THREE.WebGLRenderTarget | null = null;

  private sunLight!: THREE.DirectionalLight;
  private hemiLight!: THREE.HemisphereLight;
  private rimLight!: THREE.DirectionalLight;

  // Match entities
  private combatants: Combatant[] = [];
  private player!: Combatant;
  private vehicles: ActiveVehicle[] = [];
  private lootEntries: LootVisualEntry[] = [];
  private projectiles: Projectile[] = [];
  private thrownObjects: ThrownObject[] = [];
  private smokeClouds: SmokeCloud[] = [];
  private firePools: FirePool[] = [];
  private particles: ParticleBurst[] = [];
  private muzzleFlashes: MuzzleFlashBurst[] = [];
  private impactDecals: ImpactDecal[] = [];
  private smokePuffs: VehicleSmokePuff[] = [];
  private shellCasings: ShellCasing[] = [];
  private airdrops: ActiveAirdrop[] = [];
  public voice = new ProximityVoiceManager();
  private remotePeerVisuals = new Map<
    string,
    { visual: CharacterVisualRefs; ring: THREE.Mesh; heldWeaponId: string }
  >();

  // Plane & Skydiving
  private transportPlane: { root: THREE.Group; props: THREE.Group[] } | null = null;
  private planeStart = new THREE.Vector3();
  private planeEnd = new THREE.Vector3();
  private planeProgress = 0;
  private parachuteOpen = false;

  // FPP Weapon Viewmodel
  private fppMount = new THREE.Group();
  private fppWeaponMesh: THREE.Group | null = null;
  private fppMuzzleFlash: THREE.Group | null = null;
  private fppWeaponKey = '';
  private fppRecoilOffset = 0;
  private fppBobTime = 0;
  private muzzleLight!: THREE.PointLight;
  private muzzleFlashTimer = 0;

  // Bluezone & Redzone
  private blueZoneMesh!: THREE.Mesh;
  private safeZone = { x: 0, z: 0, r: 220 };
  private nextZone = { x: 0, z: 0, r: 140 };
  private startZone = { x: 0, z: 0, r: 220 };
  private zonePhase = 1;
  private zoneTimerSec = 32;
  private zoneShrinking = false;
  private redZone: { x: number; z: number; r: number } | null = null;
  private redZoneTimer = 28;
  private redZoneBombTimer = 0;
  private airdropTimer = 24;
  private airdropAnnounce: string | null = null;
  private airdropAnnounceTimer = 0;

  // Rain weather particles
  private rainPoints: THREE.Points | null = null;
  private weatherTime = 0;
  private weatherLabel = 'سماء صافية';

  // Player state & inventory
  private perspective: PerspectiveMode = 'tpp';
  private isAds = false;
  private currentFov = 70;
  private currentCamPos = new THREE.Vector3(0, 25, 45);
  private currentCamLook = new THREE.Vector3(0, 2, 0);
  private shakeIntensity = 0;
  private hitstopTimer = 0;
  private hitmarkerTime = 0;
  private hitmarkerHeadshot = false;
  private damageFlashTime = 0;
  private stunFlashAlpha = 0;

  private ammoBag: Record<AmmoType, number> = {
    '5.56mm': 0,
    '7.62mm': 0,
    '9mm': 0,
    '.45': 0,
    '12G': 0,
    '.300': 0,
    bolt: 0,
    flare: 0,
  };
  private meds: Record<MedType, number> = {
    bandage: 3,
    firstaid: 0,
    medkit: 0,
    energy: 1,
    painkiller: 0,
  };
  private throwables: Record<ThrowableType, number> = {
    frag: 1,
    smoke: 1,
    molotov: 0,
    stun: 0,
  };
  private activeThrowable: ThrowableType = 'frag';
  private spareScopes: ScopeType[] = [];
  private spareMuzzles: MuzzleType[] = [];
  private spareExtMags = 0;

  private isReloading = false;
  private reloadTimer = 0;
  private reloadDuration = 2.0;

  private isUsingMed = false;
  private medUseType: MedType = 'bandage';
  private medUseTimer = 0;
  private medUseDuration = 1.8;

  private kills = 0;
  private headshots = 0;
  private damageDealt = 0;
  private distanceTraveledMeters = 0;
  private lastPlayerPos = new THREE.Vector3();
  private lootCollected = {
    total: 0,
    weapons: 0,
    armor: 0,
    meds: 0,
    ammoAndMods: 0,
  };
  private survivalTimeSec = 0;
  private playerRank = 1;
  private killfeed: KillfeedEntry[] = [];
  private killfeedSeq = 1;
  private inVehicle: ActiveVehicle | null = null;
  private stepTimer = 0;
  private hudEmitTimer = 0;
  private menuOrbitAngle = 0;
  private lobbyShowcaseGroup: THREE.Group | null = null;
  private lobbyHero: CharacterVisualRefs | null = null;
  private lobbyFlames: Array<{
    mesh: THREE.Mesh;
    baseScale: number;
    phase: number;
    speed: number;
    baseY: number;
  }> = [];
  private lobbyFireLight: THREE.PointLight | null = null;
  private lobbyDragYaw = 0;
  private lobbyDragging = false;

  // Input state
  private heldKeys = new Set<string>();
  private mouseLeftDown = false;
  private mouseRightDown = false;
  private pointerLocked = false;
  private dragLooking = false;
  private lastPointerX = 0;
  private lastPointerY = 0;

  // Dedicated Android / Multi-Touch input state
  private touchModeEnabled = false;
  private touchMoveX = 0;
  private touchMoveY = 0;
  private touchSprint = false;
  private touchFiring = false;
  private touchVehThrottle = 0;
  private touchVehSteer = 0;
  private touchVehBrake = false;

  // Shared tracer, casing & VFX geometries
  private bulletGeo = new THREE.SphereGeometry(0.06, 6, 6);
  private bulletMat = new THREE.MeshBasicMaterial({ color: 0xffd56b });
  private flareMat = new THREE.MeshBasicMaterial({ color: 0xff3b3b });
  private particleGeo = new THREE.BoxGeometry(0.22, 0.22, 0.22);
  private casingGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.055, 6);
  private casingMat = new THREE.MeshStandardMaterial({
    color: 0xe6b84c,
    metalness: 0.9,
    roughness: 0.22,
  });
  private decalGeo = new THREE.PlaneGeometry(0.28, 0.28);
  private craterGeo = new THREE.PlaneGeometry(2.8, 2.8);
  private smokePuffGeo = new THREE.PlaneGeometry(1, 1);

  constructor(
    container: HTMLElement,
    initialSettings: GameSettings,
    onHudUpdate: (snap: HudSnapshot) => void,
  ) {
    this.container = container;
    this.settings = { ...initialSettings };
    this.onHudUpdate = onHudUpdate;

    this.voice.onPeersChanged = () => {
      if (this.voice.peers.size > 0) {
        this.hadRemoteOpponent = true;
      }
      if (this.phase === 'menu' || this.phase === 'playing' || this.phase === 'plane' || this.phase === 'skydiving') {
        this.emitHud();
      }
    };

    this.voice.onRemoteShoot = (ev) => {
      if (
        this.networkMode === 'offline' ||
        this.phase === 'menu' ||
        this.phase === 'paused' ||
        this.phase === 'victory' ||
        this.phase === 'gameover'
      ) {
        return;
      }
      const def = WEAPONS[ev.weaponId] ?? WEAPONS.m416;
      const origin = new THREE.Vector3(ev.origin.x, ev.origin.y, ev.origin.z);
      const dir = new THREE.Vector3(ev.dir.x, ev.dir.y, ev.dir.z).normalize();
      const mesh = new THREE.Mesh(this.bulletGeo, this.bulletMat);
      mesh.position.copy(origin);
      this.scene.add(mesh);
      this.projectiles.push({
        pos: origin,
        vel: dir.clone().multiplyScalar(def.bulletSpeed),
        ownerId: `remote_${ev.fromId}`,
        teamId: ev.teamId,
        weaponId: def.id,
        damage: 0,
        headshotMult: 1,
        life: Math.min(1.8, def.range / def.bulletSpeed),
        isFlare: false,
        mesh,
      });
      this.spawnMuzzleFlash(origin, dir, Boolean(def.builtInSuppressor));
      if (this.player) {
        const dist = origin.distanceTo(this.player.pos);
        soundEngine.playShot(def.category, false, dist);
      }
    };

    this.voice.onRemoteHit = (ev) => {
      if (
        this.networkMode === 'offline' ||
        !this.player ||
        !this.player.alive ||
        this.phase !== 'playing'
      ) {
        return;
      }
      let dmg = ev.damage;
      if (ev.isHeadshot && this.player.helmetLevel > 0) {
        const red =
          this.player.helmetLevel === 3 ? 0.55 : this.player.helmetLevel === 2 ? 0.4 : 0.3;
        dmg *= 1 - red;
        this.player.helmetDurability = Math.max(0, this.player.helmetDurability - 30);
        if (this.player.helmetDurability <= 0) this.player.helmetLevel = 0;
      } else if (!ev.isHeadshot && this.player.vestLevel > 0) {
        const red = this.player.vestLevel === 3 ? 0.55 : this.player.vestLevel === 2 ? 0.4 : 0.3;
        dmg *= 1 - red;
        this.player.vestDurability = Math.max(0, this.player.vestDurability - 20);
        if (this.player.vestDurability <= 0) this.player.vestLevel = 0;
      }
      const remoteKiller = {
        id: ev.fromId,
        name: ev.fromName,
        isPlayer: false,
        teamId: 999,
      } as Combatant;
      this.applyDamage(this.player, dmg, remoteKiller, ev.weaponName, ev.isHeadshot, this.player.pos);
    };

    this.initRenderer();
    this.initScene();
    this.bindInputs();
    this.loadMapPreview('classic');
    this.startLoop();
  }

  private initRenderer() {
    this.isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas');
        const gl = probe.getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl && this.settings.antiAliasing,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.setSize(this.container.clientWidth || window.innerWidth, this.container.clientHeight || window.innerHeight);
    this.applyQualityToRenderer();

    this.maxAnisotropy = Math.min(8, this.renderer.capabilities.getMaxAnisotropy());
    this.container.innerHTML = '';
    this.container.appendChild(this.renderer.domElement);
  }

  private applyQualityToRenderer() {
    if (!this.renderer) return;
    const q = this.settings.quality;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    const deviceDpr = window.devicePixelRatio || 1;
    // Ultra ("4K UHD") dynamically supersamples up to 3840x2160 on hardware GPUs
    const target4kScale = Math.min(3840 / Math.max(1, w), 2160 / Math.max(1, h));
    const dprCap = this.isSoftwareGl
      ? q === 'smooth'
        ? 0.72
        : q === 'balanced'
          ? 0.88
          : q === 'ultra'
            ? 1.25
            : 1.0
      : q === 'smooth'
        ? 0.78
        : q === 'balanced'
          ? Math.min(deviceDpr, 1.15)
          : q === 'hd'
            ? Math.min(deviceDpr, 1.55)
            : q === 'hdr'
              ? Math.min(deviceDpr, 1.95)
              : Math.min(3.6, Math.max(deviceDpr, target4kScale));

    this.renderer.setPixelRatio(dprCap);
    this.composer?.setPixelRatio(dprCap);

    const outW = Math.round(w * dprCap);
    const outH = Math.round(h * dprCap);
    this.renderResolution = {
      width: outW,
      height: outH,
      is4k: outW >= 3200 || outH >= 1800,
    };

    if (this.camera) {
      const targetFar =
        q === 'smooth'
          ? 300
          : q === 'balanced'
            ? 450
            : q === 'hd'
              ? 640
              : q === 'hdr'
                ? 820
                : 1100;
      if (this.camera.far !== targetFar) {
        this.camera.far = targetFar;
        this.camera.updateProjectionMatrix();
      }
    }

    const shadowsOn = !this.isSoftwareGl && q !== 'smooth';
    this.renderer.shadowMap.enabled = shadowsOn;
    this.renderer.shadowMap.type =
      q === 'balanced' ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap;

    if (this.sunLight) {
      this.sunLight.castShadow = shadowsOn;
      const maxTex = this.renderer.capabilities.maxTextureSize || 2048;
      const desiredRes =
        q === 'smooth'
          ? 512
          : q === 'balanced'
            ? 1024
            : q === 'hd' || q === 'hdr'
              ? Math.min(2048, maxTex)
              : Math.min(4096, maxTex);
      if (this.currentShadowRes !== desiredRes) {
        this.currentShadowRes = desiredRes;
        this.sunLight.shadow.mapSize.set(desiredRes, desiredRes);
        if (this.sunLight.shadow.map) {
          this.sunLight.shadow.map.dispose();
          this.sunLight.shadow.map = null;
        }
        this.sunLight.shadow.needsUpdate = true;
      }
    }

    if (this.hemiLight) {
      this.hemiLight.intensity =
        q === 'smooth' ? 0.96 : q === 'balanced' ? 0.8 : q === 'hd' ? 0.7 : q === 'hdr' ? 0.64 : 0.58;
    }

    if (this.rimLight) {
      this.rimLight.intensity =
        q === 'smooth' ? 0.16 : q === 'balanced' ? 0.42 : q === 'hd' ? 0.68 : q === 'hdr' ? 0.94 : 1.2;
    }

    if (this.bloomPass) {
      if (!this.isSoftwareGl && q === 'hdr') {
        this.bloomPass.enabled = true;
        this.bloomPass.strength = 0.28;
        this.bloomPass.radius = 0.46;
        this.bloomPass.threshold = 0.8;
      } else if (!this.isSoftwareGl && q === 'ultra') {
        this.bloomPass.enabled = true;
        this.bloomPass.strength = 0.42;
        this.bloomPass.radius = 0.62;
        this.bloomPass.threshold = 0.72;
      } else {
        this.bloomPass.enabled = false;
      }
    }

    if (this.scene) {
      const envIntensity =
        q === 'smooth' ? 0.28 : q === 'balanced' ? 0.65 : q === 'hd' ? 1.05 : q === 'hdr' ? 1.45 : 1.85;
      this.scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (!mesh.isMesh) return;
        const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        for (const m of mats) {
          if (m && 'envMapIntensity' in m) {
            (m as THREE.MeshStandardMaterial).envMapIntensity = envIntensity;
          }
        }
      });
    }

    const style = this.settings.style;
    const baseExp =
      style === 'colorful'
        ? 1.18
        : style === 'movie'
          ? 0.98
          : style === 'realistic'
            ? 1.05
            : style === 'soft'
              ? 1.12
              : 1.09;
    const qExp =
      q === 'smooth' ? 0.92 : q === 'balanced' ? 1.0 : q === 'hd' ? 1.05 : q === 'hdr' ? 1.12 : 1.18;
    this.renderer.toneMappingExposure = baseExp * qExp;
  }

  private initScene() {
    this.scene = new THREE.Scene();
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera = new THREE.PerspectiveCamera(70, w / h, 0.15, 720);
    this.scene.add(this.camera);

    // Attach FPP mount & muzzle flash light to camera
    this.camera.add(this.fppMount);
    this.fppMount.visible = false;
    this.muzzleLight = new THREE.PointLight(0xffb44c, 0, 12);
    this.muzzleLight.position.set(0.18, -0.1, -0.9);
    this.camera.add(this.muzzleLight);

    // Mandatory RoomEnvironment IBL
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const roomEnv = new RoomEnvironment();
    const envTex = pmrem.fromScene(roomEnv, 0.04).texture;
    this.scene.environment = envTex;
    roomEnv.dispose();
    pmrem.dispose();

    this.shadowTex = createRadialShadowTexture();
    this.impactDecalTex = this.createImpactDecalTexture();
    this.smokePuffTex = this.createSmokePuffTexture();

    // 3-Point Outdoor Tactical Lighting Rig
    this.hemiLight = new THREE.HemisphereLight(0x9ac6eb, 0x3b4d2b, 0.72);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff0d4, 2.1);
    this.sunLight.position.set(65, 95, 50);
    this.sunLight.castShadow = !this.isSoftwareGl;
    this.sunLight.shadow.mapSize.set(2048, 2048);
    const d = 85;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.camera.near = 5;
    this.sunLight.shadow.camera.far = 260;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.02;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    this.rimLight = new THREE.DirectionalLight(0x88b4e6, 0.55);
    this.rimLight.position.set(-70, 45, -65);
    this.scene.add(this.rimLight);

    // Bluezone energy wall cylinder
    const bzGeo = new THREE.CylinderGeometry(1, 1, 130, 64, 1, true);
    const bzMat = new THREE.MeshBasicMaterial({
      color: 0x2288ff,
      transparent: true,
      opacity: 0.28,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.blueZoneMesh = new THREE.Mesh(bzGeo, bzMat);
    this.blueZoneMesh.position.y = 45;
    this.scene.add(this.blueZoneMesh);

    if (!this.isSoftwareGl) {
      this.composer = new EffectComposer(this.renderer);
      this.composer.addPass(new RenderPass(this.scene, this.camera));
      this.bloomPass = new UnrealBloomPass(new THREE.Vector2(w, h), 0.26, 0.45, 0.84);
      this.bloomPass.enabled = false;
      this.composer.addPass(this.bloomPass);
      this.composer.addPass(new OutputPass());
      this.renderer.compile(this.scene, this.camera);
    }

    this.applyQualityToRenderer();
  }

  public updateSettings(next: GameSettings) {
    this.settings = { ...next };
    soundEngine.setMuted(next.muted);
    soundEngine.quality = next.audioQuality;
    this.applyQualityToRenderer();
    this.applyBiomeAtmosphere();
    this.emitHud();
  }

  public setLobbyNetworkConfig(
    networkMode: NetworkMode,
    roomCode: string,
    playerName: string,
    fillWithBots: boolean,
    hostingRoom = false,
  ) {
    this.networkMode = networkMode;
    this.roomCode = (roomCode || 'ROOM1').trim().toUpperCase().slice(0, 12) || 'ROOM1';
    this.playerName = playerName.trim() || 'أنت';
    this.fillWithBots = fillWithBots;
    this.hostingRoom = networkMode === 'local' ? hostingRoom : false;
    this.voice.joinLobbyRoom(
      this.networkMode,
      this.roomCode,
      this.mapId,
      this.mode,
      this.playerName,
      this.hostingRoom,
    );
    this.emitHud();
  }

  private applyBiomeAtmosphere() {
    const cfg = MAP_CONFIGS[this.mapId];
    const style = this.settings.style;
    const q = this.settings.quality;
    const sky = new THREE.Color(cfg.skyColor);
    const fog = new THREE.Color(cfg.fogColor);
    let fogScale = 1.0;

    if (style === 'movie') {
      sky.multiplyScalar(0.8);
      fog.multiplyScalar(0.78);
      fogScale = 1.15;
    } else if (style === 'colorful') {
      sky.offsetHSL(0, 0.1, 0.03);
      fog.offsetHSL(0, 0.08, 0.02);
      fogScale = 0.9;
    } else if (style === 'realistic') {
      sky.offsetHSL(0, -0.05, -0.02);
      fog.offsetHSL(0, -0.04, -0.02);
    } else if (style === 'soft') {
      sky.lerp(new THREE.Color(0xdbe8f0), 0.16);
      fog.lerp(new THREE.Color(0xdbe8f0), 0.18);
      fogScale = 0.88;
    }

    const qFogMult =
      q === 'smooth'
        ? 1.42
        : q === 'balanced'
          ? 1.08
          : q === 'hd'
            ? 0.84
            : q === 'hdr'
              ? 0.7
              : 0.56;
    fogScale *= qFogMult;

    this.scene.background = sky;
    this.scene.fog = new THREE.FogExp2(fog.getHex(), cfg.fogDensity * fogScale);
    this.sunLight.color.setHex(cfg.sunColor);
    this.sunLight.intensity =
      cfg.sunIntensity *
      (q === 'smooth'
        ? 0.82
        : q === 'balanced'
          ? 1.0
          : q === 'hd'
            ? 1.15
            : q === 'hdr'
              ? 1.28
              : 1.42);
    this.hemiLight.color.setHex(cfg.hemiSky);
    this.hemiLight.groundColor.setHex(cfg.hemiGround);
  }

  private clearWorldEntities() {
    this.combatants.forEach((c) => {
      this.scene.remove(c.visual.root);
      this.scene.remove(c.contactShadow);
    });
    this.combatants = [];

    this.vehicles.forEach((v) => this.scene.remove(v.visual.root));
    this.vehicles = [];

    this.lootEntries.forEach((l) => this.scene.remove(l.mesh));
    this.lootEntries = [];

    this.projectiles.forEach((p) => this.scene.remove(p.mesh));
    this.projectiles = [];

    this.thrownObjects.forEach((t) => this.scene.remove(t.mesh));
    this.thrownObjects = [];

    this.smokeClouds.forEach((s) => this.scene.remove(s.group));
    this.smokeClouds = [];

    this.firePools.forEach((f) => this.scene.remove(f.mesh));
    this.firePools = [];

    this.particles.forEach((pt) => this.scene.remove(pt.mesh));
    this.particles = [];

    this.muzzleFlashes.forEach((mf) => this.scene.remove(mf.mesh));
    this.muzzleFlashes = [];

    this.impactDecals.forEach((dc) => {
      this.scene.remove(dc.mesh);
      (dc.mesh.material as THREE.Material).dispose();
    });
    this.impactDecals = [];

    this.smokePuffs.forEach((sp) => {
      this.scene.remove(sp.mesh);
      (sp.mesh.material as THREE.Material).dispose();
    });
    this.smokePuffs = [];

    this.shellCasings.forEach((sc) => this.scene.remove(sc.mesh));
    this.shellCasings = [];

    this.airdrops.forEach((a) => this.scene.remove(a.crate.root));
    this.airdrops = [];

    this.remotePeerVisuals.forEach((rv) => this.scene.remove(rv.visual.root));
    this.remotePeerVisuals.clear();

    if (this.transportPlane) {
      this.scene.remove(this.transportPlane.root);
      this.transportPlane = null;
    }

    if (this.lobbyShowcaseGroup) {
      this.scene.remove(this.lobbyShowcaseGroup);
      this.lobbyShowcaseGroup = null;
    }
    this.lobbyHero = null;
    this.lobbyFlames = [];
    this.lobbyFireLight = null;

    if (this.rainPoints) {
      this.scene.remove(this.rainPoints);
      this.rainPoints.geometry.dispose();
      (this.rainPoints.material as THREE.Material).dispose();
      this.rainPoints = null;
    }

    // Remove static world meshes cleanly except lights, camera, and bluezone
    const keep = new Set<THREE.Object3D>([
      this.camera,
      this.hemiLight,
      this.sunLight,
      this.sunLight.target,
      this.rimLight,
      this.blueZoneMesh,
    ]);
    for (let i = this.scene.children.length - 1; i >= 0; i--) {
      const ch = this.scene.children[i];
      if (!keep.has(ch)) {
        this.scene.remove(ch);
      }
    }

    this.world?.dispose();
    this.world = null;
    if (this.textures) {
      this.textures.groundMap.dispose();
      this.textures.wallMap.dispose();
      this.textures.roofMap.dispose();
      this.textures.roadMap.dispose();
      this.textures.crateMap.dispose();
      this.textures = null;
    }
  }

  public loadMapPreview(mapId: MapId) {
    this.mapId = mapId;
    this.phase = 'menu';
    this.lobbyDragYaw = 0;
    this.releasePointerLock();
    soundEngine.stopEngine();

    this.clearWorldEntities();
    this.applyBiomeAtmosphere();
    this.textures = createBiomeTextures(mapId, this.maxAnisotropy);
    this.world = buildMapWorld(this.scene, mapId, this.textures);

    this.safeZone = { x: 0, z: 0, r: this.world.worldRadius - 10 };
    this.nextZone = { x: 0, z: 0, r: this.world.worldRadius * 0.65 };
    this.blueZoneMesh.position.set(0, 45, 0);
    this.blueZoneMesh.scale.set(this.safeZone.r, 1, this.safeZone.r);

    // Spawn vehicles on preview so user sees the living world
    this.world.vehicleSpawnPoints.forEach((vp, idx) => {
      const visual = buildVehicleModel(vp.kind);
      visual.root.position.set(vp.x, vp.y, vp.z);
      visual.root.rotation.y = vp.rot;
      this.scene.add(visual.root);
      this.vehicles.push({
        id: `veh_${idx}`,
        kind: vp.kind,
        nameAr: vp.kind === 'offroader' ? 'سيارة دفع رباعي 4x4' : 'دراجة نارية سريعة',
        pos: new THREE.Vector3(vp.x, vp.y, vp.z),
        yaw: vp.rot,
        speed: 0,
        hp: vp.kind === 'offroader' ? 180 : 100,
        maxHp: vp.kind === 'offroader' ? 180 : 100,
        fuel: 100,
        driverId: null,
        vfxTimer: 0,
        visual,
      });
    });

    // Build flyover transport plane for title screen ambience
    this.transportPlane = buildPlaneModel();
    this.transportPlane.root.position.set(0, 74, 0);
    this.scene.add(this.transportPlane.root);

    // Build Iconic 3D Human Warrior Lobby Showcase (matches tactical reference pose & fire backdrop)
    this.buildLobbyShowcase();
    this.applyQualityToRenderer();

    this.emitHud();
  }

  private buildLobbyShowcase() {
    if (!this.world) return;
    const hx = 0;
    const hz = 10;
    const hy = this.world.groundHeightAt(hx, hz);

    const group = new THREE.Group();
    group.position.set(hx, hy, hz);
    this.scene.add(group);
    this.lobbyShowcaseGroup = group;

    // Grounded Contact Shadow under warrior
    const shadow = new THREE.Mesh(
      new THREE.PlaneGeometry(1.7, 1.7),
      new THREE.MeshBasicMaterial({
        map: this.shadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.55,
      }),
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.set(0, 0.03, 0);
    group.add(shadow);

    // Realistic Human Warrior with white collared shirt, tie, harness, dual belts, thigh holster & Lv3 visor helmet
    const hero = buildCharacterModel(0xe5e3dc, false, true);
    hero.helmet3.visible = true;
    hero.root.position.set(0, 0, 0);
    // Character front faces -Z in local space; rotate PI so warrior faces +Z toward the lobby camera
    hero.root.rotation.y = Math.PI;
    hero.rightArm.rotation.set(0.28, 0, -0.14);
    hero.leftArm.rotation.set(0.12, 0, 0.14);
    hero.leftLeg.rotation.z = 0.045;
    hero.rightLeg.rotation.z = -0.045;

    const sidearm = buildWeaponMesh('p18c', 'iron', false);
    sidearm.position.set(0, -0.02, -0.08);
    sidearm.rotation.x = -0.25;
    hero.weaponMount.add(sidearm);
    group.add(hero.root);
    this.lobbyHero = hero;

    // Wrecked tilted offroader vehicle behind & right of warrior
    const wreck = buildVehicleModel('offroader');
    wreck.root.position.set(3.4, 0.25, -4.8);
    wreck.root.rotation.set(0.18, -0.95, -0.28);
    group.add(wreck.root);

    // Tactical barricade crate behind & left
    const crateMat = new THREE.MeshStandardMaterial({
      color: 0x3b352c,
      roughness: 0.85,
      metalness: 0.15,
    });
    const crate = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.85, 0.9), crateMat);
    crate.position.set(-2.9, 0.42, -3.6);
    crate.rotation.y = 0.32;
    crate.castShadow = true;
    crate.receiveShadow = true;
    group.add(crate);

    // Dramatic explosion fireball & smoke plume behind the hero
    const fireCoreMat = new THREE.MeshBasicMaterial({ color: 0xffd275 });
    const fireMidMat = new THREE.MeshBasicMaterial({
      color: 0xff6b1a,
      transparent: true,
      opacity: 0.9,
    });
    const smokeMat = new THREE.MeshStandardMaterial({
      color: 0x262423,
      roughness: 0.98,
      metalness: 0.0,
      transparent: true,
      opacity: 0.82,
    });

    const plumeSpecs = [
      { x: 0.2, y: 1.5, z: -4.6, r: 1.35, mat: fireCoreMat, speed: 4.5 },
      { x: -1.1, y: 1.25, z: -4.9, r: 1.15, mat: fireMidMat, speed: 3.8 },
      { x: 1.4, y: 1.35, z: -4.8, r: 1.25, mat: fireMidMat, speed: 4.1 },
      { x: -0.4, y: 2.35, z: -5.2, r: 1.4, mat: fireMidMat, speed: 3.4 },
      { x: 1.1, y: 2.2, z: -5.4, r: 1.45, mat: smokeMat, speed: 2.1 },
      { x: -1.6, y: 2.0, z: -5.3, r: 1.55, mat: smokeMat, speed: 1.9 },
      { x: 0.1, y: 3.1, z: -5.7, r: 1.8, mat: smokeMat, speed: 1.6 },
    ];

    const puffGeo = new THREE.DodecahedronGeometry(1, 1);
    plumeSpecs.forEach((sp, idx) => {
      const m = new THREE.Mesh(puffGeo, sp.mat);
      m.position.set(sp.x, sp.y, sp.z);
      m.scale.setScalar(sp.r);
      group.add(m);
      this.lobbyFlames.push({
        mesh: m,
        baseScale: sp.r,
        phase: idx * 1.15,
        speed: sp.speed,
        baseY: sp.y,
      });
    });

    // Warm orange explosion rim light illuminating the warrior's silhouette & shirt folds
    const fireLight = new THREE.PointLight(0xff7d29, 14, 24, 1.4);
    fireLight.position.set(0.2, 2.2, -3.2);
    group.add(fireLight);
    this.lobbyFireLight = fireLight;

    // Position camera right in front of the warrior for dramatic lobby framing
    this.camera.position.set(hx, hy + 1.26, hz + 3.45);
    this.camera.lookAt(hx, hy + 1.18, hz - 1.5);
  }

  public startMatch(
    mapId: MapId,
    mode: GameMode,
    options?: {
      networkMode?: NetworkMode;
      roomCode?: string;
      playerName?: string;
      fillWithBots?: boolean;
      hostingRoom?: boolean;
    },
  ) {
    soundEngine.unlock();
    this.mode = mode;
    if (options?.networkMode) this.networkMode = options.networkMode;
    if (options?.roomCode !== undefined) {
      this.roomCode = options.roomCode.trim().toUpperCase().slice(0, 12) || 'ROOM1';
    }
    if (options?.playerName !== undefined) {
      this.playerName = options.playerName.trim() || 'أنت';
    }
    if (options?.fillWithBots !== undefined) {
      this.fillWithBots = options.fillWithBots;
    }
    if (options?.hostingRoom !== undefined) {
      this.hostingRoom = options.hostingRoom;
    }
    this.touchMoveX = 0;
    this.touchMoveY = 0;
    this.touchSprint = false;
    this.touchFiring = false;
    this.touchVehThrottle = 0;
    this.touchVehSteer = 0;
    this.touchVehBrake = false;
    this.hadRemoteOpponent = this.voice.peers.size > 0;
    this.loadMapWorldForMatch(mapId);

    this.phase = 'plane';
    this.planeProgress = 0.05;
    this.parachuteOpen = false;
    this.inVehicle = null;
    this.perspective = 'tpp';
    this.isAds = false;
    this.kills = 0;
    this.headshots = 0;
    this.damageDealt = 0;
    this.distanceTraveledMeters = 0;
    this.lastPlayerPos.set(0, 88, 0);
    this.lootCollected = { total: 0, weapons: 0, armor: 0, meds: 0, ammoAndMods: 0 };
    this.survivalTimeSec = 0;
    this.killfeed = [];
    this.zonePhase = 1;
    this.zoneTimerSec = 34;
    this.zoneShrinking = false;
    this.redZone = null;
    this.redZoneTimer = 24;
    this.airdropTimer = 20;
    this.airdropAnnounce = null;
    this.weatherTime = 0;
    this.weatherLabel = mapId === 'jungle' ? 'رطوبة وغبار استوائي' : 'سماء صافية';

    this.ammoBag = {
      '5.56mm': 0,
      '7.62mm': 0,
      '9mm': 0,
      '.45': 0,
      '12G': 0,
      '.300': 0,
      bolt: 0,
      flare: 0,
    };
    this.meds = { bandage: 3, firstaid: 0, medkit: 0, energy: 1, painkiller: 0 };
    this.throwables = { frag: 1, smoke: 1, molotov: 0, stun: 0 };
    this.activeThrowable = 'frag';
    this.spareScopes = [];
    this.spareMuzzles = [];
    this.spareExtMags = 0;
    this.isReloading = false;
    this.isUsingMed = false;

    const r = this.world!.worldRadius;
    const angle = Math.random() * Math.PI * 2;
    this.planeStart.set(Math.cos(angle) * (r * 0.95), 88, Math.sin(angle) * (r * 0.95));
    this.planeEnd.set(-this.planeStart.x, 88, -this.planeStart.z);

    this.safeZone = { x: 0, z: 0, r: r * 0.94 };
    this.startZone = { ...this.safeZone };
    this.nextZone = {
      x: (Math.random() - 0.5) * r * 0.45,
      z: (Math.random() - 0.5) * r * 0.45,
      r: r * 0.58,
    };

    // Spawn Player + AI Combatants (skip bots if pure friend-vs-friend local room)
    this.spawnCombatants();
    this.updateFppWeaponMesh();
    this.spawnWorldLoot();
    this.setupRainWeather();
    this.applyQualityToRenderer();

    if (!this.touchModeEnabled) {
      this.requestPointerLock();
    }
    this.voice.joinMatch(
      mapId,
      mode,
      0,
      this.playerName || 'أنت',
      this.networkMode,
      this.roomCode,
      this.networkMode === 'local' ? this.hostingRoom : false,
    );
    this.emitHud();
  }

  private loadMapWorldForMatch(mapId: MapId) {
    this.mapId = mapId;
    this.clearWorldEntities();
    this.applyBiomeAtmosphere();
    this.textures = createBiomeTextures(mapId, this.maxAnisotropy);
    this.world = buildMapWorld(this.scene, mapId, this.textures);

    this.world.vehicleSpawnPoints.forEach((vp, idx) => {
      const visual = buildVehicleModel(vp.kind);
      visual.root.position.set(vp.x, vp.y, vp.z);
      visual.root.rotation.y = vp.rot;
      this.scene.add(visual.root);
      this.vehicles.push({
        id: `veh_${idx}`,
        kind: vp.kind,
        nameAr: vp.kind === 'offroader' ? 'سيارة دفع رباعي 4x4' : 'دراجة نارية سريعة',
        pos: new THREE.Vector3(vp.x, vp.y, vp.z),
        yaw: vp.rot,
        speed: 0,
        hp: vp.kind === 'offroader' ? 180 : 100,
        maxHp: vp.kind === 'offroader' ? 180 : 100,
        fuel: 100,
        driverId: null,
        vfxTimer: 0,
        visual,
      });
    });

    this.transportPlane = buildPlaneModel();
    this.scene.add(this.transportPlane.root);
  }

  private setupRainWeather() {
    const count = this.settings.quality === 'smooth' ? 450 : 900;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 90;
      positions[i * 3 + 1] = Math.random() * 45;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({
      color: this.mapId === 'snow' ? 0xf2f8ff : 0xbdd5e8,
      size: this.mapId === 'snow' ? 0.24 : 0.14,
      transparent: true,
      opacity: 0.55,
    });
    this.rainPoints = new THREE.Points(geo, mat);
    this.rainPoints.visible = this.mapId === 'snow' || this.mapId === 'jungle';
    this.scene.add(this.rainPoints);
  }

  private spawnCombatants() {
    const r = this.world!.worldRadius;
    const teamSize = this.mode === 'solo' ? 1 : this.mode === 'duo' ? 2 : 4;
    const pureLocalPvp = this.networkMode === 'local' && !this.fillWithBots;
    const total = pureLocalPvp ? 1 : 30;

    for (let i = 0; i < total; i++) {
      const isPlayer = i === 0;
      const teamId = Math.floor(i / teamSize);
      const isAlly = !isPlayer && teamId === 0;

      const shirtColor = isPlayer
        ? 0xe5e3dc
        : isAlly
          ? 0x2b6cb0
          : [0x6e4736, 0x4b4e54, 0x6b5c3b, 0x3b4a42, 0x5d3b3b][i % 5];

      const visual = buildCharacterModel(shirtColor, isAlly, isPlayer);
      this.scene.add(visual.root);

      const shadowMat = new THREE.MeshBasicMaterial({
        map: this.shadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.45,
      });
      const contactShadow = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 1.3), shadowMat);
      contactShadow.rotation.x = -Math.PI / 2;
      this.scene.add(contactShadow);

      let sx = 0;
      let sz = 0;
      let sy = 88;
      if (!isPlayer) {
        const ang = Math.random() * Math.PI * 2;
        const rad = isAlly ? 24 + Math.random() * 20 : 28 + Math.random() * (r - 45);
        sx = Math.cos(ang) * rad;
        sz = Math.sin(ang) * rad;
        sy = this.world!.groundHeightAt(sx, sz);
        if (sy < MAP_CONFIGS[this.mapId].waterLevel + 0.3) {
          sx *= 0.45;
          sz *= 0.45;
          sy = this.world!.groundHeightAt(sx, sz);
        }
      }

      // Give AI initial starter weapon; give Player tactical starter sidearm (P18C + Red Dot) so Move/Fire/Scope work immediately on landing
      const starterGun = !isPlayer
        ? WORLD_SPAWN_WEAPON_IDS[Math.floor(Math.random() * 8)]
        : null;
      const wInst: WeaponInstance | null = starterGun
        ? {
            defId: starterGun,
            ammoInMag: WEAPONS[starterGun].magSize,
            scope: WEAPONS[starterGun].builtInScope ?? 'iron',
            muzzle: 'none',
            extendedMag: false,
          }
        : null;
      const playerSidearm: WeaponInstance | null = isPlayer
        ? {
            defId: 'p18c',
            ammoInMag: WEAPONS.p18c.magSize,
            scope: 'reddot',
            muzzle: 'none',
            extendedMag: false,
          }
        : null;
      if (isPlayer) {
        this.ammoBag['9mm'] = Math.max(this.ammoBag['9mm'], 51);
      }

      const combatant: Combatant = {
        id: isPlayer ? 'player' : `bot_${i}`,
        name: isPlayer
          ? this.playerName || 'أنت'
          : isAlly
            ? `رفيق ${i}`
            : BOT_NAMES[(i - 1) % BOT_NAMES.length],
        isPlayer,
        teamId,
        alive: true,
        pos: new THREE.Vector3(sx, sy, sz),
        vel: new THREE.Vector3(),
        yaw: Math.random() * Math.PI * 2,
        pitch: 0,
        health: 100,
        maxHealth: 100,
        boost: 0,
        helmetLevel: !isPlayer && Math.random() < 0.45 ? 1 : 0,
        helmetDurability: 100,
        vestLevel: !isPlayer && Math.random() < 0.45 ? 1 : 0,
        vestDurability: 100,
        backpackLevel: 0,
        hasPan: !isPlayer && Math.random() < 0.25,
        hasGhillie: false,
        stance: 'stand',
        lean: 0,
        weapons: isPlayer ? [null, null, playerSidearm] : [wInst, null, null],
        activeSlot: isPlayer ? 2 : 0,
        fireCooldown: 0,
        aiTargetPos: new THREE.Vector3(sx, sy, sz),
        aiThinkTimer: Math.random() * 1.5,
        aiStrafeDir: Math.random() < 0.5 ? 1 : -1,
        aiBurstCount: 0,
        visual,
        contactShadow,
        heldWeaponName: '',
      };

      this.syncCharacterAppearance(combatant);
      this.combatants.push(combatant);
      if (isPlayer) this.player = combatant;
    }
  }

  private syncCharacterAppearance(c: Combatant) {
    const v = c.visual;
    v.helmet1.visible = c.helmetLevel === 1 && !c.hasGhillie;
    v.helmet2.visible = c.helmetLevel === 2 && !c.hasGhillie;
    v.helmet3.visible = c.helmetLevel === 3 && !c.hasGhillie;
    v.vestMesh.visible = c.vestLevel > 0;
    v.backpack1.visible = c.backpackLevel === 1;
    v.backpack2.visible = c.backpackLevel === 2;
    v.backpack3.visible = c.backpackLevel === 3;
    v.panGroup.visible = c.hasPan;
    v.ghillieGroup.visible = c.hasGhillie;

    const wInst = c.weapons[c.activeSlot];
    const key = wInst ? `${wInst.defId}_${wInst.scope}_${wInst.muzzle}` : 'none';
    if (c.heldWeaponName !== key) {
      c.heldWeaponName = key;
      while (v.weaponMount.children.length > 0) {
        v.weaponMount.remove(v.weaponMount.children[0]);
      }
      if (wInst) {
        const mesh = buildWeaponMesh(
          wInst.defId,
          wInst.scope,
          wInst.muzzle === 'suppressor',
        );
        mesh.scale.setScalar(0.85);
        v.weaponMount.add(mesh);
      }
    }
  }

  private spawnWorldLoot() {
    if (!this.world) return;
    let idSeq = 1;

    const addLoot = (partial: Omit<LootItem, 'id' | 'pickedUp'>) => {
      const item: LootItem = { ...partial, id: `loot_${idSeq++}`, pickedUp: false };
      const group = new THREE.Group();
      group.position.set(item.x, item.y, item.z);

      let color = 0xd4a84b;
      if (item.kind === 'weapon') color = 0xf59e0b;
      else if (item.kind === 'med') color = 0x22c55e;
      else if (item.kind === 'helmet' || item.kind === 'vest' || item.kind === 'backpack')
        color = 0x38bdf8;
      else if (item.kind === 'pan' || item.kind === 'ghillie') color = 0xec4899;
      else if (item.kind === 'scope' || item.kind === 'muzzle' || item.kind === 'extmag')
        color = 0xa855f7;
      else if (item.kind === 'throwable') color = 0xef4444;

      // Ground glow disc
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.28, 0.42, 16),
        new THREE.MeshBasicMaterial({ color, side: THREE.DoubleSide, transparent: true, opacity: 0.68 }),
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.04;
      group.add(ring);

      if (item.kind === 'weapon' && item.weaponId) {
        const wm = buildWeaponMesh(item.weaponId, 'iron', false);
        wm.scale.setScalar(0.85);
        wm.position.y = 0.24;
        wm.rotation.z = Math.PI / 2;
        group.add(wm);
      } else {
        const box = new THREE.Mesh(
          new THREE.BoxGeometry(0.38, 0.24, 0.38),
          new THREE.MeshStandardMaterial({ color, roughness: 0.42, metalness: 0.35 }),
        );
        box.position.y = 0.22;
        group.add(box);
      }

      this.scene.add(group);
      this.lootEntries.push({ item, mesh: group });
    };

    // Spawn rich loot sets at all compound & field spawn points
    this.world.lootSpawnPoints.forEach((pt, idx) => {
      // Weapon + matching ammo
      const wid = WORLD_SPAWN_WEAPON_IDS[idx % WORLD_SPAWN_WEAPON_IDS.length];
      const def = WEAPONS[wid];
      addLoot({
        kind: 'weapon',
        labelAr: def.nameAr,
        subLabel: def.name,
        weaponId: wid,
        x: pt.x,
        y: pt.y,
        z: pt.z,
      });
      addLoot({
        kind: 'ammo',
        labelAr: `ذخيرة ${AMMO_LABELS[def.ammoType]}`,
        ammoType: def.ammoType,
        ammoAmount: def.category === 'sniper' || def.category === 'shotgun' ? 15 : 45,
        x: pt.x + 0.85,
        y: pt.y,
        z: pt.z + 0.3,
      });

      // Armor / Backpack / Pan / Med / Attachment
      const roll = idx % 8;
      if (roll === 0 || roll === 4) {
        const lvl: 1 | 2 | 3 = idx % 16 === 0 ? 3 : idx % 8 === 0 ? 2 : 1;
        addLoot({
          kind: 'helmet',
          labelAr: `خوذة تكتيكية (المستوى ${lvl})`,
          level: lvl,
          x: pt.x - 0.8,
          y: pt.y,
          z: pt.z + 0.4,
        });
      } else if (roll === 1 || roll === 5) {
        const lvl: 1 | 2 | 3 = idx % 15 === 1 ? 3 : 2;
        addLoot({
          kind: 'vest',
          labelAr: `درع واقٍ للجسد (المستوى ${lvl})`,
          level: lvl,
          x: pt.x - 0.7,
          y: pt.y,
          z: pt.z - 0.5,
        });
      } else if (roll === 2) {
        const lvl: 1 | 2 | 3 = idx % 10 === 2 ? 3 : 2;
        addLoot({
          kind: 'backpack',
          labelAr: `حقيبة ظهر (المستوى ${lvl})`,
          level: lvl,
          x: pt.x + 0.4,
          y: pt.y,
          z: pt.z - 0.75,
        });
      } else if (roll === 3) {
        addLoot({
          kind: 'pan',
          labelAr: 'المقلاة الحديدية الواقية',
          x: pt.x - 0.6,
          y: pt.y,
          z: pt.z - 0.6,
        });
      } else if (roll === 6) {
        const sc: ScopeType = idx % 14 === 6 ? '8x' : idx % 3 === 0 ? '4x' : '2x';
        addLoot({
          kind: 'scope',
          labelAr: SCOPE_INFO[sc].labelAr,
          scopeType: sc,
          x: pt.x + 0.6,
          y: pt.y,
          z: pt.z + 0.7,
        });
      } else {
        addLoot({
          kind: 'muzzle',
          labelAr: 'كاتم صوت تكتيكي',
          muzzleType: 'suppressor',
          x: pt.x - 0.5,
          y: pt.y,
          z: pt.z + 0.7,
        });
      }

      // Meds & Throwables
      const medTypes: MedType[] = ['firstaid', 'bandage', 'energy', 'painkiller', 'medkit'];
      const mt = medTypes[idx % medTypes.length];
      addLoot({
        kind: 'med',
        labelAr: MED_INFO[mt].labelAr,
        medType: mt,
        x: pt.x - 0.25,
        y: pt.y,
        z: pt.z + 0.9,
      });

      if (idx % 2 === 0) {
        const thList: ThrowableType[] = ['frag', 'smoke', 'molotov', 'stun'];
        const th = thList[(idx / 2) % thList.length];
        addLoot({
          kind: 'throwable',
          labelAr: THROWABLE_INFO[th].labelAr,
          throwableType: th,
          x: pt.x + 0.95,
          y: pt.y,
          z: pt.z - 0.4,
        });
      }

      if (idx === 5) {
        // Rare Flare Gun spawn!
        addLoot({
          kind: 'weapon',
          labelAr: WEAPONS.flaregun.nameAr,
          weaponId: 'flaregun',
          x: pt.x + 1.2,
          y: pt.y,
          z: pt.z + 0.9,
        });
      }
    });
  }

  public spawnAirdrop(targetX?: number, targetZ?: number, announceMsg = 'طائرة الدعم ألقت صندوق إمدادات نادر!') {
    if (!this.world) return;
    const tx = targetX ?? this.safeZone.x + (Math.random() - 0.5) * this.safeZone.r * 0.7;
    const tz = targetZ ?? this.safeZone.z + (Math.random() - 0.5) * this.safeZone.r * 0.7;
    const crate = buildAirdropCrate(this.textures!.crateMap);
    crate.root.position.set(tx, 75, tz);
    this.scene.add(crate.root);

    this.airdrops.push({
      pos: new THREE.Vector3(tx, 75, tz),
      landed: false,
      looted: false,
      crate,
      smokeTimer: 0,
    });
    this.airdropAnnounce = announceMsg;
    this.airdropAnnounceTimer = 5.5;
  }

  // Controls & Input Listeners
  private bindInputs() {
    window.addEventListener('resize', this.onResize);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onWindowBlur);
    document.addEventListener('pointerlockchange', this.onPointerLockChange);
    document.addEventListener('mousemove', this.onMouseMove);
    this.renderer.domElement.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
    this.renderer.domElement.addEventListener('contextmenu', this.onContextMenu);
  }

  private unbindInputs() {
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onWindowBlur);
    document.removeEventListener('pointerlockchange', this.onPointerLockChange);
    document.removeEventListener('mousemove', this.onMouseMove);
    this.renderer.domElement.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mouseup', this.onMouseUp);
    this.renderer.domElement.removeEventListener('contextmenu', this.onContextMenu);
  }

  private onResize = () => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.composer?.setSize(w, h);
    this.bloomPass?.resolution.set(w, h);
    this.applyQualityToRenderer();
    this.emitHud();
  };

  private onWindowBlur = () => {
    this.heldKeys.clear();
    this.mouseLeftDown = false;
    this.mouseRightDown = false;
    this.isAds = false;
    this.dragLooking = false;
    this.lobbyDragging = false;
    this.touchMoveX = 0;
    this.touchMoveY = 0;
    this.touchSprint = false;
    this.touchFiring = false;
    this.touchVehThrottle = 0;
    this.touchVehSteer = 0;
    this.touchVehBrake = false;
    this.voice.setPttHeld(false);
  };

  private onPointerLockChange = () => {
    this.pointerLocked = document.pointerLockElement === this.renderer.domElement;
    this.emitHud();
  };

  public setTouchModeEnabled(enabled: boolean) {
    this.touchModeEnabled = enabled;
    if (enabled) {
      this.releasePointerLock();
    }
  }

  public requestPointerLock() {
    if (this.touchModeEnabled) return;
    try {
      this.renderer.domElement.requestPointerLock?.();
    } catch {
      // Fallback drag-to-look remains active if iframe restricts pointer lock
    }
  }

  public releasePointerLock() {
    if (document.pointerLockElement) {
      document.exitPointerLock?.();
    }
  }

  private onContextMenu = (e: MouseEvent) => {
    e.preventDefault();
  };

  private onMouseDown = (e: MouseEvent) => {
    soundEngine.unlock();
    if (this.phase === 'menu') {
      if (e.button === 0) {
        this.lobbyDragging = true;
        this.lastPointerX = e.clientX;
      }
      return;
    }
    if (this.phase === 'paused' || this.phase === 'victory' || this.phase === 'gameover') {
      return;
    }
    if (this.touchModeEnabled) {
      if (e.button === 0) {
        this.dragLooking = true;
        this.lastPointerX = e.clientX;
        this.lastPointerY = e.clientY;
      }
      return;
    }
    if (!this.pointerLocked && this.phase === 'playing') {
      this.requestPointerLock();
    }
    if (e.button === 0) {
      this.mouseLeftDown = true;
      this.dragLooking = !this.pointerLocked;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
      if (this.phase === 'playing' && !this.inVehicle) {
        this.tryPlayerShoot(true);
      }
    } else if (e.button === 2) {
      this.mouseRightDown = true;
      if (this.phase === 'playing' && !this.inVehicle) {
        this.isAds = true;
      }
    }
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) {
      this.mouseLeftDown = false;
      this.dragLooking = false;
      this.lobbyDragging = false;
    } else if (e.button === 2) {
      this.mouseRightDown = false;
      this.isAds = false;
    }
  };

  private onMouseMove = (e: MouseEvent) => {
    if (this.phase === 'menu' && this.lobbyDragging) {
      const dx = e.clientX - this.lastPointerX;
      this.lastPointerX = e.clientX;
      this.lobbyDragYaw += dx * 0.009;
      return;
    }
    if (this.phase !== 'plane' && this.phase !== 'skydiving' && this.phase !== 'playing') return;
    if (!this.player || !this.player.alive) return;

    const sens = 0.0022 * this.settings.mouseSensitivity * (this.isAds ? 0.55 : 1);
    if (this.pointerLocked) {
      this.player.yaw -= e.movementX * sens;
      this.player.pitch = THREE.MathUtils.clamp(this.player.pitch - e.movementY * sens, -1.32, 1.28);
    } else if (this.dragLooking) {
      const dx = e.clientX - this.lastPointerX;
      const dy = e.clientY - this.lastPointerY;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
      this.player.yaw -= dx * sens * 1.4;
      this.player.pitch = THREE.MathUtils.clamp(this.player.pitch - dy * sens * 1.4, -1.32, 1.28);
    }
  };

  private onKeyDown = (e: KeyboardEvent) => {
    const code = e.code;
    const isRepeat = e.repeat;
    this.heldKeys.add(code);

    if (this.phase === 'menu' || this.phase === 'victory' || this.phase === 'gameover') {
      return;
    }

    if (isRepeat) return;

    if (this.phase === 'plane' && code === 'Space') {
      this.jumpFromPlane();
      return;
    }

    if (this.phase === 'skydiving' && code === 'Space' && !this.parachuteOpen) {
      this.parachuteOpen = true;
      this.player.visual.parachuteGroup.visible = true;
      soundEngine.playPickup();
      return;
    }

    if (this.phase !== 'playing' || !this.player.alive) return;

    if (code === 'KeyV') {
      this.perspective = this.perspective === 'tpp' ? 'fpp' : 'tpp';
      this.updateFppWeaponMesh();
    } else if (code === 'KeyQ') {
      this.player.lean = this.player.lean === -1 ? 0 : -1;
    } else if (code === 'KeyE') {
      this.player.lean = this.player.lean === 1 ? 0 : 1;
    } else if (code === 'KeyC') {
      this.player.stance = this.player.stance === 'crouch' ? 'stand' : 'crouch';
    } else if (code === 'KeyZ') {
      this.player.stance = this.player.stance === 'prone' ? 'stand' : 'prone';
    } else if (code === 'Space' && !this.inVehicle) {
      if (this.player.stance !== 'stand') {
        this.player.stance = 'stand';
      } else {
        const gh = this.world!.groundHeightAt(this.player.pos.x, this.player.pos.z);
        if (this.player.pos.y <= gh + 0.12) {
          this.player.vel.y = 7.4;
        }
      }
    } else if (code === 'KeyR') {
      this.startReload();
    } else if (code === 'KeyF') {
      this.handleInteract();
    } else if (code === 'Digit1') {
      this.switchWeaponSlot(0);
    } else if (code === 'Digit2') {
      this.switchWeaponSlot(1);
    } else if (code === 'Digit3') {
      this.switchWeaponSlot(2);
    } else if (code === 'Digit4') {
      this.cycleThrowable();
    } else if (code === 'KeyG') {
      this.throwActiveGrenade();
    } else if (code === 'Digit7') {
      this.startUseMed('medkit');
    } else if (code === 'Digit8') {
      this.startUseMed('firstaid');
    } else if (code === 'Digit9') {
      this.startUseMed('bandage');
    } else if (code === 'Digit0') {
      if (this.meds.painkiller > 0) this.startUseMed('painkiller');
      else this.startUseMed('energy');
    } else if (code === 'KeyT') {
      this.voice.setPttHeld(true);
    } else if (code === 'KeyY') {
      this.voice.cycleChannel();
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.heldKeys.delete(e.code);
    if (e.code === 'KeyT') {
      this.voice.setPttHeld(false);
    }
  };

  public setPaused(paused: boolean) {
    if (paused && (this.phase === 'playing' || this.phase === 'skydiving' || this.phase === 'plane')) {
      this.phase = 'paused';
      this.heldKeys.clear();
      this.mouseLeftDown = false;
      this.mouseRightDown = false;
      this.isAds = false;
      this.touchMoveX = 0;
      this.touchMoveY = 0;
      this.touchSprint = false;
      this.touchFiring = false;
      this.touchVehThrottle = 0;
      this.touchVehSteer = 0;
      this.touchVehBrake = false;
      soundEngine.stopEngine();
      this.releasePointerLock();
      this.emitHud();
    } else if (!paused && this.phase === 'paused') {
      this.phase = 'playing';
      this.requestPointerLock();
      this.emitHud();
    }
  }

  // Dedicated Android / Mobile Touch Control APIs
  public setTouchMove(x: number, y: number, sprint: boolean) {
    this.touchMoveX = THREE.MathUtils.clamp(x, -1, 1);
    this.touchMoveY = THREE.MathUtils.clamp(y, -1, 1);
    this.touchSprint = sprint;
  }

  public addTouchLook(dx: number, dy: number) {
    if (!this.player || !this.player.alive) return;
    if (this.phase === 'menu') {
      this.lobbyDragYaw += dx * 0.009;
      return;
    }
    if (this.phase !== 'plane' && this.phase !== 'skydiving' && this.phase !== 'playing') return;
    const sens = 0.0038 * this.settings.mouseSensitivity * (this.isAds ? 0.52 : 1);
    this.player.yaw -= dx * sens;
    this.player.pitch = THREE.MathUtils.clamp(this.player.pitch - dy * sens, -1.32, 1.28);
  }

  public setTouchFire(firing: boolean) {
    soundEngine.unlock();
    this.touchFiring = firing;
    if (firing && this.phase === 'playing' && !this.inVehicle && this.player?.alive) {
      this.tryPlayerShoot(true);
    }
  }

  public setTouchVehicleInput(throttle: number, steer: number, brake: boolean) {
    this.touchVehThrottle = THREE.MathUtils.clamp(throttle, -1, 1);
    this.touchVehSteer = THREE.MathUtils.clamp(steer, -1, 1);
    this.touchVehBrake = brake;
  }

  public toggleAds() {
    if (this.phase !== 'playing' || this.inVehicle || !this.player?.alive) return;
    this.isAds = !this.isAds;
    this.emitHud();
  }

  public togglePerspective() {
    if (this.phase !== 'playing' || !this.player?.alive) return;
    this.perspective = this.perspective === 'tpp' ? 'fpp' : 'tpp';
    this.updateFppWeaponMesh();
    this.emitHud();
  }

  public toggleLean(dir: -1 | 1) {
    if (this.phase !== 'playing' || this.inVehicle || !this.player?.alive) return;
    this.player.lean = this.player.lean === dir ? 0 : dir;
    this.emitHud();
  }

  public toggleStance(target: 'crouch' | 'prone') {
    if (this.phase !== 'playing' || this.inVehicle || !this.player?.alive) return;
    this.player.stance = this.player.stance === target ? 'stand' : target;
    this.emitHud();
  }

  public triggerJumpOrParachute() {
    soundEngine.unlock();
    if (this.phase === 'plane') {
      this.jumpFromPlane();
      return;
    }
    if (this.phase === 'skydiving' && !this.parachuteOpen) {
      this.parachuteOpen = true;
      this.player.visual.parachuteGroup.visible = true;
      soundEngine.playPickup();
      return;
    }
    if (this.phase === 'playing' && !this.inVehicle && this.player?.alive) {
      if (this.player.stance !== 'stand') {
        this.player.stance = 'stand';
      } else {
        const gh = this.world!.groundHeightAt(this.player.pos.x, this.player.pos.z);
        if (this.player.pos.y <= gh + 0.14) {
          this.player.vel.y = 7.4;
        }
      }
    }
  }

  public triggerInteract() {
    if (this.phase !== 'playing' || !this.player?.alive) return;
    this.handleInteract();
  }

  public triggerReload() {
    if (this.phase !== 'playing' || !this.player?.alive) return;
    this.startReload();
  }

  public selectWeaponSlot(slot: 0 | 1 | 2) {
    if (this.phase !== 'playing' || !this.player?.alive) return;
    this.switchWeaponSlot(slot);
  }

  public triggerQuickMed() {
    if (this.phase !== 'playing' || !this.player?.alive) return;
    if (this.player.health < 95) {
      const order: MedType[] = ['medkit', 'firstaid', 'bandage', 'painkiller', 'energy'];
      for (const mt of order) {
        if (this.meds[mt] > 0) {
          this.startUseMed(mt);
          return;
        }
      }
    } else if (this.player.boost < 95) {
      if (this.meds.painkiller > 0) this.startUseMed('painkiller');
      else if (this.meds.energy > 0) this.startUseMed('energy');
    }
  }

  public setVoicePtt(held: boolean) {
    this.voice.setPttHeld(held);
  }

  public jumpFromPlane() {
    if (this.phase !== 'plane') return;
    this.phase = 'skydiving';
    this.parachuteOpen = false;
    this.player.pos.copy(this.transportPlane!.root.position);
    this.player.pos.y -= 3;
    this.player.vel.set(0, -4, 0);
    soundEngine.playPickup();
  }

  private switchWeaponSlot(slot: 0 | 1 | 2) {
    if (this.player.activeSlot === slot) return;
    this.player.activeSlot = slot;
    this.isReloading = false;
    this.syncCharacterAppearance(this.player);
    this.updateFppWeaponMesh();
    soundEngine.playPickup();
  }

  public cycleThrowable() {
    const order: ThrowableType[] = ['frag', 'smoke', 'molotov', 'stun'];
    const idx = order.indexOf(this.activeThrowable);
    for (let k = 1; k <= order.length; k++) {
      const next = order[(idx + k) % order.length];
      if (this.throwables[next] > 0 || k === order.length) {
        this.activeThrowable = next;
        break;
      }
    }
  }

  public throwActiveGrenade() {
    if (this.phase !== 'playing' || this.inVehicle || !this.player.alive) return;
    if (this.throwables[this.activeThrowable] <= 0) return;

    this.throwables[this.activeThrowable] -= 1;
    const type = this.activeThrowable;

    const dir = new THREE.Vector3(0, 0, -1).applyEuler(
      new THREE.Euler(this.player.pitch + 0.18, this.player.yaw, 0, 'YXZ'),
    );
    const startPos = this.player.pos.clone().add(new THREE.Vector3(0, 1.45, 0)).addScaledVector(dir, 0.8);

    const color =
      type === 'frag' ? 0x3b4d32 : type === 'smoke' ? 0x94a3b8 : type === 'molotov' ? 0xf97316 : 0x38bdf8;
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.16, 8, 8),
      new THREE.MeshStandardMaterial({ color, roughness: 0.5, metalness: 0.4 }),
    );
    mesh.position.copy(startPos);
    this.scene.add(mesh);

    this.thrownObjects.push({
      type,
      pos: startPos,
      vel: dir.multiplyScalar(22),
      fuse: type === 'molotov' ? 1.8 : 2.1,
      ownerId: this.player.id,
      mesh,
    });
    soundEngine.playPickup();
  }

  public startUseMed(type: MedType) {
    if (this.phase !== 'playing' || !this.player.alive) return;
    if (this.meds[type] <= 0 || this.isUsingMed) return;
    const info = MED_INFO[type];
    if (info.healTo > 0 && this.player.health >= info.healTo) return;
    if (info.boostAmount > 0 && this.player.boost >= 100) return;

    this.isUsingMed = true;
    this.medUseType = type;
    this.medUseDuration = info.useTimeSec;
    this.medUseTimer = 0;
    this.isReloading = false;
  }

  public attachSpareScope(scope: ScopeType) {
    const w = this.player.weapons[this.player.activeSlot];
    if (!w) return;
    const def = WEAPONS[w.defId];
    if (def.builtInScope) return;
    const idx = this.spareScopes.indexOf(scope);
    if (idx === -1) return;
    this.spareScopes.splice(idx, 1);
    if (w.scope !== 'iron') this.spareScopes.push(w.scope);
    w.scope = scope;
    this.syncCharacterAppearance(this.player);
    this.updateFppWeaponMesh();
    soundEngine.playPickup();
  }

  public attachSpareMuzzle(muzzle: MuzzleType) {
    const w = this.player.weapons[this.player.activeSlot];
    if (!w) return;
    const idx = this.spareMuzzles.indexOf(muzzle);
    if (idx === -1) return;
    this.spareMuzzles.splice(idx, 1);
    if (w.muzzle !== 'none') this.spareMuzzles.push(w.muzzle);
    w.muzzle = muzzle;
    this.syncCharacterAppearance(this.player);
    this.updateFppWeaponMesh();
    soundEngine.playPickup();
  }

  public attachSpareExtMag() {
    const w = this.player.weapons[this.player.activeSlot];
    if (!w || w.extendedMag || this.spareExtMags <= 0) return;
    this.spareExtMags -= 1;
    w.extendedMag = true;
    soundEngine.playPickup();
  }

  private startReload() {
    const w = this.player.weapons[this.player.activeSlot];
    if (!w || this.isReloading) return;
    const def = WEAPONS[w.defId];
    const cap = w.extendedMag ? def.extendedMagSize : def.magSize;
    if (w.ammoInMag >= cap) return;
    if (this.ammoBag[def.ammoType] <= 0) return;

    this.isReloading = true;
    this.reloadDuration = def.reloadTimeSec;
    this.reloadTimer = 0;
    this.isUsingMed = false;
    soundEngine.playReload();
  }

  private handleInteract() {
    if (this.inVehicle) {
      // Exit vehicle safely to the left side
      const exitX = this.inVehicle.pos.x - Math.cos(this.inVehicle.yaw) * 2.5;
      const exitZ = this.inVehicle.pos.z + Math.sin(this.inVehicle.yaw) * 2.5;
      this.player.pos.set(exitX, this.world!.groundHeightAt(exitX, exitZ), exitZ);
      this.inVehicle.driverId = null;
      this.inVehicle = null;
      this.player.visual.root.visible = this.perspective === 'tpp';
      soundEngine.stopEngine();
      return;
    }

    // 1. Check nearby airdrop crate
    for (const drop of this.airdrops) {
      if (drop.landed && !drop.looted && drop.pos.distanceTo(this.player.pos) < 3.6) {
        drop.looted = true;
        this.grantAirdropLoot();
        soundEngine.playPickup();
        return;
      }
    }

    // 2. Check nearby loot item
    const nearestLoot = this.findNearestLoot(3.2);
    if (nearestLoot) {
      this.pickupLoot(nearestLoot);
      return;
    }

    // 3. Check nearby vehicle
    const nearestVeh = this.findNearestVehicle(4.2);
    if (nearestVeh && nearestVeh.hp > 0) {
      this.inVehicle = nearestVeh;
      nearestVeh.driverId = this.player.id;
      this.isAds = false;
      this.isReloading = false;
      this.isUsingMed = false;
      this.player.visual.root.visible = false;
      soundEngine.playPickup();
    }
  }

  private grantAirdropLoot() {
    const isAwm = Math.random() < 0.55;
    const wid = isAwm ? 'awm' : 'groza';
    const def = WEAPONS[wid];
    const inst: WeaponInstance = {
      defId: wid,
      ammoInMag: def.magSize,
      scope: def.builtInScope ?? '4x',
      muzzle: 'suppressor',
      extendedMag: true,
    };
    const emptySlot = this.player.weapons.findIndex((w) => w === null);
    const targetSlot = (emptySlot !== -1 ? emptySlot : this.player.activeSlot) as 0 | 1 | 2;
    this.player.weapons[targetSlot] = inst;
    this.player.activeSlot = targetSlot;
    this.ammoBag[def.ammoType] += isAwm ? 25 : 120;

    this.player.helmetLevel = 3;
    this.player.helmetDurability = 100;
    this.player.vestLevel = 3;
    this.player.vestDurability = 100;
    this.player.backpackLevel = 3;
    this.player.hasGhillie = true;
    this.meds.medkit += 1;
    this.meds.painkiller += 2;
    this.throwables.frag += 2;

    this.syncCharacterAppearance(this.player);
    this.updateFppWeaponMesh();
    this.lootCollected.total += 10;
    this.lootCollected.weapons += 1;
    this.lootCollected.armor += 4;
    this.lootCollected.meds += 3;
    this.lootCollected.ammoAndMods += 2;
    this.airdropAnnounce = `تم تأمين عتاد صندوق الدعم (${def.name} + خوذة ودرع 3 + بدلة تمويه)!`;
    this.airdropAnnounceTimer = 4.5;
  }

  private findNearestLoot(maxDist: number): LootVisualEntry | null {
    let best: LootVisualEntry | null = null;
    let bestDist = maxDist;
    for (const entry of this.lootEntries) {
      if (entry.item.pickedUp) continue;
      const d = Math.hypot(entry.item.x - this.player.pos.x, entry.item.z - this.player.pos.z);
      if (d < bestDist && Math.abs(entry.item.y - this.player.pos.y) < 3.2) {
        bestDist = d;
        best = entry;
      }
    }
    return best;
  }

  private findNearestVehicle(maxDist: number): ActiveVehicle | null {
    let best: ActiveVehicle | null = null;
    let bestDist = maxDist;
    for (const v of this.vehicles) {
      if (v.hp <= 0) continue;
      const d = v.pos.distanceTo(this.player.pos);
      if (d < bestDist) {
        bestDist = d;
        best = v;
      }
    }
    return best;
  }

  private pickupLoot(entry: LootVisualEntry) {
    const item = entry.item;
    item.pickedUp = true;
    this.scene.remove(entry.mesh);
    soundEngine.playPickup();

    this.lootCollected.total += 1;
    if (item.kind === 'weapon') {
      this.lootCollected.weapons += 1;
    } else if (
      item.kind === 'helmet' ||
      item.kind === 'vest' ||
      item.kind === 'backpack' ||
      item.kind === 'pan' ||
      item.kind === 'ghillie'
    ) {
      this.lootCollected.armor += 1;
    } else if (item.kind === 'med') {
      this.lootCollected.meds += 1;
    } else {
      this.lootCollected.ammoAndMods += 1;
    }

    if (item.kind === 'weapon' && item.weaponId) {
      const def = WEAPONS[item.weaponId];
      const slot =
        def.category === 'pistol'
          ? 2
          : this.player.weapons[0] === null
            ? 0
            : this.player.weapons[1] === null
              ? 1
              : this.player.activeSlot === 2
                ? 0
                : this.player.activeSlot;

      this.player.weapons[slot] = {
        defId: item.weaponId,
        ammoInMag: def.magSize,
        scope: def.builtInScope ?? 'iron',
        muzzle: 'none',
        extendedMag: false,
      };
      this.ammoBag[def.ammoType] += def.category === 'pistol' ? 15 : 30;
      this.player.activeSlot = slot as 0 | 1 | 2;
      this.syncCharacterAppearance(this.player);
      this.updateFppWeaponMesh();
    } else if (item.kind === 'ammo' && item.ammoType) {
      this.ammoBag[item.ammoType] += item.ammoAmount ?? 30;
    } else if (item.kind === 'helmet' && item.level) {
      if (item.level >= this.player.helmetLevel) {
        this.player.helmetLevel = item.level;
        this.player.helmetDurability = 100;
        this.syncCharacterAppearance(this.player);
      }
    } else if (item.kind === 'vest' && item.level) {
      if (item.level >= this.player.vestLevel) {
        this.player.vestLevel = item.level;
        this.player.vestDurability = 100;
        this.syncCharacterAppearance(this.player);
      }
    } else if (item.kind === 'backpack' && item.level) {
      if (item.level >= this.player.backpackLevel) {
        this.player.backpackLevel = item.level;
        this.syncCharacterAppearance(this.player);
      }
    } else if (item.kind === 'pan') {
      this.player.hasPan = true;
      this.syncCharacterAppearance(this.player);
    } else if (item.kind === 'ghillie') {
      this.player.hasGhillie = true;
      this.syncCharacterAppearance(this.player);
    } else if (item.kind === 'med' && item.medType) {
      this.meds[item.medType] += 1;
    } else if (item.kind === 'throwable' && item.throwableType) {
      this.throwables[item.throwableType] += 1;
    } else if (item.kind === 'scope' && item.scopeType) {
      const w = this.player.weapons[this.player.activeSlot];
      if (w && !WEAPONS[w.defId].builtInScope && w.scope === 'iron') {
        w.scope = item.scopeType;
        this.syncCharacterAppearance(this.player);
        this.updateFppWeaponMesh();
      } else {
        this.spareScopes.push(item.scopeType);
      }
    } else if (item.kind === 'muzzle' && item.muzzleType) {
      const w = this.player.weapons[this.player.activeSlot];
      if (w && w.muzzle === 'none') {
        w.muzzle = item.muzzleType;
        this.syncCharacterAppearance(this.player);
        this.updateFppWeaponMesh();
      } else {
        this.spareMuzzles.push(item.muzzleType);
      }
    } else if (item.kind === 'extmag') {
      const w = this.player.weapons[this.player.activeSlot];
      if (w && !w.extendedMag) w.extendedMag = true;
      else this.spareExtMags += 1;
    }
  }

  private updateFppWeaponMesh() {
    if (this.fppWeaponMesh) {
      this.fppMount.remove(this.fppWeaponMesh);
      this.fppWeaponMesh = null;
      this.fppMuzzleFlash = null;
    }
    const w = this.player?.weapons[this.player.activeSlot];
    if (!w) {
      this.fppWeaponKey = '';
      return;
    }
    this.fppWeaponMesh = buildWeaponMesh(w.defId, w.scope, w.muzzle === 'suppressor');
    this.fppWeaponMesh.position.set(0.24, -0.22, -0.45);
    const suppressed = Boolean(WEAPONS[w.defId]?.builtInSuppressor || w.muzzle === 'suppressor');
    this.fppMuzzleFlash = this.buildMuzzleFlashMesh(suppressed);
    this.fppMuzzleFlash.position.set(0, 0.035, -0.46);
    this.fppMuzzleFlash.visible = false;
    this.fppWeaponMesh.add(this.fppMuzzleFlash);
    this.fppMount.add(this.fppWeaponMesh);
    this.fppWeaponKey = `${w.defId}_${w.scope}_${w.muzzle}`;
  }

  private tryPlayerShoot(isTriggerPress: boolean) {
    let w = this.player.weapons[this.player.activeSlot];
    if (!w) {
      const armedSlot = this.player.weapons.findIndex((slotWep) => slotWep !== null);
      if (armedSlot !== -1) {
        this.switchWeaponSlot(armedSlot as 0 | 1 | 2);
        w = this.player.weapons[this.player.activeSlot];
      }
    }
    if (!w || this.isReloading || this.isUsingMed) return;
    const def = WEAPONS[w.defId];
    if (!def.auto && !isTriggerPress) return;
    if (this.player.fireCooldown > 0) return;

    if (w.ammoInMag <= 0) {
      this.startReload();
      return;
    }

    w.ammoInMag -= 1;
    this.player.fireCooldown = def.fireRateMs / 1000;
    const suppressed = Boolean(def.builtInSuppressor || w.muzzle === 'suppressor');
    soundEngine.playShot(def.category, suppressed, 0);

    // Muzzle flash, shell casing & recoil
    this.muzzleFlashTimer = 0.058;
    this.muzzleLight.intensity = suppressed ? 1.5 : 5.2;
    this.fppRecoilOffset = Math.min(0.11, this.fppRecoilOffset + 0.05);
    if (this.fppMuzzleFlash) {
      this.fppMuzzleFlash.visible = true;
      this.fppMuzzleFlash.rotation.z = Math.random() * Math.PI * 2;
      const sc = suppressed ? 0.48 : 0.85 + Math.random() * 0.45;
      this.fppMuzzleFlash.scale.setScalar(sc);
    }

    const stanceRecoilMult =
      this.player.stance === 'prone' ? 0.55 : this.player.stance === 'crouch' ? 0.78 : 1.0;
    const muzzleMult = w.muzzle === 'compensator' ? 0.74 : w.muzzle === 'suppressor' ? 0.88 : 1.0;
    const kick = def.recoilKick * stanceRecoilMult * muzzleMult;
    this.player.pitch = THREE.MathUtils.clamp(this.player.pitch + kick, -1.32, 1.28);
    this.player.yaw += (Math.random() - 0.5) * kick * 0.45;
    this.shakeIntensity = Math.min(0.08, this.shakeIntensity + kick * 0.5);

    // Spawn bullet(s) from camera forward ray
    const dirBase = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion).normalize();
    const origin = this.camera.position.clone().addScaledVector(dirBase, 0.7);

    // World-space 3D muzzle burst for TPP and ejected brass shell casing
    if (this.perspective === 'tpp' && !this.isAds) {
      const gunPos = this.player.pos
        .clone()
        .add(new THREE.Vector3(-Math.sin(this.player.yaw) * 0.85, 1.4, -Math.cos(this.player.yaw) * 0.85));
      this.spawnMuzzleFlash(gunPos, dirBase, suppressed);
    }
    this.spawnShellCasing(
      this.player.pos.clone().add(new THREE.Vector3(0, 1.42, 0)),
      this.player.yaw,
    );

    const spreadMult = this.isAds ? 0.35 : 1.0;
    const pellets = def.pellets ?? 1;

    if (def.ammoType === 'flare') {
      // Flare shoots straight up to call an Airdrop!
      const fDir = new THREE.Vector3(dirBase.x * 0.25, 0.96, dirBase.z * 0.25).normalize();
      this.spawnProjectile(this.player, origin, fDir, def.id, true);
      this.spawnAirdrop(
        this.player.pos.x + (Math.random() - 0.5) * 12,
        this.player.pos.z + (Math.random() - 0.5) * 12,
        'أطلقت إشارة ضوئية! طائرة الدعم تتجه لإسقاط صندوق خاص فوقك!',
      );
      return;
    }

    for (let i = 0; i < pellets; i++) {
      const spread = def.baseSpread * spreadMult * stanceRecoilMult;
      const d = dirBase.clone();
      d.x += (Math.random() - 0.5) * spread * 2;
      d.y += (Math.random() - 0.5) * spread * 2;
      d.z += (Math.random() - 0.5) * spread * 2;
      d.normalize();
      this.spawnProjectile(this.player, origin, d, def.id, false);
    }

    if (this.networkMode !== 'offline') {
      this.voice.sendShoot(
        { x: origin.x, y: origin.y, z: origin.z },
        { x: dirBase.x, y: dirBase.y, z: dirBase.z },
        def.id,
      );
    }

    // Alert nearby bots to gunshot sound
    if (!suppressed) {
      this.alertBotsNear(this.player.pos, 95);
    }
  }

  private spawnProjectile(
    owner: Combatant,
    origin: THREE.Vector3,
    dir: THREE.Vector3,
    weaponId: string,
    isFlare: boolean,
  ) {
    const def = WEAPONS[weaponId];
    const mesh = new THREE.Mesh(this.bulletGeo, isFlare ? this.flareMat : this.bulletMat);
    mesh.position.copy(origin);
    if (isFlare) mesh.scale.setScalar(2.4);
    this.scene.add(mesh);

    this.projectiles.push({
      pos: origin.clone(),
      vel: dir.clone().multiplyScalar(def.bulletSpeed),
      ownerId: owner.id,
      teamId: owner.teamId,
      weaponId,
      damage: def.damage,
      headshotMult: def.headshotMult,
      life: def.range / def.bulletSpeed,
      isFlare,
      mesh,
    });
  }

  private alertBotsNear(pos: THREE.Vector3, radius: number) {
    for (const c of this.combatants) {
      if (c.isPlayer || !c.alive) continue;
      if (c.pos.distanceTo(pos) < radius && Math.random() < 0.6) {
        c.aiTargetPos.copy(pos);
      }
    }
  }

  // Main Simulation Tick
  private startLoop() {
    this.lastFrameAt = performance.now();
    const tick = () => {
      if (this.disposed) return;

      const now = performance.now();
      if (!this.isSoftwareGl && this.settings.targetFps < 120) {
        const minIntervalMs = 1000 / this.settings.targetFps - 1.5;
        if (now - this.lastFrameAt < minIntervalMs) {
          this.frameId = requestAnimationFrame(tick);
          return;
        }
      }
      const frameDeltaSec = Math.max(0.001, (now - this.lastFrameAt) / 1000);
      this.lastFrameAt = now;

      this.fpsFrames += 1;
      this.fpsAccum += frameDeltaSec;
      if (this.fpsAccum >= 0.5) {
        this.liveFps = Math.max(1, Math.round(this.fpsFrames / this.fpsAccum));
        this.fpsFrames = 0;
        this.fpsAccum = 0;
        if (this.phase === 'menu') {
          this.emitHud();
        }
      }

      const rawDt = this.clock.getDelta();
      const dt = Math.min(rawDt, 0.05);

      if (this.hitstopTimer > 0) {
        this.hitstopTimer -= dt;
      } else {
        this.updateSimulation(dt);
      }

      const useComposer =
        !this.isSoftwareGl &&
        this.composer !== null &&
        (this.settings.quality === 'hdr' || this.settings.quality === 'ultra');
      if (useComposer) {
        this.composer!.render();
      } else {
        this.renderer.render(this.scene, this.camera);
      }

      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.afterDraw(tick);
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || !gl.fenceSync) {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private updateSimulation(dt: number) {
    if (this.phase === 'menu') {
      this.menuOrbitAngle += dt * 0.45;
      if (this.lobbyShowcaseGroup && this.lobbyHero) {
        const basePos = this.lobbyShowcaseGroup.position;
        this.lobbyHero.root.rotation.y = Math.PI + this.lobbyDragYaw;
        // Subtle lifelike breathing & idle readiness
        this.lobbyHero.bodyPivot.position.y = Math.sin(this.menuOrbitAngle * 2.2) * 0.012;
        this.lobbyHero.headGroup.rotation.y = Math.sin(this.menuOrbitAngle * 0.9) * 0.09;

        // Flickering fire & billowing smoke backdrop
        for (const fl of this.lobbyFlames) {
          const pulse = 1 + Math.sin(this.menuOrbitAngle * fl.speed + fl.phase) * 0.14;
          fl.mesh.scale.setScalar(fl.baseScale * pulse);
          fl.mesh.position.y = fl.baseY + Math.sin(this.menuOrbitAngle * fl.speed * 0.7 + fl.phase) * 0.12;
          fl.mesh.rotation.y += dt * 0.6;
        }
        if (this.lobbyFireLight) {
          this.lobbyFireLight.intensity = 13 + Math.sin(this.menuOrbitAngle * 9.5) * 2.8;
        }

        const camSwayX = Math.sin(this.menuOrbitAngle * 0.45) * 0.16;
        this.camera.position.set(basePos.x + camSwayX, basePos.y + 1.26, basePos.z + 3.45);
        this.camera.lookAt(basePos.x, basePos.y + 1.18, basePos.z - 1.5);
      }
      if (this.transportPlane) {
        const planeAngle = this.menuOrbitAngle * 0.25;
        this.transportPlane.root.position.set(
          Math.cos(planeAngle) * 80,
          72,
          Math.sin(planeAngle) * 80 - 25,
        );
        this.transportPlane.root.rotation.y = -planeAngle;
        this.transportPlane.props.forEach((p) => (p.rotation.z += dt * 28));
      }
      return;
    }

    if (this.phase === 'paused' || this.phase === 'victory' || this.phase === 'gameover') {
      return;
    }

    this.survivalTimeSec += dt;
    if (this.killfeed.length > 0) {
      this.killfeed = this.killfeed.filter((k) => this.survivalTimeSec - k.timestamp <= 12);
    }
    this.weatherTime += dt;
    this.hitmarkerTime = Math.max(0, this.hitmarkerTime - dt);
    this.damageFlashTime = Math.max(0, this.damageFlashTime - dt);
    this.stunFlashAlpha = Math.max(0, this.stunFlashAlpha - dt * 0.85);
    this.shakeIntensity = Math.max(0, this.shakeIntensity - dt * 0.25);

    if (this.muzzleFlashTimer > 0) {
      this.muzzleFlashTimer -= dt;
      if (this.muzzleFlashTimer <= 0) {
        this.muzzleLight.intensity = 0;
        if (this.fppMuzzleFlash) this.fppMuzzleFlash.visible = false;
      }
    }
    this.fppRecoilOffset = THREE.MathUtils.damp(this.fppRecoilOffset, 0, 14, dt);

    // Dynamic weather cycle
    if (this.rainPoints) {
      const cycle = Math.sin(this.weatherTime * 0.035);
      const showPrecip = this.mapId === 'snow' || this.mapId === 'jungle' || cycle > 0.35;
      this.rainPoints.visible = showPrecip;
      if (showPrecip) {
        this.weatherLabel = this.mapId === 'snow' ? 'تساقط ثلوج' : 'أمطار وضباب خفيف';
        this.rainPoints.position.set(this.player.pos.x, this.player.pos.y, this.player.pos.z);
        const pos = this.rainPoints.geometry.attributes.position as THREE.BufferAttribute;
        const fallSpeed = this.mapId === 'snow' ? 6 : 26;
        for (let i = 0; i < pos.count; i++) {
          let py = pos.getY(i) - fallSpeed * dt;
          if (py < -2) py = 42;
          pos.setY(i, py);
        }
        pos.needsUpdate = true;
      } else {
        this.weatherLabel = 'سماء صافية';
      }
    }

    // Transport Plane Flight
    if (this.transportPlane) {
      this.planeProgress += dt * 0.042;
      this.transportPlane.props.forEach((p) => (p.rotation.z += dt * 32));
      if (this.planeProgress <= 1.15) {
        this.transportPlane.root.position.lerpVectors(
          this.planeStart,
          this.planeEnd,
          Math.min(1, this.planeProgress),
        );
        this.transportPlane.root.lookAt(this.planeEnd);
        this.transportPlane.root.rotateY(Math.PI);
      } else {
        this.transportPlane.root.visible = false;
      }
      if (this.phase === 'plane' && this.planeProgress >= 0.92) {
        this.jumpFromPlane();
      }
    }

    // Update Player according to Phase
    if (this.phase === 'plane') {
      this.player.pos.copy(this.transportPlane!.root.position);
      this.lastPlayerPos.copy(this.player.pos);
      this.player.visual.root.visible = false;
      this.updatePlaneCamera(dt);
    } else if (this.phase === 'skydiving') {
      this.updateSkydiving(dt);
      const stepDist = Math.hypot(
        this.player.pos.x - this.lastPlayerPos.x,
        this.player.pos.z - this.lastPlayerPos.z,
      );
      if (stepDist > 0 && stepDist < 20) this.distanceTraveledMeters += stepDist;
      this.lastPlayerPos.copy(this.player.pos);
    } else if (this.phase === 'playing') {
      this.updatePlayerGroundOrVehicle(dt);
      const stepDist = Math.hypot(
        this.player.pos.x - this.lastPlayerPos.x,
        this.player.pos.z - this.lastPlayerPos.z,
      );
      if (stepDist > 0 && stepDist < 20) this.distanceTraveledMeters += stepDist;
      this.lastPlayerPos.copy(this.player.pos);
    }

    // Update Bots & Allies
    this.updateAiCombatants(dt);

    // Update Zones, Airdrops, Redzone
    this.updateZonesAndEvents(dt);

    // Update Projectiles, Throwables, Smoke, Fire, Particles, Combat VFX, Vehicles VFX
    this.updateProjectiles(dt);
    this.updateThrowables(dt);
    this.updateSmokeAndFire(dt);
    this.updateParticles(dt);
    this.updateVehiclesVfx(dt);
    this.updateVfxEntities(dt);

    // Animate loot hover
    const tNow = this.survivalTimeSec;
    for (const entry of this.lootEntries) {
      if (!entry.item.pickedUp) {
        entry.mesh.rotation.y = tNow * 1.4;
      }
    }

    // Proximity Voice Chat spatial update & remote peer 3D rendering
    const activeWepId = this.player.weapons[this.player.activeSlot]?.defId ?? '';
    this.voice.updateSelfSpatial(
      this.player.pos.x,
      this.player.pos.y,
      this.player.pos.z,
      this.player.yaw,
      this.player.alive,
      this.survivalTimeSec,
      this.player.stance,
      activeWepId,
      Math.round(this.player.health),
    );
    this.syncRemotePeersInScene();

    // Check Victory / GameOver
    this.checkMatchOutcome();

    // Throttled HUD snapshot emit (~20Hz)
    this.hudEmitTimer += dt;
    if (this.hudEmitTimer >= 0.05) {
      this.hudEmitTimer = 0;
      this.emitHud();
    }
  }

  private syncRemotePeersInScene() {
    if (this.networkMode === 'offline') {
      if (this.remotePeerVisuals.size > 0) {
        this.remotePeerVisuals.forEach((rv) => this.scene.remove(rv.visual.root));
        this.remotePeerVisuals.clear();
      }
      return;
    }

    const activeIds = new Set<string>();
    for (const [pid, peer] of this.voice.peers.entries()) {
      activeIds.add(pid);
      let entry = this.remotePeerVisuals.get(pid);
      if (!entry) {
        const isAlly = peer.teamId === 0 && this.mode !== 'solo';
        const visual = buildCharacterModel(isAlly ? 0x2b6cb0 : 0xd97706, isAlly, true);
        const ring = new THREE.Mesh(
          new THREE.TorusGeometry(0.28, 0.045, 8, 20),
          new THREE.MeshBasicMaterial({ color: isAlly ? 0x38bdf8 : 0x22c55e }),
        );
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 2.15;
        ring.visible = false;
        visual.root.add(ring);
        this.scene.add(visual.root);
        entry = { visual, ring, heldWeaponId: '' };
        this.remotePeerVisuals.set(pid, entry);
      }

      entry.visual.root.visible = peer.alive;
      entry.visual.root.position.set(peer.x, peer.y, peer.z);
      entry.visual.root.rotation.y = peer.yaw;
      entry.ring.visible = peer.alive && peer.speaking;

      const peerStance = peer.stance ?? 'stand';
      entry.visual.bodyPivot.position.y =
        peerStance === 'prone' ? -0.9 : peerStance === 'crouch' ? -0.42 : 0;
      entry.visual.bodyPivot.rotation.x = peerStance === 'prone' ? -Math.PI * 0.42 : 0;

      const wepId = peer.weaponId || '';
      if (entry.heldWeaponId !== wepId) {
        entry.heldWeaponId = wepId;
        while (entry.visual.weaponMount.children.length > 0) {
          entry.visual.weaponMount.remove(entry.visual.weaponMount.children[0]);
        }
        if (wepId && WEAPONS[wepId]) {
          const wm = buildWeaponMesh(wepId, 'iron', false);
          wm.scale.setScalar(0.85);
          entry.visual.weaponMount.add(wm);
        }
      }
    }

    for (const [pid, entry] of this.remotePeerVisuals.entries()) {
      if (!activeIds.has(pid)) {
        this.scene.remove(entry.visual.root);
        this.remotePeerVisuals.delete(pid);
      }
    }
  }

  private updatePlaneCamera(dt: number) {
    // Allow keyboard arrow aim fallback
    if (this.heldKeys.has('ArrowLeft')) this.player.yaw += dt * 1.8;
    if (this.heldKeys.has('ArrowRight')) this.player.yaw -= dt * 1.8;

    const offset = new THREE.Vector3(0, 7, 26).applyAxisAngle(
      new THREE.Vector3(0, 1, 0),
      this.player.yaw,
    );
    const targetCam = this.transportPlane!.root.position.clone().add(offset);
    this.currentCamPos.lerp(targetCam, 1 - Math.exp(-8 * dt));
    this.camera.position.copy(this.currentCamPos);
    this.camera.lookAt(this.transportPlane!.root.position);
  }

  private updateSkydiving(dt: number) {
    this.player.visual.root.visible = true;
    this.fppMount.visible = false;

    if (this.heldKeys.has('ArrowLeft')) this.player.yaw += dt * 2.1;
    if (this.heldKeys.has('ArrowRight')) this.player.yaw -= dt * 2.1;

    const forward = new THREE.Vector3(-Math.sin(this.player.yaw), 0, -Math.cos(this.player.yaw));
    const right = new THREE.Vector3(Math.cos(this.player.yaw), 0, -Math.sin(this.player.yaw));

    const horizSpeed = this.parachuteOpen ? 16 : 24;
    const fallSpeed = this.parachuteOpen ? -6.8 : -22;

    const move = new THREE.Vector3();
    if (this.heldKeys.has('KeyW')) move.add(forward);
    if (this.heldKeys.has('KeyS')) move.sub(forward);
    if (this.heldKeys.has('KeyD')) move.add(right);
    if (this.heldKeys.has('KeyA')) move.sub(right);
    if (Math.abs(this.touchMoveY) > 0.08) move.addScaledVector(forward, this.touchMoveY);
    if (Math.abs(this.touchMoveX) > 0.08) move.addScaledVector(right, this.touchMoveX);
    if (move.lengthSq() > 1) move.normalize();
    else if (move.lengthSq() > 0 && Math.abs(this.touchMoveX) < 0.08 && Math.abs(this.touchMoveY) < 0.08) {
      move.normalize();
    }

    this.player.pos.x += move.x * horizSpeed * dt;
    this.player.pos.z += move.z * horizSpeed * dt;
    this.player.pos.y += fallSpeed * dt;

    const gh = this.world!.groundHeightAt(this.player.pos.x, this.player.pos.z);
    if (!this.parachuteOpen && this.player.pos.y - gh <= 22) {
      this.parachuteOpen = true;
      this.player.visual.parachuteGroup.visible = true;
      soundEngine.playPickup();
    }

    if (this.player.pos.y <= gh) {
      this.player.pos.y = gh;
      this.parachuteOpen = false;
      this.player.visual.parachuteGroup.visible = false;
      this.phase = 'playing';
      soundEngine.playFootstep(true);
    }

    this.player.visual.root.position.copy(this.player.pos);
    this.player.visual.root.rotation.y = this.player.yaw;
    this.player.contactShadow.position.set(this.player.pos.x, gh + 0.04, this.player.pos.z);

    // Camera follows behind skydiver
    const camDist = this.parachuteOpen ? 6.5 : 5.0;
    const desiredCam = this.player.pos
      .clone()
      .add(new THREE.Vector3(Math.sin(this.player.yaw) * camDist, 2.8, Math.cos(this.player.yaw) * camDist));
    this.currentCamPos.lerp(desiredCam, 1 - Math.exp(-8 * dt));
    this.camera.position.copy(this.currentCamPos);
    this.camera.lookAt(this.player.pos.x, this.player.pos.y + 1.2, this.player.pos.z);
  }

  private updatePlayerGroundOrVehicle(dt: number) {
    if (!this.player.alive) return;

    // Keyboard arrow look fallback
    const keyTurnSpeed = 1.9 * (this.isAds ? 0.55 : 1);
    if (this.heldKeys.has('ArrowLeft')) this.player.yaw += keyTurnSpeed * dt;
    if (this.heldKeys.has('ArrowRight')) this.player.yaw -= keyTurnSpeed * dt;
    if (this.heldKeys.has('ArrowUp'))
      this.player.pitch = THREE.MathUtils.clamp(this.player.pitch + keyTurnSpeed * 0.7 * dt, -1.32, 1.28);
    if (this.heldKeys.has('ArrowDown'))
      this.player.pitch = THREE.MathUtils.clamp(this.player.pitch - keyTurnSpeed * 0.7 * dt, -1.32, 1.28);

    // Cooldowns, Reload, Meds, Boost Regen
    this.player.fireCooldown = Math.max(0, this.player.fireCooldown - dt);

    if (this.player.boost > 0) {
      this.player.boost = Math.max(0, this.player.boost - dt * 1.4);
      const regenRate = this.player.boost > 60 ? 3.5 : 1.6;
      this.player.health = Math.min(this.player.maxHealth, this.player.health + regenRate * dt);
    }

    if (this.isReloading) {
      this.reloadTimer += dt;
      if (this.reloadTimer >= this.reloadDuration) {
        this.completeReload();
      }
    }

    if (this.isUsingMed) {
      this.medUseTimer += dt;
      if (this.medUseTimer >= this.medUseDuration) {
        this.completeMedUse();
      }
    }

    // Continuous auto-fire if holding left mouse or touch fire button
    if ((this.mouseLeftDown || this.touchFiring) && !this.inVehicle) {
      this.tryPlayerShoot(false);
    }

    if (this.inVehicle) {
      this.updateDrivingVehicle(dt);
    } else {
      this.updatePlayerMovement(dt);
    }

    this.updatePlayerCamera(dt);
  }

  private completeReload() {
    this.isReloading = false;
    const w = this.player.weapons[this.player.activeSlot];
    if (!w) return;
    const def = WEAPONS[w.defId];
    const cap = w.extendedMag ? def.extendedMagSize : def.magSize;
    const needed = cap - w.ammoInMag;
    const avail = this.ammoBag[def.ammoType];
    const take = Math.min(needed, avail);
    w.ammoInMag += take;
    this.ammoBag[def.ammoType] -= take;
    soundEngine.playPickup();
  }

  private completeMedUse() {
    this.isUsingMed = false;
    if (this.meds[this.medUseType] <= 0) return;
    this.meds[this.medUseType] -= 1;
    const info = MED_INFO[this.medUseType];
    if (info.healAmount > 0) {
      this.player.health = Math.min(info.healTo, this.player.health + info.healAmount);
    }
    if (info.boostAmount > 0) {
      this.player.boost = Math.min(100, this.player.boost + info.boostAmount);
    }
    soundEngine.playPickup();
  }

  private updatePlayerMovement(dt: number) {
    const forward = _v1.set(-Math.sin(this.player.yaw), 0, -Math.cos(this.player.yaw));
    const right = _v2.set(Math.cos(this.player.yaw), 0, -Math.sin(this.player.yaw));

    const move = _v3.set(0, 0, 0);
    if (this.heldKeys.has('KeyW')) move.add(forward);
    if (this.heldKeys.has('KeyS')) move.sub(forward);
    if (this.heldKeys.has('KeyD')) move.add(right);
    if (this.heldKeys.has('KeyA')) move.sub(right);
    if (Math.abs(this.touchMoveY) > 0.08) move.addScaledVector(forward, this.touchMoveY);
    if (Math.abs(this.touchMoveX) > 0.08) move.addScaledVector(right, this.touchMoveX);

    const moveLen = move.length();
    const isMoving = moveLen > 0.01;
    if (moveLen > 1) {
      move.divideScalar(moveLen);
    } else if (isMoving && Math.abs(this.touchMoveX) < 0.08 && Math.abs(this.touchMoveY) < 0.08) {
      move.divideScalar(moveLen);
    }

    const boostSpeedMult = this.player.boost > 50 ? 1.1 : 1.0;
    const isSprinting =
      ((this.heldKeys.has('ShiftLeft') && this.heldKeys.has('KeyW')) || this.touchSprint) &&
      this.player.stance === 'stand' &&
      !this.isAds &&
      !this.isUsingMed;

    let speed =
      this.player.stance === 'prone'
        ? 2.2
        : this.player.stance === 'crouch'
          ? 4.0
          : isSprinting
            ? 8.4
            : 5.6;
    if (this.isAds) speed *= 0.65;
    if (this.isUsingMed) speed *= 0.45;
    speed *= boostSpeedMult;

    this.player.pos.x += move.x * speed * dt;
    this.player.pos.z += move.z * speed * dt;

    // Gravity & Ground clamp
    this.player.vel.y -= 19.5 * dt;
    this.player.pos.y += this.player.vel.y * dt;

    const gh = this.world!.groundHeightAt(this.player.pos.x, this.player.pos.z);
    if (this.player.pos.y <= gh) {
      this.player.pos.y = gh;
      this.player.vel.y = 0;
    }

    // Clamp to island & resolve building/tree collisions
    this.resolveActorCollisions(this.player.pos, 0.45);

    // Footstep sound & limb animation
    if (isMoving && this.player.pos.y <= gh + 0.08) {
      this.stepTimer += dt * (isSprinting ? 2.8 : 1.9);
      this.fppBobTime += dt * (isSprinting ? 12 : 8);
      if (this.stepTimer >= 1) {
        this.stepTimer = 0;
        soundEngine.playFootstep(isSprinting);
      }
      const swing = Math.sin(this.survivalTimeSec * (isSprinting ? 13 : 8)) * 0.55;
      this.player.visual.leftLeg.rotation.x = swing;
      this.player.visual.rightLeg.rotation.x = -swing;
    } else {
      this.player.visual.leftLeg.rotation.x = THREE.MathUtils.damp(
        this.player.visual.leftLeg.rotation.x,
        0,
        10,
        dt,
      );
      this.player.visual.rightLeg.rotation.x = THREE.MathUtils.damp(
        this.player.visual.rightLeg.rotation.x,
        0,
        10,
        dt,
      );
    }

    // Stance & Lean visual pose
    const targetBodyY =
      this.player.stance === 'prone' ? -0.9 : this.player.stance === 'crouch' ? -0.42 : 0;
    this.player.visual.bodyPivot.position.y = THREE.MathUtils.damp(
      this.player.visual.bodyPivot.position.y,
      targetBodyY,
      12,
      dt,
    );
    this.player.visual.bodyPivot.rotation.x = THREE.MathUtils.damp(
      this.player.visual.bodyPivot.rotation.x,
      this.player.stance === 'prone' ? -Math.PI * 0.42 : 0,
      10,
      dt,
    );
    this.player.visual.bodyPivot.rotation.z = THREE.MathUtils.damp(
      this.player.visual.bodyPivot.rotation.z,
      -this.player.lean * 0.24,
      12,
      dt,
    );
    this.player.visual.rightArm.rotation.x = Math.PI * 0.44 + this.player.pitch * 0.5;
    this.player.visual.leftArm.rotation.x = Math.PI * 0.42 + this.player.pitch * 0.4;

    this.player.visual.root.position.copy(this.player.pos);
    this.player.visual.root.rotation.y = this.player.yaw;
    this.player.contactShadow.position.set(this.player.pos.x, gh + 0.03, this.player.pos.z);
  }

  private updateDrivingVehicle(dt: number) {
    const v = this.inVehicle!;
    const maxFwd = v.kind === 'motorcycle' ? 28 : 22;
    const accel = v.kind === 'motorcycle' ? 18 : 13;

    const throttle = this.heldKeys.has('KeyW')
      ? 1
      : this.heldKeys.has('KeyS')
        ? -1
        : this.touchVehThrottle;
    const braking = this.heldKeys.has('Space') || this.touchVehBrake;

    if (throttle > 0.1) {
      v.speed = Math.min(
        maxFwd * (this.heldKeys.has('ShiftLeft') ? 1.2 : 1),
        v.speed + accel * throttle * dt,
      );
    } else if (throttle < -0.1) {
      v.speed = Math.max(-9, v.speed + accel * 1.1 * throttle * dt);
    } else if (braking) {
      v.speed = THREE.MathUtils.damp(v.speed, 0, 8, dt);
    } else {
      v.speed = THREE.MathUtils.damp(v.speed, 0, 2.2, dt);
    }

    const steerRate = v.kind === 'motorcycle' ? 2.4 : 1.8;
    const steerFactor = Math.min(1, Math.abs(v.speed) / 4) * (v.speed >= 0 ? 1 : -1);
    const steerCmd =
      (this.heldKeys.has('KeyA') ? 1 : 0) -
      (this.heldKeys.has('KeyD') ? 1 : 0) +
      this.touchVehSteer;
    v.yaw += steerRate * steerFactor * THREE.MathUtils.clamp(steerCmd, -1, 1) * dt;

    v.pos.x += -Math.sin(v.yaw) * v.speed * dt;
    v.pos.z += -Math.cos(v.yaw) * v.speed * dt;

    const r = this.world!.worldRadius - 8;
    const dist = Math.hypot(v.pos.x, v.pos.z);
    if (dist > r) {
      v.pos.x *= r / dist;
      v.pos.z *= r / dist;
      v.speed *= 0.4;
    }

    const gh = this.world!.groundHeightAt(v.pos.x, v.pos.z);
    v.pos.y = gh;
    v.visual.root.position.copy(v.pos);
    v.visual.root.rotation.y = v.yaw;

    // Spin wheels
    const wheelSpin = v.speed * dt * 2.2;
    v.visual.wheels.forEach((w) => (w.rotation.x -= wheelSpin));

    // Sync player position with vehicle & roadkill collision
    this.player.pos.copy(v.pos);
    soundEngine.updateEngine(true, v.speed / maxFwd);

    if (Math.abs(v.speed) > 9) {
      this.alertBotsNear(v.pos, 110);
      for (const c of this.combatants) {
        if (!c.alive || c.isPlayer || c.teamId === this.player.teamId) continue;
        if (c.pos.distanceTo(v.pos) < 2.4) {
          this.applyDamage(c, 95, this.player, 'مركبة قتالية', false, v.pos);
        }
      }
    }
  }

  private updatePlayerCamera(dt: number) {
    const wInst = this.player.weapons[this.player.activeSlot];
    const activeScope: ScopeType = wInst
      ? (WEAPONS[wInst.defId].builtInScope ?? wInst.scope)
      : 'iron';
    const targetFov = this.isAds ? (wInst ? SCOPE_INFO[activeScope].fov : 52) : 70;
    this.currentFov = THREE.MathUtils.damp(this.currentFov, targetFov, 14, dt);
    if (Math.abs(this.camera.fov - this.currentFov) > 0.05) {
      this.camera.fov = this.currentFov;
      this.camera.updateProjectionMatrix();
    }

    const eyeHeight =
      this.player.stance === 'prone' ? 0.55 : this.player.stance === 'crouch' ? 1.15 : 1.62;
    const leanOffset = this.player.lean * 0.45;

    // Enter smooth first-person ADS whenever scoping with a weapon (or in FPP mode)
    const useFirstPersonView =
      !this.inVehicle &&
      (this.perspective === 'fpp' || (this.isAds && Boolean(wInst)));

    this.player.visual.root.visible = !useFirstPersonView && !this.inVehicle;
    this.fppMount.visible = useFirstPersonView && !this.inVehicle;

    if (useFirstPersonView) {
      const rightX = Math.cos(this.player.yaw) * leanOffset;
      const rightZ = -Math.sin(this.player.yaw) * leanOffset;
      const eyePos = _v4.set(
        this.player.pos.x + rightX,
        this.player.pos.y + eyeHeight,
        this.player.pos.z + rightZ,
      );
      this.camera.position.copy(eyePos);
      _euler.set(this.player.pitch, this.player.yaw, -this.player.lean * 0.09, 'YXZ');
      this.camera.quaternion.setFromEuler(_euler);

      if (this.fppWeaponMesh) {
        // Hide weapon mesh when looking through high-zoom overlay scope
        this.fppWeaponMesh.visible = !(this.isAds && (activeScope === '4x' || activeScope === '8x'));
        const targetX = this.isAds ? 0 : 0.24;
        const targetY = this.isAds ? -0.14 : -0.22 + Math.sin(this.fppBobTime) * 0.008;
        const targetZ = (this.isAds ? -0.34 : -0.45) + this.fppRecoilOffset;
        this.fppWeaponMesh.position.x = THREE.MathUtils.damp(this.fppWeaponMesh.position.x, targetX, 16, dt);
        this.fppWeaponMesh.position.y = THREE.MathUtils.damp(this.fppWeaponMesh.position.y, targetY, 16, dt);
        this.fppWeaponMesh.position.z = THREE.MathUtils.damp(this.fppWeaponMesh.position.z, targetZ, 18, dt);
        this.fppWeaponMesh.rotation.x = this.isReloading ? -0.6 : this.fppRecoilOffset * 1.8;
      }
    } else {
      // Smooth Third-Person Over-Shoulder Camera
      const dist = this.inVehicle ? (this.inVehicle.kind === 'offroader' ? 7.6 : 5.4) : this.isAds ? 2.1 : 3.7;
      const shoulder = this.inVehicle ? 0 : 0.62 + leanOffset;
      const camYaw = this.player.yaw;
      const camPitch = this.player.pitch;

      const sinY = Math.sin(camYaw);
      const cosY = Math.cos(camYaw);
      const cosP = Math.cos(camPitch);
      const sinP = Math.sin(camPitch);

      const backX = sinY * cosP * dist + cosY * shoulder;
      const backZ = cosY * cosP * dist - sinY * shoulder;
      const backY = -sinP * dist + (this.inVehicle ? 2.5 : eyeHeight + 0.25);

      const desiredX = this.player.pos.x + backX;
      const desiredZ = this.player.pos.z + backZ;
      const minGroundY = this.world!.groundHeightAt(desiredX, desiredZ) + 0.55;
      const desiredY = Math.max(minGroundY, this.player.pos.y + backY);

      this.currentCamPos.x = THREE.MathUtils.damp(this.currentCamPos.x, desiredX, 18, dt);
      this.currentCamPos.y = THREE.MathUtils.damp(this.currentCamPos.y, desiredY, 18, dt);
      this.currentCamPos.z = THREE.MathUtils.damp(this.currentCamPos.z, desiredZ, 18, dt);

      // Look point ahead along aim vector
      const lookDist = 28;
      const lookX = this.player.pos.x - sinY * cosP * lookDist + cosY * shoulder * 0.4;
      const lookZ = this.player.pos.z - cosY * cosP * lookDist - sinY * shoulder * 0.4;
      const lookY = this.player.pos.y + eyeHeight + sinP * lookDist;

      this.currentCamLook.x = THREE.MathUtils.damp(this.currentCamLook.x, lookX, 20, dt);
      this.currentCamLook.y = THREE.MathUtils.damp(this.currentCamLook.y, lookY, 20, dt);
      this.currentCamLook.z = THREE.MathUtils.damp(this.currentCamLook.z, lookZ, 20, dt);

      this.camera.position.copy(this.currentCamPos);
      this.camera.lookAt(this.currentCamLook);
    }

    // Apply decaying camera shake
    if (this.shakeIntensity > 0.001) {
      this.camera.position.x += (Math.random() - 0.5) * this.shakeIntensity;
      this.camera.position.y += (Math.random() - 0.5) * this.shakeIntensity;
    }
  }

  private resolveActorCollisions(pos: THREE.Vector3, radius: number) {
    if (!this.world) return;
    const maxR = this.world.worldRadius - 4;
    const dCenter = Math.hypot(pos.x, pos.z);
    if (dCenter > maxR) {
      pos.x *= maxR / dCenter;
      pos.z *= maxR / dCenter;
    }

    // Building wall AABBs
    for (const c of this.world.colliders) {
      if (pos.y > c.maxY) continue;
      const closestX = THREE.MathUtils.clamp(pos.x, c.minX, c.maxX);
      const closestZ = THREE.MathUtils.clamp(pos.z, c.minZ, c.maxZ);
      const dx = pos.x - closestX;
      const dz = pos.z - closestZ;
      const distSq = dx * dx + dz * dz;
      if (distSq < radius * radius) {
        const dist = Math.sqrt(distSq);
        if (dist > 0.0001) {
          pos.x += (dx / dist) * (radius - dist);
          pos.z += (dz / dist) * (radius - dist);
        } else {
          pos.x += radius;
        }
      }
    }

    // Tree & Rock cylinders
    for (const tr of this.world.treePositions) {
      const dx = pos.x - tr.x;
      const dz = pos.z - tr.z;
      const minD = radius + tr.r;
      const dSq = dx * dx + dz * dz;
      if (dSq < minD * minD && dSq > 0.0001) {
        const d = Math.sqrt(dSq);
        pos.x = tr.x + (dx / d) * minD;
        pos.z = tr.z + (dz / d) * minD;
      }
    }
  }

  private updateAiCombatants(dt: number) {
    for (const bot of this.combatants) {
      if (bot.isPlayer || !bot.alive) continue;
      bot.fireCooldown = Math.max(0, bot.fireCooldown - dt);
      bot.aiThinkTimer -= dt;

      // Zone damage to bots
      const dToZone = Math.hypot(bot.pos.x - this.safeZone.x, bot.pos.z - this.safeZone.z);
      if (dToZone > this.safeZone.r) {
        bot.health -= (1.6 + this.zonePhase * 1.1) * dt;
        if (bot.health <= 0) {
          this.killCombatant(bot, null, 'العاصفة المغناطيسية', false);
          continue;
        }
      }

      // Find nearest visible enemy
      let nearestEnemy: Combatant | null = null;
      let nearestDist = 115;
      for (const other of this.combatants) {
        if (!other.alive || other.teamId === bot.teamId) continue;
        if (other.isPlayer && (this.phase === 'plane' || this.phase === 'skydiving')) continue;
        const d = bot.pos.distanceTo(other.pos);
        const detectRange = other.hasGhillie ? 64 : 115;
        if (d < nearestDist && d < detectRange && !this.isBlockedBySmoke(bot.pos, other.pos)) {
          nearestDist = d;
          nearestEnemy = other;
        }
      }

      if (bot.aiThinkTimer <= 0) {
        bot.aiThinkTimer = 0.7 + Math.random() * 0.9;
        bot.aiStrafeDir = Math.random() < 0.5 ? 1 : -1;

        if (dToZone > this.safeZone.r * 0.9) {
          // Move inward toward safe zone
          const ang = Math.atan2(this.safeZone.z - bot.pos.z, this.safeZone.x - bot.pos.x);
          bot.aiTargetPos.set(
            bot.pos.x + Math.cos(ang) * 28,
            0,
            bot.pos.z + Math.sin(ang) * 28,
          );
        } else if (bot.teamId === this.player.teamId && this.phase === 'playing') {
          // Ally follows player tactically!
          const followAng = this.player.yaw + (bot.id.endsWith('1') ? 1.1 : -1.1);
          bot.aiTargetPos.set(
            this.player.pos.x + Math.cos(followAng) * 9,
            0,
            this.player.pos.z + Math.sin(followAng) * 9,
          );
        } else if (!nearestEnemy) {
          // Patrol near safe zone
          const ang = Math.random() * Math.PI * 2;
          const dist = Math.random() * this.safeZone.r * 0.75;
          bot.aiTargetPos.set(
            this.safeZone.x + Math.cos(ang) * dist,
            0,
            this.safeZone.z + Math.sin(ang) * dist,
          );
        }
      }

      // Movement & Engagement
      let moveSpeed = 4.2;
      let moveVecX = 0;
      let moveVecZ = 0;

      if (nearestEnemy) {
        const dx = nearestEnemy.pos.x - bot.pos.x;
        const dz = nearestEnemy.pos.z - bot.pos.z;
        const targetYaw = Math.atan2(-dx, -dz);
        bot.yaw = targetYaw;

        if (nearestDist > 34) {
          moveVecX = dx / nearestDist;
          moveVecZ = dz / nearestDist;
        } else {
          // Tactical strafing
          moveVecX = Math.cos(bot.yaw) * bot.aiStrafeDir;
          moveVecZ = -Math.sin(bot.yaw) * bot.aiStrafeDir;
          moveSpeed = 3.1;
        }

        // Fire burst if weapon ready & line-of-sight roughly clear
        const w = bot.weapons[0];
        if (w && bot.fireCooldown <= 0 && !this.isBlockedByWall(bot.pos, nearestEnemy.pos)) {
          const def = WEAPONS[w.defId];
          bot.fireCooldown = (def.fireRateMs / 1000) * 1.9 + Math.random() * 0.16;
          const origin = bot.pos.clone().add(new THREE.Vector3(0, 1.42, 0));
          const aimTarget = nearestEnemy.pos.clone().add(new THREE.Vector3(0, 1.2, 0));
          const dir = aimTarget.sub(origin).normalize();
          // Bot accuracy jitter
          const err = 0.055;
          dir.x += (Math.random() - 0.5) * err;
          dir.y += (Math.random() - 0.5) * err * 0.6;
          dir.z += (Math.random() - 0.5) * err;
          dir.normalize();
          const suppressed = Boolean(def.builtInSuppressor);
          this.spawnProjectile(bot, origin, dir, def.id, false);
          const muzzlePos = origin.clone().addScaledVector(dir, 0.72);
          this.spawnMuzzleFlash(muzzlePos, dir, suppressed);
          this.spawnShellCasing(origin, bot.yaw);

          const distToPlayer = bot.pos.distanceTo(this.player.pos);
          soundEngine.playShot(def.category, suppressed, distToPlayer);
        }
      } else {
        const dx = bot.aiTargetPos.x - bot.pos.x;
        const dz = bot.aiTargetPos.z - bot.pos.z;
        const dist = Math.hypot(dx, dz);
        if (dist > 2.2) {
          moveVecX = dx / dist;
          moveVecZ = dz / dist;
          bot.yaw = Math.atan2(-moveVecX, -moveVecZ);
        } else {
          moveSpeed = 0;
        }
      }

      bot.pos.x += moveVecX * moveSpeed * dt;
      bot.pos.z += moveVecZ * moveSpeed * dt;
      this.resolveActorCollisions(bot.pos, 0.45);
      const gh = this.world!.groundHeightAt(bot.pos.x, bot.pos.z);
      bot.pos.y = gh;

      // Animate bot legs
      if (moveSpeed > 0.2) {
        const swing = Math.sin(this.survivalTimeSec * 8 + bot.teamId) * 0.5;
        bot.visual.leftLeg.rotation.x = swing;
        bot.visual.rightLeg.rotation.x = -swing;
      }
      bot.visual.rightArm.rotation.x = Math.PI * 0.42;
      bot.visual.leftArm.rotation.x = Math.PI * 0.4;
      bot.visual.root.position.copy(bot.pos);
      bot.visual.root.rotation.y = bot.yaw;
      bot.contactShadow.position.set(bot.pos.x, gh + 0.03, bot.pos.z);
    }
  }

  private isBlockedBySmoke(a: THREE.Vector3, b: THREE.Vector3): boolean {
    for (const sm of this.smokeClouds) {
      const distToCenter = this.pointToSegmentDistSq(sm.pos, a, b);
      if (distToCenter < sm.radius * sm.radius) return true;
    }
    return false;
  }

  private pointToSegmentDistSq(p: THREE.Vector3, a: THREE.Vector3, b: THREE.Vector3): number {
    const abx = b.x - a.x;
    const abz = b.z - a.z;
    const lenSq = abx * abx + abz * abz;
    if (lenSq < 0.001) return (p.x - a.x) ** 2 + (p.z - a.z) ** 2;
    const t = THREE.MathUtils.clamp(((p.x - a.x) * abx + (p.z - a.z) * abz) / lenSq, 0, 1);
    const cx = a.x + t * abx;
    const cz = a.z + t * abz;
    return (p.x - cx) ** 2 + (p.z - cz) ** 2;
  }

  private isBlockedByWall(a: THREE.Vector3, b: THREE.Vector3): boolean {
    if (!this.world) return false;
    // Quick 6-sample segment check against building AABBs
    for (let s = 1; s <= 5; s++) {
      const t = s / 6;
      const px = a.x + (b.x - a.x) * t;
      const pz = a.z + (b.z - a.z) * t;
      for (const col of this.world.colliders) {
        if (px >= col.minX && px <= col.maxX && pz >= col.minZ && pz <= col.maxZ) {
          return true;
        }
      }
    }
    return false;
  }

  private updateZonesAndEvents(dt: number) {
    // 1. Bluezone Phase Timer & Shrinking
    this.zoneTimerSec -= dt;
    if (!this.zoneShrinking && this.zoneTimerSec <= 0) {
      this.zoneShrinking = true;
      this.zoneTimerSec = 22;
      this.startZone = { ...this.safeZone };
    } else if (this.zoneShrinking) {
      const t = Math.min(1, 1 - this.zoneTimerSec / 22);
      this.safeZone.x = THREE.MathUtils.lerp(this.startZone.x, this.nextZone.x, t);
      this.safeZone.z = THREE.MathUtils.lerp(this.startZone.z, this.nextZone.z, t);
      this.safeZone.r = THREE.MathUtils.lerp(this.startZone.r, this.nextZone.r, t);
      if (this.zoneTimerSec <= 0) {
        this.zoneShrinking = false;
        this.zonePhase += 1;
        this.zoneTimerSec = Math.max(16, 32 - this.zonePhase * 3);
        const nextR = Math.max(18, this.safeZone.r * 0.56);
        const offsetAng = Math.random() * Math.PI * 2;
        const offsetDist = Math.random() * (this.safeZone.r - nextR) * 0.6;
        this.nextZone = {
          x: this.safeZone.x + Math.cos(offsetAng) * offsetDist,
          z: this.safeZone.z + Math.sin(offsetAng) * offsetDist,
          r: nextR,
        };
      }
    }

    this.blueZoneMesh.position.set(this.safeZone.x, 45, this.safeZone.z);
    this.blueZoneMesh.scale.set(Math.max(1, this.safeZone.r), 1, Math.max(1, this.safeZone.r));

    // Apply Bluezone damage to Player
    if (this.phase === 'playing' && this.player.alive) {
      const d = Math.hypot(this.player.pos.x - this.safeZone.x, this.player.pos.z - this.safeZone.z);
      if (d > this.safeZone.r) {
        this.player.health -= (1.8 + this.zonePhase * 1.2) * dt;
        if (this.player.health <= 0) {
          this.killCombatant(this.player, null, 'العاصفة المغناطيسية', false);
        }
      }
    }

    // 2. Periodic Airdrop
    this.airdropTimer -= dt;
    if (this.airdropTimer <= 0) {
      this.airdropTimer = 46;
      this.spawnAirdrop();
    }
    if (this.airdropAnnounceTimer > 0) {
      this.airdropAnnounceTimer -= dt;
      if (this.airdropAnnounceTimer <= 0) this.airdropAnnounce = null;
    }

    for (const drop of this.airdrops) {
      if (!drop.landed) {
        drop.pos.y -= 9.5 * dt;
        const gh = this.world!.groundHeightAt(drop.pos.x, drop.pos.z);
        if (drop.pos.y <= gh) {
          drop.pos.y = gh;
          drop.landed = true;
          drop.crate.chute.visible = false;
        }
        drop.crate.root.position.copy(drop.pos);
      } else if (!drop.looted) {
        drop.smokeTimer -= dt;
        if (drop.smokeTimer <= 0) {
          drop.smokeTimer = 0.28;
          this.spawnParticleBurst(
            new THREE.Vector3(drop.pos.x, drop.pos.y + 1.8, drop.pos.z),
            1,
            0xef4444,
            3.5,
          );
        }
      }
    }

    // 3. Redzone Air Raid
    this.redZoneTimer -= dt;
    if (!this.redZone && this.redZoneTimer <= 0 && this.safeZone.r > 48) {
      this.redZone = {
        x: this.safeZone.x + (Math.random() - 0.5) * this.safeZone.r * 0.7,
        z: this.safeZone.z + (Math.random() - 0.5) * this.safeZone.r * 0.7,
        r: 36,
      };
      this.redZoneTimer = 14;
      this.redZoneBombTimer = 1.6;
    } else if (this.redZone) {
      this.redZoneBombTimer -= dt;
      if (this.redZoneBombTimer <= 0) {
        this.redZoneBombTimer = 1.8;
        const ang = Math.random() * Math.PI * 2;
        const rad = Math.random() * this.redZone.r;
        const bx = this.redZone.x + Math.cos(ang) * rad;
        const bz = this.redZone.z + Math.sin(ang) * rad;
        const by = this.world!.groundHeightAt(bx, bz);
        this.detonateExplosion(new THREE.Vector3(bx, by + 0.3, bz), 9.5, 85, null, 'القصف الجوي');
      }
      if (this.redZoneTimer <= 0) {
        this.redZone = null;
        this.redZoneTimer = 34;
      }
    }
  }

  private updateProjectiles(dt: number) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.projectiles.splice(i, 1);
        continue;
      }

      const prevPos = _v1.copy(p.pos);
      p.pos.addScaledVector(p.vel, dt);
      p.vel.y -= p.isFlare ? 6 * dt : 2.5 * dt;
      p.mesh.position.copy(p.pos);

      if (p.isFlare) continue;

      // Ground collision
      const gh = this.world!.groundHeightAt(p.pos.x, p.pos.z);
      if (p.pos.y <= gh) {
        const hitPos = new THREE.Vector3(p.pos.x, gh + 0.02, p.pos.z);
        this.spawnSurfaceImpact(hitPos, new THREE.Vector3(0, 1, 0), 'ground');
        this.scene.remove(p.mesh);
        this.projectiles.splice(i, 1);
        continue;
      }

      // Building wall collision with exact face normal for surface bullet hole decals
      let hitWallCol: BuildingCollider | null = null;
      for (const col of this.world!.colliders) {
        if (
          p.pos.y <= col.maxY &&
          p.pos.x >= col.minX &&
          p.pos.x <= col.maxX &&
          p.pos.z >= col.minZ &&
          p.pos.z <= col.maxZ
        ) {
          hitWallCol = col;
          break;
        }
      }
      if (hitWallCol) {
        const dMinX = Math.abs(p.pos.x - hitWallCol.minX);
        const dMaxX = Math.abs(hitWallCol.maxX - p.pos.x);
        const dMinZ = Math.abs(p.pos.z - hitWallCol.minZ);
        const dMaxZ = Math.abs(hitWallCol.maxZ - p.pos.z);
        const dMaxY = Math.abs(hitWallCol.maxY - p.pos.y);
        const minD = Math.min(dMinX, dMaxX, dMinZ, dMaxZ, dMaxY);
        const normal = new THREE.Vector3(0, 1, 0);
        const hitPos = p.pos.clone();
        if (minD === dMinX) {
          normal.set(-1, 0, 0);
          hitPos.x = hitWallCol.minX - 0.02;
        } else if (minD === dMaxX) {
          normal.set(1, 0, 0);
          hitPos.x = hitWallCol.maxX + 0.02;
        } else if (minD === dMinZ) {
          normal.set(0, 0, -1);
          hitPos.z = hitWallCol.minZ - 0.02;
        } else if (minD === dMaxZ) {
          normal.set(0, 0, 1);
          hitPos.z = hitWallCol.maxZ + 0.02;
        } else {
          normal.set(0, 1, 0);
          hitPos.y = hitWallCol.maxY + 0.02;
        }
        this.spawnSurfaceImpact(hitPos, normal, 'wall');
        this.scene.remove(p.mesh);
        this.projectiles.splice(i, 1);
        continue;
      }

      // Vehicle bullet collision & progressive damage
      let hitVehicle: ActiveVehicle | null = null;
      for (const v of this.vehicles) {
        if (v.driverId === p.ownerId) continue;
        const rad = v.kind === 'offroader' ? 2.15 : 1.35;
        if (p.pos.y < v.pos.y - 0.2 || p.pos.y > v.pos.y + 2.0) continue;
        const dSq = this.pointToSegmentDistSq(v.pos, prevPos, p.pos);
        if (dSq < rad * rad) {
          hitVehicle = v;
          break;
        }
      }
      if (hitVehicle) {
        const hitNormal = p.pos.clone().sub(hitVehicle.pos).setY(0.35).normalize();
        this.spawnSurfaceImpact(p.pos, hitNormal, 'metal');
        if (hitVehicle.hp > 0 && !p.ownerId.startsWith('remote_')) {
          hitVehicle.hp = Math.max(0, hitVehicle.hp - p.damage * 0.72);
          if (p.ownerId === 'player') {
            this.hitmarkerTime = 0.14;
            this.hitmarkerHeadshot = false;
            soundEngine.playPanClang();
          }
          if (hitVehicle.hp <= 0) {
            const attacker = this.combatants.find((c) => c.id === p.ownerId) ?? null;
            this.destroyVehicle(hitVehicle, attacker);
          }
        }
        this.scene.remove(p.mesh);
        this.projectiles.splice(i, 1);
        continue;
      }

      // Combatant hit detection (segment proximity check)
      let hitTarget: Combatant | null = null;
      let isHeadshot = false;
      const isRemoteTracer = p.ownerId.startsWith('remote_');
      if (!isRemoteTracer) {
        for (const c of this.combatants) {
          if (!c.alive || c.id === p.ownerId || c.teamId === p.teamId) continue;
          if (c.isPlayer && (this.phase === 'plane' || this.phase === 'skydiving')) continue;

          const bodyHeight = c.stance === 'prone' ? 0.65 : c.stance === 'crouch' ? 1.25 : 1.75;
          if (p.pos.y < c.pos.y || p.pos.y > c.pos.y + bodyHeight + 0.15) continue;

          const dSq = this.pointToSegmentDistSq(c.pos, prevPos, p.pos);
          if (dSq < 0.34) {
            hitTarget = c;
            isHeadshot = p.pos.y >= c.pos.y + bodyHeight - 0.35;
            break;
          }
        }
      }

      if (hitTarget) {
        const attacker = this.combatants.find((c) => c.id === p.ownerId) ?? null;
        const wName = WEAPONS[p.weaponId]?.name ?? p.weaponId;

        // Check Iconic Iron Pan rear bullet deflection!
        let deflectedByPan = false;
        if (hitTarget.hasPan && !isHeadshot) {
          const forwardX = -Math.sin(hitTarget.yaw);
          const forwardZ = -Math.cos(hitTarget.yaw);
          const bulletDirX = p.vel.x;
          const bulletDirZ = p.vel.z;
          // If bullet travels roughly in the same direction target faces -> hit from behind!
          const dot = forwardX * bulletDirX + forwardZ * bulletDirZ;
          if (dot > 0 && Math.random() < 0.72) {
            deflectedByPan = true;
          }
        }

        if (deflectedByPan) {
          soundEngine.playPanClang();
          this.spawnParticleBurst(p.pos, 5, 0xfef08a, 6);
        } else {
          let dmg = p.damage * (isHeadshot ? p.headshotMult : 1.0);
          if (isHeadshot && hitTarget.helmetLevel > 0) {
            // AWM penetrates all helmets!
            const red =
              p.weaponId === 'awm'
                ? 0.12
                : hitTarget.helmetLevel === 3
                  ? 0.55
                  : hitTarget.helmetLevel === 2
                    ? 0.4
                    : 0.3;
            dmg *= 1 - red;
            hitTarget.helmetDurability = Math.max(0, hitTarget.helmetDurability - 35);
            if (hitTarget.helmetDurability <= 0) hitTarget.helmetLevel = 0;
          } else if (!isHeadshot && hitTarget.vestLevel > 0) {
            const red = hitTarget.vestLevel === 3 ? 0.55 : hitTarget.vestLevel === 2 ? 0.4 : 0.3;
            dmg *= 1 - red;
            hitTarget.vestDurability = Math.max(0, hitTarget.vestDurability - 22);
            if (hitTarget.vestDurability <= 0) hitTarget.vestLevel = 0;
          }

          this.applyDamage(hitTarget, dmg, attacker, wName, isHeadshot, p.pos);
          this.spawnParticleBurst(p.pos, 4, 0xdc2626, 4);
        }

        this.scene.remove(p.mesh);
        this.projectiles.splice(i, 1);
        continue;
      }

      // Remote player hit detection (authoritative shooter sends combat:hit relay)
      if (p.ownerId === 'player' && this.networkMode !== 'offline') {
        let hitRemoteId: string | null = null;
        let remoteHeadshot = false;
        for (const [pid, peer] of this.voice.peers.entries()) {
          if (!peer.alive) continue;
          if (this.mode !== 'solo' && peer.teamId === this.player.teamId) continue;
          const peerStance = peer.stance ?? 'stand';
          const bodyHeight = peerStance === 'prone' ? 0.65 : peerStance === 'crouch' ? 1.25 : 1.75;
          if (p.pos.y < peer.y || p.pos.y > peer.y + bodyHeight + 0.15) continue;
          _v2.set(peer.x, peer.y, peer.z);
          const dSq = this.pointToSegmentDistSq(_v2, prevPos, p.pos);
          if (dSq < 0.42) {
            hitRemoteId = pid;
            remoteHeadshot = p.pos.y >= peer.y + bodyHeight - 0.35;
            break;
          }
        }
        if (hitRemoteId) {
          const wName = WEAPONS[p.weaponId]?.name ?? p.weaponId;
          const dmg = p.damage * (remoteHeadshot ? p.headshotMult : 1.0);
          this.voice.sendHit(hitRemoteId, dmg, wName, remoteHeadshot);
          this.damageDealt += Math.round(dmg);
          this.hitmarkerTime = 0.22;
          this.hitmarkerHeadshot = remoteHeadshot;
          soundEngine.playHitmarker(remoteHeadshot);
          this.spawnParticleBurst(p.pos, 5, 0xdc2626, 4.5);
          this.scene.remove(p.mesh);
          this.projectiles.splice(i, 1);
        }
      }
    }
  }

  private applyDamage(
    target: Combatant,
    dmg: number,
    attacker: Combatant | null,
    weaponName: string,
    isHeadshot: boolean,
    hitPos: THREE.Vector3,
  ) {
    if (!target.alive) return;
    target.health -= dmg;

    if (attacker?.isPlayer && !target.isPlayer) {
      this.damageDealt += Math.round(dmg);
      this.hitmarkerTime = 0.22;
      this.hitmarkerHeadshot = isHeadshot;
      soundEngine.playHitmarker(isHeadshot);
    }

    if (target.isPlayer) {
      this.damageFlashTime = 0.35;
      this.shakeIntensity = Math.min(0.16, this.shakeIntensity + 0.06);
    } else if (attacker) {
      // Alert bot to look toward attacker!
      target.aiTargetPos.copy(attacker.pos);
    }

    if (target.health <= 0) {
      this.killCombatant(target, attacker, weaponName, isHeadshot);
      if (attacker?.isPlayer) {
        this.hitstopTimer = 0.04; // Crisp 40ms heavy impact hitstop
      }
    }
  }

  private killCombatant(
    victim: Combatant,
    killer: Combatant | null,
    weaponName: string,
    isHeadshot: boolean,
  ) {
    if (!victim.alive) return;
    victim.alive = false;
    victim.health = 0;
    victim.visual.root.visible = false;
    victim.contactShadow.visible = false;

    const aliveLeft = this.combatants.filter((c) => c.alive).length;
    if (victim.isPlayer) {
      this.playerRank = aliveLeft + 1;
    }
    if (killer?.isPlayer && !victim.isPlayer) {
      this.kills += 1;
      if (isHeadshot) this.headshots += 1;
    }

    this.killfeed.unshift({
      id: this.killfeedSeq++,
      killer: killer ? killer.name : 'المنطقة',
      victim: victim.name,
      weaponName,
      isPlayerKiller: Boolean(killer?.isPlayer),
      isAllyKiller: Boolean(killer && !killer.isPlayer && killer.teamId === this.player?.teamId),
      isPlayerVictim: victim.isPlayer,
      isHeadshot,
      timestamp: this.survivalTimeSec,
    });
    if (this.killfeed.length > 5) this.killfeed.pop();
    this.emitHud();
  }

  private updateThrowables(dt: number) {
    for (let i = this.thrownObjects.length - 1; i >= 0; i--) {
      const th = this.thrownObjects[i];
      th.fuse -= dt;
      th.vel.y -= 18 * dt;
      th.pos.addScaledVector(th.vel, dt);

      const gh = this.world!.groundHeightAt(th.pos.x, th.pos.z);
      if (th.pos.y <= gh + 0.16) {
        th.pos.y = gh + 0.16;
        th.vel.y = Math.abs(th.vel.y) * 0.35;
        th.vel.x *= 0.6;
        th.vel.z *= 0.6;
        if (th.type === 'molotov') th.fuse = 0;
      }
      th.mesh.position.copy(th.pos);

      if (th.fuse <= 0) {
        this.scene.remove(th.mesh);
        this.thrownObjects.splice(i, 1);

        if (th.type === 'frag') {
          this.detonateExplosion(th.pos, 9.0, 115, this.player, 'قنبلة شظايا');
        } else if (th.type === 'smoke') {
          this.spawnSmokeCloud(th.pos);
        } else if (th.type === 'molotov') {
          this.spawnFirePool(th.pos);
        } else if (th.type === 'stun') {
          soundEngine.playExplosion(th.pos.distanceTo(this.player.pos));
          this.spawnParticleBurst(th.pos, 10, 0xfef9c3, 9);
          if (th.pos.distanceTo(this.player.pos) < 12) {
            this.stunFlashAlpha = 0.85;
          }
          for (const b of this.combatants) {
            if (!b.isPlayer && b.alive && b.pos.distanceTo(th.pos) < 12) {
              b.fireCooldown = 3.2; // Blinded for 3s
            }
          }
        }
      }
    }
  }

  private detonateExplosion(
    pos: THREE.Vector3,
    radius: number,
    maxDmg: number,
    attacker: Combatant | null,
    weaponName: string,
  ) {
    const dToPlayer = pos.distanceTo(this.player.pos);
    soundEngine.playExplosion(dToPlayer);
    this.spawnParticleBurst(pos, 16, 0xf97316, 12);
    if (this.world) {
      const gh = this.world.groundHeightAt(pos.x, pos.z);
      this.spawnSurfaceImpact(
        new THREE.Vector3(pos.x, gh + 0.03, pos.z),
        new THREE.Vector3(0, 1, 0),
        'ground',
        8.5,
      );
      this.spawnSmokePuff(
        new THREE.Vector3(pos.x, gh + 0.6, pos.z),
        new THREE.Vector3(0, 3.4, 0),
        1.6,
        5.5,
        2.4,
        0x1f2226,
        0.78,
      );
    }
    if (dToPlayer < 35) {
      this.shakeIntensity = Math.min(0.28, this.shakeIntensity + (1 - dToPlayer / 35) * 0.22);
    }

    for (const c of this.combatants) {
      if (!c.alive) continue;
      const d = c.pos.distanceTo(pos);
      if (d < radius) {
        const dmg = maxDmg * (1 - d / radius);
        this.applyDamage(c, dmg, attacker, weaponName, false, pos);
      }
    }

    for (const v of this.vehicles) {
      if (v.hp <= 0) continue;
      const d = v.pos.distanceTo(pos);
      if (d < radius + 1.5 && d > 0.3) {
        v.hp = Math.max(0, v.hp - maxDmg * 1.15 * (1 - d / (radius + 2)));
        if (v.hp <= 0) {
          this.destroyVehicle(v, attacker);
        }
      }
    }
  }

  private spawnSmokeCloud(pos: THREE.Vector3) {
    soundEngine.playSmokeHiss();
    const group = new THREE.Group();
    group.position.copy(pos);
    const mat = new THREE.MeshStandardMaterial({
      color: 0xd1d5db,
      roughness: 1,
      transparent: true,
      opacity: 0.72,
    });
    for (let i = 0; i < 8; i++) {
      const puff = new THREE.Mesh(new THREE.DodecahedronGeometry(2.2 + (i % 3) * 0.7, 1), mat);
      puff.position.set((Math.random() - 0.5) * 3.8, 1.4 + Math.random() * 2.2, (Math.random() - 0.5) * 3.8);
      group.add(puff);
    }
    this.scene.add(group);
    this.smokeClouds.push({ pos: pos.clone(), radius: 5.8, life: 16, group });
  }

  private spawnFirePool(pos: THREE.Vector3) {
    soundEngine.playExplosion(pos.distanceTo(this.player.pos));
    const mesh = new THREE.Mesh(
      new THREE.CircleGeometry(4.2, 16),
      new THREE.MeshBasicMaterial({ color: 0xf97316, transparent: true, opacity: 0.65 }),
    );
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.set(pos.x, this.world!.groundHeightAt(pos.x, pos.z) + 0.08, pos.z);
    this.scene.add(mesh);
    this.firePools.push({ pos: pos.clone(), radius: 4.2, life: 10, tickTimer: 0, mesh });
  }

  private updateSmokeAndFire(dt: number) {
    for (let i = this.smokeClouds.length - 1; i >= 0; i--) {
      const s = this.smokeClouds[i];
      s.life -= dt;
      s.group.rotation.y += dt * 0.25;
      if (s.life <= 0) {
        this.scene.remove(s.group);
        this.smokeClouds.splice(i, 1);
      }
    }
    for (let i = this.firePools.length - 1; i >= 0; i--) {
      const f = this.firePools[i];
      f.life -= dt;
      f.tickTimer -= dt;
      if (f.tickTimer <= 0) {
        f.tickTimer = 0.45;
        this.spawnParticleBurst(f.pos, 2, 0xfbbf24, 4);
        for (const c of this.combatants) {
          if (c.alive && c.pos.distanceTo(f.pos) < f.radius) {
            this.applyDamage(c, 12, this.player, 'قنبلة حارقة', false, f.pos);
          }
        }
      }
      if (f.life <= 0) {
        this.scene.remove(f.mesh);
        this.firePools.splice(i, 1);
      }
    }
  }

  private spawnParticleBurst(pos: THREE.Vector3, count: number, color: number, speed: number) {
    const mat = new THREE.MeshBasicMaterial({ color });
    for (let i = 0; i < count; i++) {
      const m = new THREE.Mesh(this.particleGeo, mat);
      m.position.copy(pos);
      this.scene.add(m);
      this.particles.push({
        pos: pos.clone(),
        vel: new THREE.Vector3(
          (Math.random() - 0.5) * speed * 2,
          Math.random() * speed * 1.3 + 1.5,
          (Math.random() - 0.5) * speed * 2,
        ),
        life: 0.45 + Math.random() * 0.35,
        maxLife: 0.8,
        mesh: m,
      });
    }
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const pt = this.particles[i];
      pt.life -= dt;
      if (pt.life <= 0) {
        this.scene.remove(pt.mesh);
        this.particles.splice(i, 1);
        continue;
      }
      pt.vel.y -= 12 * dt;
      pt.pos.addScaledVector(pt.vel, dt);
      pt.mesh.position.copy(pt.pos);
      pt.mesh.scale.setScalar(Math.max(0.1, pt.life / pt.maxLife));
    }
  }

  private createImpactDecalTexture(): THREE.CanvasTexture {
    const c = document.createElement('canvas');
    c.width = 64;
    c.height = 64;
    const ctx = c.getContext('2d')!;
    const g = ctx.createRadialGradient(32, 32, 2, 32, 32, 28);
    g.addColorStop(0, 'rgba(8, 8, 10, 0.96)');
    g.addColorStop(0.28, 'rgba(24, 22, 20, 0.85)');
    g.addColorStop(0.55, 'rgba(55, 50, 45, 0.35)');
    g.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 64, 64);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  private createSmokePuffTexture(): THREE.CanvasTexture {
    const c = document.createElement('canvas');
    c.width = 64;
    c.height = 64;
    const ctx = c.getContext('2d')!;
    const g = ctx.createRadialGradient(32, 32, 4, 32, 32, 30);
    g.addColorStop(0, 'rgba(255, 255, 255, 0.92)');
    g.addColorStop(0.45, 'rgba(220, 220, 220, 0.55)');
    g.addColorStop(1, 'rgba(180, 180, 180, 0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 64, 64);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  private buildMuzzleFlashMesh(suppressed: boolean): THREE.Group {
    const grp = new THREE.Group();
    const outerColor = suppressed ? 0x93c5fd : 0xff8c1a;
    const coreColor = suppressed ? 0xe0f2fe : 0xfff3b0;
    const outerMat = new THREE.MeshBasicMaterial({
      color: outerColor,
      transparent: true,
      opacity: suppressed ? 0.45 : 0.92,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const coreMat = new THREE.MeshBasicMaterial({
      color: coreColor,
      transparent: true,
      opacity: suppressed ? 0.55 : 0.98,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });

    const planeGeo = new THREE.PlaneGeometry(0.42, 0.14);
    for (let k = 0; k < 3; k++) {
      const m = new THREE.Mesh(planeGeo, outerMat);
      m.rotation.z = (k * Math.PI) / 3;
      grp.add(m);
    }
    const core = new THREE.Mesh(new THREE.ConeGeometry(0.085, 0.34, 6), coreMat);
    core.rotation.x = -Math.PI / 2;
    core.position.z = -0.15;
    grp.add(core);
    return grp;
  }

  private spawnMuzzleFlash(pos: THREE.Vector3, dir: THREE.Vector3, suppressed: boolean) {
    const grp = this.buildMuzzleFlashMesh(suppressed);
    grp.position.copy(pos);
    grp.lookAt(pos.clone().add(dir));
    const scale = suppressed ? 0.55 : 0.95 + Math.random() * 0.45;
    grp.scale.setScalar(scale);
    this.scene.add(grp);
    this.muzzleFlashes.push({ mesh: grp, life: 0.055, maxLife: 0.055 });
  }

  private spawnShellCasing(origin: THREE.Vector3, yaw: number) {
    if (this.shellCasings.length > 36) {
      const oldest = this.shellCasings.shift();
      if (oldest) this.scene.remove(oldest.mesh);
    }
    const m = new THREE.Mesh(this.casingGeo, this.casingMat);
    const rightX = Math.cos(yaw);
    const rightZ = -Math.sin(yaw);
    m.position.set(origin.x + rightX * 0.25, origin.y, origin.z + rightZ * 0.25);
    this.scene.add(m);
    this.shellCasings.push({
      mesh: m,
      vel: new THREE.Vector3(
        rightX * (2.6 + Math.random() * 1.4),
        2.1 + Math.random() * 1.2,
        rightZ * (2.6 + Math.random() * 1.4),
      ),
      spin: new THREE.Vector3(Math.random() * 18, Math.random() * 18, Math.random() * 18),
      life: 1.6,
    });
  }

  private spawnSurfaceImpact(
    pos: THREE.Vector3,
    normal: THREE.Vector3,
    kind: 'ground' | 'wall' | 'metal',
    scale = 1,
  ) {
    // 1. Place oriented bullet-hole / scorch decal
    if (this.impactDecals.length >= 110) {
      const oldest = this.impactDecals.shift();
      if (oldest) {
        this.scene.remove(oldest.mesh);
        (oldest.mesh.material as THREE.Material).dispose();
      }
    }
    const mat = new THREE.MeshBasicMaterial({
      map: this.impactDecalTex,
      transparent: true,
      opacity: scale > 2 ? 0.85 : 0.92,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
    });
    const decal = new THREE.Mesh(scale > 2 ? this.craterGeo : this.decalGeo, mat);
    decal.position.copy(pos).addScaledVector(normal, 0.025);
    decal.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
    decal.rotateZ(Math.random() * Math.PI * 2);
    if (scale > 2) {
      decal.scale.setScalar(scale / 2.8);
    } else {
      decal.scale.setScalar(0.85 + Math.random() * 0.45);
    }
    this.scene.add(decal);
    this.impactDecals.push({ mesh: decal, life: scale > 2 ? 35 : 18 });

    // 2. Sparks or biome-matched ground dust puffs
    if (kind === 'metal') {
      this.spawnParticleBurst(pos, 5, 0xfef08a, 6.5);
    } else if (kind === 'wall') {
      this.spawnParticleBurst(pos, 4, 0xd1d5db, 4.2);
      this.spawnSmokePuff(pos, normal.clone().multiplyScalar(0.9), 0.25, 0.85, 0.55, 0xbdbdbd, 0.45);
    } else if (scale <= 2) {
      const dirtColor =
        this.mapId === 'snow'
          ? 0xf1f5f9
          : this.mapId === 'desert'
            ? 0xd9b37c
            : 0x9c8867;
      this.spawnParticleBurst(pos, 3, dirtColor, 3.8);
      this.spawnSmokePuff(pos, new THREE.Vector3(0, 1.4, 0), 0.28, 0.95, 0.65, dirtColor, 0.42);
    }
  }

  private spawnSmokePuff(
    pos: THREE.Vector3,
    vel: THREE.Vector3,
    startScale: number,
    endScale: number,
    life: number,
    color: number,
    opacity: number,
  ) {
    if (this.smokePuffs.length > 120) {
      const oldest = this.smokePuffs.shift();
      if (oldest) {
        this.scene.remove(oldest.mesh);
        (oldest.mesh.material as THREE.Material).dispose();
      }
    }
    const mat = new THREE.MeshBasicMaterial({
      map: this.smokePuffTex,
      color,
      transparent: true,
      opacity,
      depthWrite: false,
    });
    const m = new THREE.Mesh(this.smokePuffGeo, mat);
    m.position.copy(pos);
    m.scale.setScalar(startScale);
    this.scene.add(m);
    this.smokePuffs.push({
      mesh: m,
      vel: vel.clone(),
      life,
      maxLife: life,
      startScale,
      endScale,
    });
  }

  private destroyVehicle(v: ActiveVehicle, attacker: Combatant | null) {
    if (this.inVehicle === v) {
      const exitX = v.pos.x - Math.cos(v.yaw) * 2.6;
      const exitZ = v.pos.z + Math.sin(v.yaw) * 2.6;
      this.player.pos.set(exitX, this.world!.groundHeightAt(exitX, exitZ), exitZ);
      this.inVehicle = null;
      this.player.visual.root.visible = this.perspective === 'tpp';
      soundEngine.stopEngine();
    }
    v.driverId = null;
    v.speed = 0;

    // Char the vehicle silhouette dark
    v.visual.root.traverse((obj) => {
      const m = obj as THREE.Mesh;
      if (m.isMesh && m.material) {
        const mat = m.material as THREE.MeshStandardMaterial;
        if (mat.color) mat.color.multiplyScalar(0.28);
      }
    });

    this.detonateExplosion(v.pos.clone().add(new THREE.Vector3(0, 0.6, 0)), 7.5, 90, attacker, 'انفجار مركبة');
  }

  private updateVehiclesVfx(dt: number) {
    for (const v of this.vehicles) {
      const ratio = v.hp / v.maxHp;
      if (ratio >= 0.65) continue;

      v.vfxTimer -= dt;
      if (v.vfxTimer > 0) continue;

      // Engine hood coordinates at vehicle nose
      const hoodOffset = v.kind === 'offroader' ? 1.35 : 0.65;
      const hoodPos = new THREE.Vector3(
        v.pos.x - Math.sin(v.yaw) * hoodOffset + (Math.random() - 0.5) * 0.35,
        v.pos.y + 1.05,
        v.pos.z - Math.cos(v.yaw) * hoodOffset + (Math.random() - 0.5) * 0.35,
      );

      if (v.hp <= 0) {
        v.vfxTimer = 0.24;
        this.spawnSmokePuff(
          hoodPos,
          new THREE.Vector3((Math.random() - 0.5) * 0.6, 2.4, (Math.random() - 0.5) * 0.6),
          0.9,
          3.4,
          2.1,
          0x1a1a1d,
          0.65,
        );
      } else if (ratio < 0.3) {
        v.vfxTimer = 0.08;
        this.spawnSmokePuff(
          hoodPos,
          new THREE.Vector3((Math.random() - 0.5) * 0.9, 3.2, (Math.random() - 0.5) * 0.9),
          0.75,
          2.8,
          1.45,
          0x1c1c1e,
          0.72,
        );
        // Engine fire burst
        this.spawnSmokePuff(
          hoodPos,
          new THREE.Vector3((Math.random() - 0.5) * 0.5, 2.1, (Math.random() - 0.5) * 0.5),
          0.48,
          1.05,
          0.32,
          Math.random() < 0.5 ? 0xff6b1a : 0xfbbf24,
          0.88,
        );
      } else {
        v.vfxTimer = 0.16;
        this.spawnSmokePuff(
          hoodPos,
          new THREE.Vector3((Math.random() - 0.5) * 0.6, 2.2, (Math.random() - 0.5) * 0.6),
          0.5,
          2.0,
          1.25,
          0x787c82,
          0.48,
        );
      }
    }
  }

  private updateVfxEntities(dt: number) {
    for (let i = this.muzzleFlashes.length - 1; i >= 0; i--) {
      const mf = this.muzzleFlashes[i];
      mf.life -= dt;
      if (mf.life <= 0) {
        this.scene.remove(mf.mesh);
        this.muzzleFlashes.splice(i, 1);
      } else {
        mf.mesh.scale.multiplyScalar(0.92);
      }
    }

    for (let i = this.smokePuffs.length - 1; i >= 0; i--) {
      const sp = this.smokePuffs[i];
      sp.life -= dt;
      if (sp.life <= 0) {
        this.scene.remove(sp.mesh);
        (sp.mesh.material as THREE.Material).dispose();
        this.smokePuffs.splice(i, 1);
        continue;
      }
      const t = 1 - sp.life / sp.maxLife;
      sp.mesh.position.addScaledVector(sp.vel, dt);
      sp.mesh.quaternion.copy(this.camera.quaternion);
      const sc = THREE.MathUtils.lerp(sp.startScale, sp.endScale, t);
      sp.mesh.scale.setScalar(sc);
      const mat = sp.mesh.material as THREE.MeshBasicMaterial;
      mat.opacity = Math.max(0, (1 - t) * 0.72);
    }

    for (let i = this.shellCasings.length - 1; i >= 0; i--) {
      const sc = this.shellCasings[i];
      sc.life -= dt;
      if (sc.life <= 0) {
        this.scene.remove(sc.mesh);
        this.shellCasings.splice(i, 1);
        continue;
      }
      sc.vel.y -= 16 * dt;
      sc.mesh.position.addScaledVector(sc.vel, dt);
      sc.mesh.rotation.x += sc.spin.x * dt;
      sc.mesh.rotation.y += sc.spin.y * dt;
      const gh = this.world!.groundHeightAt(sc.mesh.position.x, sc.mesh.position.z);
      if (sc.mesh.position.y <= gh + 0.02) {
        sc.mesh.position.y = gh + 0.02;
        sc.vel.y = Math.abs(sc.vel.y) * 0.35;
        sc.vel.x *= 0.5;
        sc.vel.z *= 0.5;
        sc.spin.multiplyScalar(0.5);
      }
    }

    for (let i = this.impactDecals.length - 1; i >= 0; i--) {
      const dc = this.impactDecals[i];
      dc.life -= dt;
      if (dc.life <= 0) {
        this.scene.remove(dc.mesh);
        (dc.mesh.material as THREE.Material).dispose();
        this.impactDecals.splice(i, 1);
      } else if (dc.life < 2) {
        (dc.mesh.material as THREE.MeshBasicMaterial).opacity = dc.life * 0.45;
      }
    }
  }

  private checkMatchOutcome() {
    if (!this.player.alive) {
      this.phase = 'gameover';
      soundEngine.stopEngine();
      this.releasePointerLock();
      this.emitHud();
      return;
    }
    const botEnemyAlive = this.combatants.some((c) => c.alive && c.teamId !== this.player.teamId);
    const remoteEnemyAlive =
      this.networkMode !== 'offline' &&
      Array.from(this.voice.peers.values()).some(
        (p) => p.alive && (this.mode === 'solo' || p.teamId !== this.player.teamId),
      );
    const hasAnyOpponent =
      this.combatants.some((c) => c.teamId !== this.player.teamId) || this.hadRemoteOpponent;
    if (hasAnyOpponent && !botEnemyAlive && !remoteEnemyAlive) {
      this.phase = 'victory';
      this.playerRank = 1;
      soundEngine.stopEngine();
      soundEngine.playVictoryFanfare();
      this.releasePointerLock();
      this.emitHud();
    }
  }

  private emitHud() {
    const remoteAliveCount =
      this.networkMode === 'offline'
        ? 0
        : Array.from(this.voice.peers.values()).filter((p) => p.alive).length;
    const aliveCount = this.combatants.filter((c) => c.alive).length + remoteAliveCount;
    const totalCount =
      (this.combatants.length || (this.networkMode === 'local' && !this.fillWithBots ? 1 : 30)) +
      (this.networkMode === 'offline' ? 0 : this.voice.peers.size);
    const activeWeapon = this.player?.weapons[this.player.activeSlot] ?? null;
    const activeScope: ScopeType = activeWeapon
      ? WEAPONS[activeWeapon.defId].builtInScope ?? activeWeapon.scope
      : 'iron';

    // Prompt text for loot / crate / vehicle
    let promptText: string | null = null;
    if (this.phase === 'playing' && this.player?.alive) {
      if (this.inVehicle) {
        promptText = '[F] النزول من المركبة';
      } else {
        const drop = this.airdrops.find(
          (a) => a.landed && !a.looted && a.pos.distanceTo(this.player.pos) < 3.6,
        );
        if (drop) {
          promptText = '[F] فتح صندوق الدعم الأسطوري';
        } else {
          const nl = this.findNearestLoot(3.2);
          if (nl) {
            promptText = `[F] التقاط: ${nl.item.labelAr}`;
          } else {
            const nv = this.findNearestVehicle(4.2);
            if (nv) promptText = `[F] قيادة: ${nv.nameAr}`;
          }
        }
      }
    }

    const blips: MinimapBlip[] = [];
    for (const c of this.combatants) {
      if (!c.alive || c.isPlayer) continue;
      if (c.teamId === this.player?.teamId) {
        blips.push({ x: c.pos.x, z: c.pos.z, type: 'ally' });
      }
    }
    for (const v of this.vehicles) {
      if (v.hp > 0 && v !== this.inVehicle) {
        blips.push({ x: v.pos.x, z: v.pos.z, type: 'vehicle' });
      }
    }
    for (const d of this.airdrops) {
      if (!d.looted) {
        blips.push({ x: d.pos.x, z: d.pos.z, type: 'airdrop' });
      }
    }

    const pYaw = this.player?.yaw ?? 0;
    const compassDeg = (((-THREE.MathUtils.radToDeg(pYaw)) % 360) + 360) % 360;
    const gh = this.world && this.player ? this.world.groundHeightAt(this.player.pos.x, this.player.pos.z) : 0;
    const outsideZone =
      this.player &&
      Math.hypot(this.player.pos.x - this.safeZone.x, this.player.pos.z - this.safeZone.z) >
        this.safeZone.r;
    const inRedzone = Boolean(
      this.redZone &&
        this.player &&
        Math.hypot(this.player.pos.x - this.redZone.x, this.player.pos.z - this.redZone.z) <
          this.redZone.r,
    );

    const teammates = this.combatants
      .filter((c) => !c.isPlayer && c.teamId === 0)
      .map((c) => ({ name: c.name, health: Math.round(c.health), alive: c.alive }));

    this.onHudUpdate({
      phase: this.phase,
      mapId: this.mapId,
      mode: this.mode,
      networkMode: this.networkMode,
      roomCode: this.roomCode,
      perspective: this.perspective,
      stance: this.player?.stance ?? 'stand',
      lean: this.player?.lean ?? 0,
      isAds: this.isAds,
      activeScope,
      health: Math.max(0, Math.round(this.player?.health ?? 100)),
      maxHealth: 100,
      boost: Math.round(this.player?.boost ?? 0),
      helmetLevel: this.player?.helmetLevel ?? 0,
      helmetDurability: Math.round(this.player?.helmetDurability ?? 0),
      vestLevel: this.player?.vestLevel ?? 0,
      vestDurability: Math.round(this.player?.vestDurability ?? 0),
      backpackLevel: this.player?.backpackLevel ?? 0,
      hasPan: this.player?.hasPan ?? false,
      hasGhillie: this.player?.hasGhillie ?? false,
      aliveCount,
      totalCount,
      kills: this.kills,
      headshots: this.headshots,
      damageDealt: this.damageDealt,
      distanceTraveledMeters: Math.round(this.distanceTraveledMeters),
      lootCollected: { ...this.lootCollected },
      survivalTimeSec: Math.floor(this.survivalTimeSec),
      rank: this.playerRank,
      liveFps: this.liveFps,
      planeProgress: this.planeProgress,
      canJumpFromPlane: this.phase === 'plane',
      altitude: Math.max(0, Math.round((this.player?.pos.y ?? 0) - gh)),
      isParachuteOpen: this.parachuteOpen,
      inVehicle: Boolean(this.inVehicle),
      vehicleName: this.inVehicle?.nameAr ?? '',
      vehicleSpeedKmh: this.inVehicle ? Math.round(Math.abs(this.inVehicle.speed) * 3.6) : 0,
      vehicleFuel: this.inVehicle ? Math.round(this.inVehicle.fuel) : 0,
      vehicleHp: this.inVehicle ? Math.round(this.inVehicle.hp) : 0,
      weapons: this.player
        ? [
            this.player.weapons[0] ? { ...this.player.weapons[0] } : null,
            this.player.weapons[1] ? { ...this.player.weapons[1] } : null,
            this.player.weapons[2] ? { ...this.player.weapons[2] } : null,
          ]
        : [null, null, null],
      activeSlot: this.player?.activeSlot ?? 0,
      ammoBag: { ...this.ammoBag },
      meds: { ...this.meds },
      throwables: { ...this.throwables },
      activeThrowable: this.activeThrowable,
      spareAttachments: {
        scopes: [...this.spareScopes],
        muzzles: [...this.spareMuzzles],
        extMags: this.spareExtMags,
      },
      isReloading: this.isReloading,
      reloadProgress: this.isReloading ? Math.min(1, this.reloadTimer / this.reloadDuration) : 0,
      isUsingMed: this.isUsingMed,
      medUseLabel: MED_INFO[this.medUseType].labelAr,
      medUseProgress: this.isUsingMed ? Math.min(1, this.medUseTimer / this.medUseDuration) : 0,
      promptText,
      compassDeg,
      crosshairSpread: this.isAds ? 4 : this.player?.stance === 'prone' ? 8 : 14,
      hitmarkerTime: this.hitmarkerTime,
      hitmarkerHeadshot: this.hitmarkerHeadshot,
      damageFlashTime: this.damageFlashTime,
      stunFlashAlpha: this.stunFlashAlpha,
      zonePhase: this.zonePhase,
      zoneTimerSec: Math.max(0, Math.ceil(this.zoneTimerSec)),
      zoneShrinking: this.zoneShrinking,
      outsideZone: Boolean(outsideZone),
      redzoneActive: Boolean(this.redZone),
      inRedzone,
      airdropAnnounce: this.airdropAnnounce,
      weatherLabel: this.weatherLabel,
      playerX: this.player?.pos.x ?? 0,
      playerZ: this.player?.pos.z ?? 0,
      playerYaw: pYaw,
      worldRadius: this.world?.worldRadius ?? 240,
      safeZone: { ...this.safeZone },
      nextZone: { ...this.nextZone },
      redZone: this.redZone ? { ...this.redZone } : null,
      blips,
      buildings: this.world?.buildingsMeta ?? [],
      killfeed: [...this.killfeed],
      teammates,
      pointerLocked: this.pointerLocked,
      renderResolution: { ...this.renderResolution },
      multiplayer: {
        connected: Boolean(this.voice.selfId),
        networkMode: this.networkMode,
        roomCode: this.roomCode,
        roomPeers: Array.from(this.voice.peers.values()).map((p) => ({
          id: p.id,
          name: p.name,
          alive: p.alive,
        })),
      },
      voice: {
        connected: Boolean(this.voice.selfId),
        peerCount: this.voice.peers.size,
        channel: this.voice.channel,
        micMode: this.voice.micMode,
        micPermission: this.voice.micPermission,
        isMicActive: this.voice.isMicTransmitting(),
        isPttHeld: this.voice.isPttHeld,
        micLevel: this.voice.micLevel,
        testLoopback: this.voice.testLoopback,
        nearbySpeakers: this.voice.getNearbySpeakers(),
      },
    });
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    soundEngine.stopEngine();
    this.voice.dispose();
    this.unbindInputs();
    this.clearWorldEntities();
    this.shadowTex?.dispose();
    this.impactDecalTex?.dispose();
    this.smokePuffTex?.dispose();
    this.envRT?.dispose();
    this.bulletGeo.dispose();
    this.bulletMat.dispose();
    this.flareMat.dispose();
    this.particleGeo.dispose();
    this.casingGeo.dispose();
    this.casingMat.dispose();
    this.decalGeo.dispose();
    this.craterGeo.dispose();
    this.smokePuffGeo.dispose();
    this.blueZoneMesh.geometry.dispose();
    (this.blueZoneMesh.material as THREE.Material).dispose();
    this.composer?.dispose();
    this.renderer.dispose();
  }
}
