import * as THREE from 'three';
import type { MapId } from './types';
import { MAP_CONFIGS } from './weaponsData';

export interface BiomeTextures {
  groundMap: THREE.CanvasTexture;
  wallMap: THREE.CanvasTexture;
  roofMap: THREE.CanvasTexture;
  roadMap: THREE.CanvasTexture;
  crateMap: THREE.CanvasTexture;
}

function makeCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  return [c, ctx];
}

function finalizeTexture(
  canvas: HTMLCanvasElement,
  anisotropy: number,
  repeatX = 1,
  repeatY = 1,
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = Math.max(1, anisotropy);
  tex.needsUpdate = true;
  return tex;
}

export function createBiomeTextures(mapId: MapId, maxAnisotropy: number): BiomeTextures {
  const cfg = MAP_CONFIGS[mapId];

  // 1. Ground Albedo Texture
  const [gc, gctx] = makeCanvas(512, 512);
  gctx.fillStyle = cfg.groundPrimary;
  gctx.fillRect(0, 0, 512, 512);

  for (let i = 0; i < 3800; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const r = 1 + Math.random() * (mapId === 'desert' ? 5 : 3);
    gctx.fillStyle = i % 2 === 0 ? cfg.groundSecondary : 'rgba(255,255,255,0.06)';
    gctx.globalAlpha = 0.28 + Math.random() * 0.25;
    gctx.beginPath();
    gctx.arc(x, y, r, 0, Math.PI * 2);
    gctx.fill();
  }
  if (mapId === 'desert') {
    gctx.strokeStyle = 'rgba(130, 92, 48, 0.22)';
    gctx.lineWidth = 3;
    for (let y = 0; y < 512; y += 22) {
      gctx.beginPath();
      gctx.moveTo(0, y);
      gctx.bezierCurveTo(170, y + 8, 340, y - 8, 512, y);
      gctx.stroke();
    }
  } else if (mapId === 'snow') {
    gctx.fillStyle = 'rgba(255,255,255,0.22)';
    for (let i = 0; i < 400; i++) {
      gctx.fillRect(Math.random() * 512, Math.random() * 512, 6, 2);
    }
  }
  gctx.globalAlpha = 1;
  const groundMap = finalizeTexture(gc, maxAnisotropy, 36, 36);

  // 2. Building Wall Texture
  const [wc, wctx] = makeCanvas(256, 256);
  wctx.fillStyle =
    mapId === 'desert'
      ? '#c8ae87'
      : mapId === 'snow'
        ? '#7b8591'
        : mapId === 'jungle'
          ? '#6f6556'
          : '#b6b0a3';
  wctx.fillRect(0, 0, 256, 256);

  // Subtle weathered bricks / concrete panels
  wctx.strokeStyle = 'rgba(0,0,0,0.14)';
  wctx.lineWidth = 2;
  for (let y = 0; y < 256; y += 32) {
    wctx.beginPath();
    wctx.moveTo(0, y);
    wctx.lineTo(256, y);
    wctx.stroke();
    const offset = (y / 32) % 2 === 0 ? 0 : 32;
    for (let x = offset; x < 256; x += 64) {
      wctx.beginPath();
      wctx.moveTo(x, y);
      wctx.lineTo(x, y + 32);
      wctx.stroke();
    }
  }
  for (let i = 0; i < 900; i++) {
    wctx.fillStyle = i % 2 === 0 ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.04)';
    wctx.fillRect(Math.random() * 256, Math.random() * 256, 4, 4);
  }
  const wallMap = finalizeTexture(wc, maxAnisotropy, 2, 2);

  // 3. Roof Texture
  const [rc, rctx] = makeCanvas(256, 256);
  rctx.fillStyle = mapId === 'snow' ? '#cad8e6' : mapId === 'desert' ? '#9e7d58' : '#6e4235';
  rctx.fillRect(0, 0, 256, 256);
  rctx.strokeStyle = 'rgba(0,0,0,0.22)';
  rctx.lineWidth = 3;
  for (let y = 0; y < 256; y += 16) {
    rctx.beginPath();
    rctx.moveTo(0, y);
    rctx.lineTo(256, y);
    rctx.stroke();
  }
  const roofMap = finalizeTexture(rc, maxAnisotropy, 2, 2);

  // 4. Asphalt / Dirt Road Texture
  const [rdc, rdctx] = makeCanvas(256, 256);
  rdctx.fillStyle = mapId === 'desert' ? '#8c6f4b' : mapId === 'jungle' ? '#4d4134' : '#3a3e44';
  rdctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 1200; i++) {
    rdctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.09)';
    rdctx.fillRect(Math.random() * 256, Math.random() * 256, 2, 2);
  }
  if (mapId === 'classic' || mapId === 'snow') {
    rdctx.fillStyle = '#d4aa4b';
    for (let y = 12; y < 256; y += 48) {
      rdctx.fillRect(124, y, 8, 24);
    }
  }
  const roadMap = finalizeTexture(rdc, maxAnisotropy, 1, 24);

  // 5. Airdrop Crate Texture
  const [cc, cctx] = makeCanvas(256, 256);
  cctx.fillStyle = '#a82222';
  cctx.fillRect(0, 0, 256, 256);
  cctx.fillStyle = '#202636';
  cctx.fillRect(0, 0, 256, 44);
  cctx.fillRect(0, 212, 256, 44);
  cctx.strokeStyle = '#d4a84b';
  cctx.lineWidth = 8;
  cctx.strokeRect(12, 12, 232, 232);
  cctx.fillStyle = '#e8c468';
  cctx.font = 'bold 40px monospace';
  cctx.textAlign = 'center';
  cctx.fillText('SUPPLY', 128, 142);
  const crateMap = finalizeTexture(cc, maxAnisotropy, 1, 1);

  return { groundMap, wallMap, roofMap, roadMap, crateMap };
}

export function createRadialShadowTexture(): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(128, 128);
  const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0,0,0,0.55)');
  grad.addColorStop(0.55, 'rgba(0,0,0,0.22)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
