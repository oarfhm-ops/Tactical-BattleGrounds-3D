import { useState } from 'react';
import { Download, Smartphone, WifiOff } from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

export function PWAInstallButton() {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  return (
    <>
      <button
        type="button"
        onClick={() => {
          if (isInstallable) {
            void install();
          } else {
            setShowGuide(true);
          }
        }}
        className="flex items-center gap-1.5 bg-emerald-600/90 hover:bg-emerald-500 border border-emerald-400/50 text-white px-3 py-2 rounded-lg text-xs font-bold shadow-lg transition-colors cursor-pointer"
        title="تثبيت اللعبة كتطبيق على الهاتف"
      >
        {isInstallable ? <Download className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
        <span>{isInstallable ? 'تثبيت التطبيق' : 'تطبيق أندرويد'}</span>
      </button>

      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0b0e11]/85 p-4 pointer-events-auto">
          <div className="w-full max-w-sm rounded-xl bg-[#12171e] border border-[#d4a84b]/60 p-5 shadow-2xl space-y-3 text-right">
            <h3 className="text-base font-black text-[#d4a84b] flex items-center gap-2">
              <Smartphone className="w-5 h-5" />
              تثبيت تطبيق ميدان البقاء 3D
            </h3>
            {isIOS ? (
              <p className="text-xs text-[#d1d5db] leading-relaxed">
                1. اضغط على زر <strong className="text-white">المشاركة (Share)</strong> في متصفح Safari.
                <br />
                2. اختر <strong className="text-white">إضافة إلى الشاشة الرئيسية (Add to Home Screen)</strong> لتشغيل اللعبة بملء الشاشة.
              </p>
            ) : isAndroid ? (
              <p className="text-xs text-[#d1d5db] leading-relaxed">
                1. افتح قائمة متصفح Chrome أعلى الشاشة (⋮).
                <br />
                2. اختر <strong className="text-white">تثبيت التطبيق (Install app)</strong> أو <strong className="text-white">إضافة للشاشة الرئيسية</strong> لتشغيلها كتطبيق أندرويد بوضع ملء الشاشة.
              </p>
            ) : (
              <p className="text-xs text-[#d1d5db] leading-relaxed">
                اضغط على أيقونة <strong className="text-white">تثبيت التطبيق</strong> في شريط العنوان لتشغيل اللعبة كتطبيق مستقل بملء الشاشة مع دعم اللعب أوفلاين.
              </p>
            )}
            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="w-full bg-[#d4a84b] hover:bg-[#e3ba5d] text-[#0b0e11] font-black py-2 rounded-lg text-xs cursor-pointer"
            >
              فهمت
            </button>
          </div>
        </div>
      )}
    </>
  );
}

export function OfflineIndicator() {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-lg bg-amber-600/95 border border-amber-300/50 px-3 py-1.5 text-xs font-bold text-white shadow-lg pointer-events-none">
      <WifiOff className="w-3.5 h-3.5" />
      <span>وضع عدم الاتصال — يمكنك اللعب أوفلاين</span>
    </div>
  );
}
