import { useMemo, useState } from 'react';
import {
  Check,
  Copy,
  Crosshair,
  Globe,
  Monitor,
  Radio,
  RefreshCw,
  Search,
  Shield,
  Sliders,
  Smartphone,
  UserCheck,
  Users,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
} from 'lucide-react';
import type {
  ControlScheme,
  DiscoveredLocalRoom,
  GameMode,
  GameSettings,
  GraphicsQuality,
  GraphicsStyle,
  HudSnapshot,
  MapId,
  NetworkMode,
  TargetFps,
} from '../game/types';
import { MAP_CONFIGS } from '../game/weaponsData';
import { PWAInstallButton } from './PWAInstallButton';

interface TitleScreenProps {
  selectedMap: MapId;
  selectedMode: GameMode;
  networkMode: NetworkMode;
  roomCode: string;
  hostingLocalRoom: boolean;
  localRooms: DiscoveredLocalRoom[];
  searchingRooms: boolean;
  playerName: string;
  fillWithBots: boolean;
  multiplayer: HudSnapshot['multiplayer'];
  settings: GameSettings;
  isTouchMode: boolean;
  liveFps: number;
  renderResolution: { width: number; height: number; is4k: boolean };
  onSelectMap: (map: MapId) => void;
  onSelectMode: (mode: GameMode) => void;
  onSelectNetworkMode: (mode: NetworkMode) => void;
  onChangeRoomCode: (code: string) => void;
  onToggleHostLocalRoom: (hosting: boolean) => void;
  onRefreshLocalRooms: (query?: string) => void;
  onJoinLocalRoom: (room: DiscoveredLocalRoom) => void;
  onChangePlayerName: (name: string) => void;
  onToggleFillWithBots: (fill: boolean) => void;
  onUpdateSettings: (settings: GameSettings) => void;
  onStart: () => void;
}

const MAP_LIST: MapId[] = ['classic', 'desert', 'snow', 'jungle'];
const MODES: Array<{ id: GameMode; label: string; desc: string }> = [
  { id: 'solo', label: 'منفرد (Solo)', desc: 'الكل ضد الكل' },
  { id: 'duo', label: 'ثنائي (Duo)', desc: 'شراكة مع رفيق' },
  { id: 'squad', label: 'فرق (Squad)', desc: 'فريق من 4 مقاتلين' },
];

const NETWORK_MODES: Array<{
  id: NetworkMode;
  label: string;
  sub: string;
}> = [
  { id: 'online', label: 'أونلاين جيم', sub: 'سيرفر عام + لاعبين' },
  { id: 'local', label: 'لوكال جيم', sub: 'غرف حقيقية قريبة' },
  { id: 'offline', label: 'أوفلاين جيم', sub: 'لعب بدون إنترنت' },
];

const QUALITY_OPTIONS: Array<[GraphicsQuality, string]> = [
  ['smooth', 'Smooth'],
  ['balanced', 'Balanced'],
  ['hd', 'HD'],
  ['hdr', 'HDR'],
  ['ultra', '4K UHD'],
];

const QUALITY_AR: Record<GraphicsQuality, string> = {
  smooth: 'سلسة Smooth',
  balanced: 'متوازنة Balanced',
  hd: 'عالية HD',
  hdr: 'فائقة HDR',
  ultra: 'دقة 4K UHD',
};

const STYLE_OPTIONS: Array<[GraphicsStyle, string]> = [
  ['classic', 'كلاسيكي'],
  ['colorful', 'ملون'],
  ['realistic', 'واقعي'],
  ['soft', 'ناعم'],
  ['movie', 'فيلم'],
];

const CONTROL_SCHEMES: Array<{ id: ControlScheme; label: string }> = [
  { id: 'auto', label: 'تلقائي' },
  { id: 'touch', label: 'أندرويد (لمس)' },
  { id: 'pc', label: 'كمبيوتر (ماوس)' },
];

export function TitleScreen({
  selectedMap,
  selectedMode,
  networkMode,
  roomCode,
  hostingLocalRoom,
  localRooms,
  searchingRooms,
  playerName,
  fillWithBots,
  multiplayer,
  settings,
  isTouchMode,
  liveFps,
  renderResolution,
  onSelectMap,
  onSelectMode,
  onSelectNetworkMode,
  onChangeRoomCode,
  onToggleHostLocalRoom,
  onRefreshLocalRooms,
  onJoinLocalRoom,
  onChangePlayerName,
  onToggleFillWithBots,
  onUpdateSettings,
  onStart,
}: TitleScreenProps) {
  const [showGraphics, setShowGraphics] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [localSubTab, setLocalSubTab] = useState<'search' | 'host'>('search');
  const [roomSearchQuery, setRoomSearchQuery] = useState('');

  const filteredRooms = useMemo(() => {
    const q = roomSearchQuery.trim().toUpperCase();
    if (!q) return localRooms;
    return localRooms.filter(
      (r) =>
        r.roomCode.toUpperCase().includes(q) ||
        r.hostName.toUpperCase().includes(q) ||
        r.players.some((p) => p.toUpperCase().includes(q)),
    );
  }, [localRooms, roomSearchQuery]);

  const handleCopyInvite = () => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('room', roomCode || 'ROOM1');
      void navigator.clipboard?.writeText(url.toString());
      setCopiedLink(true);
      window.setTimeout(() => setCopiedLink(false), 1800);
    } catch {
      // ignore clipboard restriction
    }
  };

  const handleRandomRoom = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 5; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    onChangeRoomCode(code);
  };

  return (
    <div className="fixed inset-0 z-20 flex flex-col justify-between p-3 md:p-6 pointer-events-none overflow-y-auto">
      {/* Top Bar: Tactical Lockup on Right + Instant 4K Quality, PWA Install & Audio Controls on Left */}
      <div className="flex flex-wrap items-start justify-between gap-2.5">
        <div className="pointer-events-auto bg-[#0b0e11]/90 border border-[#d4a84b]/45 px-3.5 py-2.5 rounded-lg shadow-2xl max-w-sm">
          <div className="flex items-center gap-2.5">
            <svg width="38" height="38" viewBox="0 0 48 48" className="shrink-0">
              <polygon
                points="24,2 44,12 44,36 24,46 4,36 4,12"
                fill="#161b22"
                stroke="#d4a84b"
                strokeWidth="2.2"
              />
              <circle cx="24" cy="24" r="10" fill="none" stroke="#f3f0e6" strokeWidth="1.6" />
              <line x1="24" y1="8" x2="24" y2="17" stroke="#d4a84b" strokeWidth="2.2" />
              <line x1="24" y1="31" x2="24" y2="40" stroke="#d4a84b" strokeWidth="2.2" />
              <line x1="8" y1="24" x2="17" y2="24" stroke="#d4a84b" strokeWidth="2.2" />
              <line x1="31" y1="24" x2="40" y2="24" stroke="#d4a84b" strokeWidth="2.2" />
              <circle cx="24" cy="24" r="2.5" fill="#d4a84b" />
            </svg>
            <div>
              <div className="text-[10px] font-mono-num tracking-widest text-[#d4a84b] uppercase">
                TACTICAL BATTLEGROUNDS 3D
              </div>
              <h1 className="text-lg md:text-2xl font-black tracking-tight text-[#f3f0e6] leading-tight">
                ميدان البقاء 3D
              </h1>
            </div>
          </div>
          <p className="mt-1 text-[11px] text-[#b8b5aa] leading-relaxed">
            {isTouchMode
              ? 'وضع الأندرويد واللمس مفعّل — اسحب المقاتل أو ابدأ المعركة فوراً.'
              : 'اسحب الماوس في الوسط لتدوير المقاتل — اقفز من الطائرة العسكرية وكن الناجي الأخير.'}
          </p>
        </div>

        {/* Left Top Cluster: Resolution + Quality Bar + Control Mode + PWA Install + Settings + Sound */}
        <div className="pointer-events-auto flex flex-wrap items-center gap-1.5 md:gap-2">
          <div className="flex items-center gap-1.5 bg-[#0b0e11]/90 border border-white/15 px-2.5 py-2 rounded-lg text-[11px] font-mono-num text-[#d4a84b]">
            <span>{liveFps} FPS</span>
            <span className="text-white/25">|</span>
            <span className={renderResolution.is4k ? 'text-emerald-400 font-bold' : 'text-[#9ca3af]'}>
              {renderResolution.width}×{renderResolution.height}
              {renderResolution.is4k ? ' 4K' : ''}
            </span>
          </div>

          {/* Direct 5-Quality Selector always reachable in Lobby */}
          <div className="flex items-center bg-[#0b0e11]/90 border border-[#d4a84b]/40 rounded-lg p-1 gap-1">
            {QUALITY_OPTIONS.map(([val, lbl]) => (
              <button
                key={val}
                type="button"
                onClick={() => onUpdateSettings({ ...settings, quality: val })}
                className={`px-2 py-1 rounded text-[11px] font-mono-num font-bold transition-colors cursor-pointer ${
                  settings.quality === val
                    ? 'bg-[#d4a84b] text-[#0b0e11]'
                    : 'text-[#d1d5db] hover:bg-white/10'
                }`}
                title={`تفعيل جودة ${QUALITY_AR[val]}`}
              >
                {lbl}
              </button>
            ))}
          </div>

          <PWAInstallButton />

          <button
            type="button"
            onClick={() => setShowGraphics((v) => !v)}
            className="flex items-center gap-1.5 bg-[#0b0e11]/90 hover:bg-[#171d24] border border-[#d4a84b]/45 text-[#f3f0e6] px-3 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer"
          >
            <Sliders className="w-4 h-4 text-[#d4a84b]" />
            <span>خيارات متقدمة</span>
          </button>

          <button
            type="button"
            onClick={() => onUpdateSettings({ ...settings, muted: !settings.muted })}
            className="flex items-center justify-center bg-[#0b0e11]/90 hover:bg-[#171d24] border border-[#d4a84b]/40 text-[#f3f0e6] p-2 rounded-lg transition-colors cursor-pointer"
            title={settings.muted ? 'تشغيل الصوت' : 'كتم الصوت'}
          >
            {settings.muted ? (
              <VolumeX className="w-5 h-5 text-red-400" />
            ) : (
              <Volume2 className="w-5 h-5 text-[#d4a84b]" />
            )}
          </button>
        </div>
      </div>

      {/* Middle Side Panels: Match Entry Hub (Right) + Advanced Graphics & Touch Drawer (Left) */}
      <div className="my-2 flex flex-col lg:flex-row items-start justify-between gap-3">
        {/* Match Entry Hub: Online / Real Local Room Search & Host / Offline */}
        <div className="pointer-events-auto bg-[#0b0e11]/92 border border-[#d4a84b]/45 rounded-xl p-3.5 w-full max-w-sm shadow-2xl space-y-2.5">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <span className="text-xs font-black text-[#d4a84b]">نوع الاتصال والدخول</span>
            <span className="text-[10px] font-mono-num text-[#9ca3af]">
              {networkMode === 'offline'
                ? 'محلي بدون شبكة'
                : multiplayer.connected
                  ? `متصل (${multiplayer.roomPeers.length + 1})`
                  : 'جاري الاتصال...'}
            </span>
          </div>

          {/* 3 Entry Mode Buttons */}
          <div className="grid grid-cols-3 gap-1.5">
            {NETWORK_MODES.map((nm) => {
              const active = networkMode === nm.id;
              return (
                <button
                  key={nm.id}
                  type="button"
                  onClick={() => onSelectNetworkMode(nm.id)}
                  className={`p-2 rounded-lg border text-center transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                      : 'bg-[#12161c] text-[#d1d5db] border-white/10 hover:border-white/25'
                  }`}
                >
                  <div className="flex justify-center mb-1">
                    {nm.id === 'online' ? (
                      <Globe className={`w-4 h-4 ${active ? 'text-[#0b0e11]' : 'text-emerald-400'}`} />
                    ) : nm.id === 'local' ? (
                      <Wifi className={`w-4 h-4 ${active ? 'text-[#0b0e11]' : 'text-sky-400'}`} />
                    ) : (
                      <WifiOff className={`w-4 h-4 ${active ? 'text-[#0b0e11]' : 'text-amber-400'}`} />
                    )}
                  </div>
                  <div className="text-[11px] font-black leading-tight">{nm.label}</div>
                </button>
              );
            })}
          </div>

          {/* Player Name Input */}
          <div>
            <label className="block text-[10px] text-[#9ca3af] mb-1">اسم المقاتل</label>
            <input
              type="text"
              maxLength={18}
              value={playerName}
              onChange={(e) => onChangePlayerName(e.target.value)}
              placeholder="أدخل اسمك..."
              className="w-full bg-[#12171e] border border-white/15 focus:border-[#d4a84b] rounded-md px-2.5 py-1.5 text-xs text-[#f3f0e6] outline-none"
            />
          </div>

          {/* Mode-specific details */}
          {networkMode === 'online' && (
            <div className="bg-[#12171e] border border-emerald-500/30 rounded-lg p-2.5 text-[11px] space-y-1">
              <div className="flex items-center justify-between text-emerald-300 font-bold">
                <span>سيرفر الأونلاين العام</span>
                <span className="font-mono-num">{multiplayer.roomPeers.length + 1} لاعب</span>
              </div>
              <div className="text-[#9ca3af] leading-relaxed">
                مطابقة فورية على خريطة {MAP_CONFIGS[selectedMap].nameAr} مع لاعبين حقيقيين وروبوتات ودردشة صوتية.
              </div>
            </div>
          )}

          {networkMode === 'local' && (
            <div className="bg-[#12171e] border border-sky-500/35 rounded-lg p-2.5 text-[11px] space-y-2.5">
              {/* Local Sub-tabs: Real Live Search vs Host Room */}
              <div className="grid grid-cols-2 gap-1 bg-[#0b0e11] p-1 rounded-lg border border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    setLocalSubTab('search');
                    onRefreshLocalRooms(roomSearchQuery);
                  }}
                  className={`py-1.5 px-2 rounded text-[11px] font-black flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                    localSubTab === 'search'
                      ? 'bg-sky-500 text-[#0b0e11]'
                      : 'text-[#d1d5db] hover:bg-white/5'
                  }`}
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>بحث عن غرف</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLocalSubTab('host');
                    onToggleHostLocalRoom(true);
                  }}
                  className={`py-1.5 px-2 rounded text-[11px] font-black flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                    localSubTab === 'host'
                      ? 'bg-[#d4a84b] text-[#0b0e11]'
                      : 'text-[#d1d5db] hover:bg-white/5'
                  }`}
                >
                  <Radio className="w-3.5 h-3.5" />
                  <span>فتح غرفة جديدة</span>
                </button>
              </div>

              {localSubTab === 'search' ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5">
                    <div className="relative flex-1">
                      <Search className="w-3.5 h-3.5 text-[#9ca3af] absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={roomSearchQuery}
                        onChange={(e) => setRoomSearchQuery(e.target.value)}
                        placeholder="ابحث برمز الغرفة أو اسم المضيف..."
                        className="w-full bg-[#0b0e11] border border-white/15 focus:border-sky-400 rounded pr-7 pl-2 py-1.5 text-[11px] text-white outline-none"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => onRefreshLocalRooms(roomSearchQuery)}
                      className="bg-[#1a2029] hover:bg-[#252d3a] border border-white/15 px-2.5 py-1.5 rounded text-sky-300 flex items-center gap-1 cursor-pointer"
                      title="تحديث البحث عن غرف لوكال حقيقية"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${searchingRooms ? 'animate-spin' : ''}`} />
                    </button>
                  </div>

                  {/* Live Real Discovered Local Rooms List (NO simulated rooms) */}
                  <div className="max-h-40 overflow-y-auto space-y-1.5 pr-0.5">
                    {filteredRooms.length === 0 ? (
                      <div className="bg-[#0b0e11]/85 border border-white/10 rounded-md p-2.5 text-center space-y-1">
                        <div className="text-[11px] font-bold text-[#d1d5db]">
                          لا توجد غرف لوكال مفتوحة حالياً
                        </div>
                        <div className="text-[10px] text-[#9ca3af] leading-relaxed">
                          تظهر هنا فقط الغرف الحقيقية التي فتحها لاعبون متصلون الآن. اضغط &quot;فتح غرفة جديدة&quot; لإنشاء غرفتك ودعوة أصدقائك.
                        </div>
                      </div>
                    ) : (
                      filteredRooms.map((room) => (
                        <div
                          key={room.roomCode}
                          className="bg-[#0b0e11]/90 border border-sky-500/35 rounded-lg p-2 flex items-center justify-between gap-2"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono-num font-black text-xs text-sky-300">
                                {room.roomCode}
                              </span>
                              <span
                                className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                                  room.inMatch
                                    ? 'bg-amber-500/20 text-amber-300'
                                    : 'bg-emerald-500/20 text-emerald-300'
                                }`}
                              >
                                {room.inMatch ? 'داخل معركة' : 'في الانتظار'}
                              </span>
                            </div>
                            <div className="text-[10px] text-[#b8b5aa] truncate mt-0.5">
                              المضيف: {room.hostName} · {MAP_CONFIGS[room.mapId]?.nameAr ?? room.mapId} ·{' '}
                              <span className="font-mono-num text-white">{room.playerCount}</span> لاعب
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => onJoinLocalRoom(room)}
                            className="shrink-0 bg-sky-500 hover:bg-sky-400 text-[#0b0e11] font-black text-[11px] px-2.5 py-1.5 rounded cursor-pointer"
                          >
                            انضمام
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sky-300 font-bold">رمز الغرفة المحلية</span>
                    <button
                      type="button"
                      onClick={handleCopyInvite}
                      className="flex items-center gap-1 bg-sky-900/50 hover:bg-sky-800/60 border border-sky-400/40 text-sky-200 px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer"
                    >
                      {copiedLink ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedLink ? 'تم النسخ' : 'نسخ الرابط'}</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      maxLength={12}
                      value={roomCode}
                      onChange={(e) =>
                        onChangeRoomCode(e.target.value.toUpperCase().replace(/[^A-Z0-9_-]/g, ''))
                      }
                      className="flex-1 bg-[#0b0e11] border border-white/15 focus:border-sky-400 rounded px-2.5 py-1 text-xs font-mono-num font-bold tracking-wider text-white uppercase outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleRandomRoom}
                      className="bg-[#1a2029] hover:bg-[#252d3a] border border-white/15 p-1.5 rounded text-[#d4a84b] cursor-pointer"
                      title="إنشاء رمز جديد"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <label className="flex items-center justify-between gap-2 cursor-pointer pt-0.5">
                    <span className="text-[#d1d5db]">إظهار الغرفة في البحث العام</span>
                    <input
                      type="checkbox"
                      checked={hostingLocalRoom}
                      onChange={(e) => onToggleHostLocalRoom(e.target.checked)}
                      className="accent-sky-400 w-4 h-4 cursor-pointer"
                    />
                  </label>

                  <label className="flex items-center justify-between gap-2 cursor-pointer">
                    <span className="text-[#d1d5db]">ملء الغرفة بالروبوتات</span>
                    <input
                      type="checkbox"
                      checked={fillWithBots}
                      onChange={(e) => onToggleFillWithBots(e.target.checked)}
                      className="accent-[#d4a84b] w-4 h-4 cursor-pointer"
                    />
                  </label>

                  <div className="pt-1 border-t border-white/10 text-[10px] text-[#9ca3af] flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <UserCheck className="w-3 h-3 text-sky-400" />
                      في الغرفة حالياً:
                    </span>
                    <span className="font-mono-num text-white font-bold">
                      {multiplayer.roomPeers.length + 1}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {networkMode === 'offline' && (
            <div className="bg-[#12171e] border border-amber-500/30 rounded-lg p-2.5 text-[11px] space-y-1">
              <div className="text-amber-300 font-bold">وضع الأوفلاين الفردي</div>
              <div className="text-[#9ca3af] leading-relaxed">
                لعب محلي بالكامل بدون شبكة ضد 29 روبوت تكتيكي على الخريطة المختارة.
              </div>
            </div>
          )}
        </div>

        {/* Graphics, 4K & Android/PC Control Scheme Drawer */}
        {showGraphics && (
          <div className="pointer-events-auto bg-[#0b0e11]/95 border border-[#d4a84b]/45 rounded-xl p-4 w-full max-w-md shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="font-bold text-sm text-[#d4a84b] flex items-center gap-2">
                <Monitor className="w-4 h-4" />
                الجودة والتحكم ({QUALITY_AR[settings.quality]})
              </span>
              <button
                type="button"
                onClick={() => setShowGraphics(false)}
                className="text-xs text-[#9ca3af] hover:text-white cursor-pointer"
              >
                إغلاق
              </button>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs text-[#b8b5aa] mb-1.5">
                <span>جودة الرسوميات (4K UHD)</span>
                <span className="font-mono-num text-[11px] text-[#d4a84b]">
                  {renderResolution.width}×{renderResolution.height}
                </span>
              </div>
              <div className="grid grid-cols-5 gap-1">
                {QUALITY_OPTIONS.map(([val, lbl]) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => onUpdateSettings({ ...settings, quality: val })}
                    className={`py-1.5 px-1 rounded text-[10px] font-bold border cursor-pointer transition-colors ${
                      settings.quality === val
                        ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                        : 'bg-[#161b22] text-[#d1d5db] border-white/10 hover:border-white/30'
                    }`}
                  >
                    {lbl}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="text-xs text-[#b8b5aa] mb-1.5 flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5 text-[#d4a84b]" />
                <span>نظام التحكم (أندرويد لمس / كمبيوتر)</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {CONTROL_SCHEMES.map((cs) => (
                  <button
                    key={cs.id}
                    type="button"
                    onClick={() => onUpdateSettings({ ...settings, controlScheme: cs.id })}
                    className={`py-1.5 px-2 rounded text-[11px] font-bold border cursor-pointer transition-colors ${
                      (settings.controlScheme ?? 'auto') === cs.id
                        ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                        : 'bg-[#161b22] text-[#d1d5db] border-white/10 hover:border-white/30'
                    }`}
                  >
                    {cs.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="text-xs text-[#b8b5aa] mb-1.5">نمط الألوان (Graphics Style)</div>
              <div className="grid grid-cols-5 gap-1">
                {STYLE_OPTIONS.map(([val, lbl]) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => onUpdateSettings({ ...settings, style: val })}
                    className={`py-1.5 px-1 rounded text-[11px] font-bold border cursor-pointer transition-colors ${
                      settings.style === val
                        ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                        : 'bg-[#161b22] text-[#d1d5db] border-white/10 hover:border-white/30'
                    }`}
                  >
                    {lbl}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="text-xs text-[#b8b5aa] mb-1.5">معدل الإطارات (FPS)</div>
                <div className="grid grid-cols-4 gap-1">
                  {([30, 60, 90, 120] as TargetFps[]).map((fps) => (
                    <button
                      key={fps}
                      type="button"
                      onClick={() => onUpdateSettings({ ...settings, targetFps: fps })}
                      className={`py-1 rounded text-xs font-mono-num font-bold border cursor-pointer ${
                        settings.targetFps === fps
                          ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                          : 'bg-[#161b22] text-[#d1d5db] border-white/10'
                      }`}
                    >
                      {fps}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#b8b5aa] mb-1.5">حساسية التصويب</div>
                <input
                  type="range"
                  min={0.4}
                  max={2.2}
                  step={0.1}
                  value={settings.mouseSensitivity}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, mouseSensitivity: parseFloat(e.target.value) })
                  }
                  className="w-full accent-[#d4a84b]"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Dock: Map Selection + Squad Mode + Start CTA + Control Hint */}
      <div className="space-y-2">
        <div className="pointer-events-auto bg-[#0b0e11]/92 border border-[#d4a84b]/40 rounded-xl p-3 md:p-3.5 shadow-2xl max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-center">
            {/* 4 Biomes / Maps */}
            <div className="lg:col-span-6 grid grid-cols-2 sm:grid-cols-4 gap-2">
              {MAP_LIST.map((id) => {
                const cfg = MAP_CONFIGS[id];
                const active = selectedMap === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => onSelectMap(id)}
                    className={`text-right p-2 rounded-lg border transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#1c232d] border-[#d4a84b]'
                        : 'bg-[#12161c] border-white/10 hover:border-white/25'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span
                        className="w-2.5 h-2.5 rounded-sm shrink-0"
                        style={{ backgroundColor: cfg.accentHex }}
                      />
                      <span className="text-[10px] font-mono-num text-[#9ca3af]">{cfg.sizeLabel}</span>
                    </div>
                    <div className="mt-1 text-xs font-extrabold text-[#f3f0e6] truncate">
                      {cfg.nameAr}
                    </div>
                    <div className="text-[10px] text-[#9ca3af] truncate">{cfg.subtitleAr}</div>
                  </button>
                );
              })}
            </div>

            {/* Game Mode Selector */}
            <div className="lg:col-span-3 flex gap-1.5">
              {MODES.map((m) => {
                const active = selectedMode === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onSelectMode(m.id)}
                    className={`flex-1 p-2 rounded-lg border text-center transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#1c232d] border-[#d4a84b] text-[#f3f0e6]'
                        : 'bg-[#12161c] border-white/10 text-[#9ca3af] hover:border-white/25'
                    }`}
                  >
                    <Users className="w-3.5 h-3.5 mx-auto mb-1 text-[#d4a84b]" />
                    <div className="text-[11px] font-bold">{m.label.split(' ')[0]}</div>
                  </button>
                );
              })}
            </div>

            {/* Primary Start CTA */}
            <div className="lg:col-span-3">
              <button
                type="button"
                onClick={onStart}
                className="w-full flex items-center justify-center gap-2.5 bg-[#d4a84b] hover:bg-[#e3ba5d] text-[#0b0e11] font-black text-base py-3 px-5 rounded-lg shadow-lg transition-colors cursor-pointer"
              >
                <Crosshair className="w-5 h-5" />
                <span>
                  {networkMode === 'online'
                    ? 'دخول أونلاين'
                    : networkMode === 'local'
                      ? `دخول غرفة ${roomCode}`
                      : 'ابدأ أوفلاين'}
                </span>
              </button>
            </div>
          </div>

          <div className="mt-2 pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#b8b5aa]">
            <div className="flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-[#d4a84b]" />
              <span>تكتيك الخريطة: {MAP_CONFIGS[selectedMap].tacticAr}</span>
            </div>
            <div className="font-mono-num text-[#d4a84b]">
              {isTouchMode
                ? 'عصا اليسار: حركة وركض · اليمين: سحب الكاميرا وإطلاق نار · أزرار القفز والمنظار والميلان والمركبة باللمس'
                : 'WASD حركة · Shift ركض · Space قفز/مظلة · V منظور · Q/E ميلان · F التقاط/مركبة · R تعبئة · T صوت · Tab حقيبة · M خريطة'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
