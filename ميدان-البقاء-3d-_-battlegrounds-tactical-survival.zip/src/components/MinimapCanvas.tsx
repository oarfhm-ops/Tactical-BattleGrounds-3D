import { useEffect, useRef } from 'react';
import type { HudSnapshot } from '../game/types';
import { MAP_CONFIGS } from '../game/weaponsData';

interface MinimapCanvasProps {
  hud: HudSnapshot;
  size: number;
}

export function MinimapCanvas({ hud, size }: MinimapCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const r = hud.worldRadius || 240;
    const half = size / 2;
    const scale = (size * 0.45) / r;

    const toX = (wx: number) => half + wx * scale;
    const toY = (wz: number) => half + wz * scale;

    // Ocean background
    ctx.fillStyle = '#0d1b26';
    ctx.fillRect(0, 0, size, size);

    // Island base circle
    const cfg = MAP_CONFIGS[hud.mapId];
    ctx.fillStyle = cfg.groundSecondary;
    ctx.beginPath();
    ctx.arc(half, half, r * scale, 0, Math.PI * 2);
    ctx.fill();

    // Cross roads
    ctx.strokeStyle = 'rgba(220, 210, 185, 0.28)';
    ctx.lineWidth = Math.max(1.5, 4 * scale);
    ctx.beginPath();
    ctx.moveTo(toX(-r * 0.85), half);
    ctx.lineTo(toX(r * 0.85), half);
    ctx.moveTo(half, toY(-r * 0.85));
    ctx.lineTo(half, toY(r * 0.85));
    ctx.stroke();

    // Buildings
    ctx.fillStyle = 'rgba(235, 228, 210, 0.72)';
    for (const b of hud.buildings) {
      const bw = Math.max(3, b.w * scale);
      const bd = Math.max(3, b.d * scale);
      ctx.fillRect(toX(b.x) - bw / 2, toY(b.z) - bd / 2, bw, bd);
    }

    // Bluezone exterior tint
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, size, size);
    ctx.arc(toX(hud.safeZone.x), toY(hud.safeZone.z), Math.max(2, hud.safeZone.r * scale), 0, Math.PI * 2, true);
    ctx.fillStyle = 'rgba(28, 108, 224, 0.34)';
    ctx.fill();
    ctx.restore();

    // Current Bluezone circle
    ctx.strokeStyle = '#3b9eff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(toX(hud.safeZone.x), toY(hud.safeZone.z), Math.max(2, hud.safeZone.r * scale), 0, Math.PI * 2);
    ctx.stroke();

    // Next Safe Zone white circle
    ctx.strokeStyle = '#f8fafc';
    ctx.lineWidth = 1.4;
    ctx.setLineDash([4, 3]);
    ctx.beginPath();
    ctx.arc(toX(hud.nextZone.x), toY(hud.nextZone.z), Math.max(2, hud.nextZone.r * scale), 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // Redzone circle
    if (hud.redZone) {
      ctx.fillStyle = 'rgba(239, 68, 68, 0.32)';
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(toX(hud.redZone.x), toY(hud.redZone.z), hud.redZone.r * scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }

    // Blips: vehicles, airdrops, allies
    for (const blip of hud.blips) {
      const bx = toX(blip.x);
      const by = toY(blip.z);
      if (blip.type === 'vehicle') {
        ctx.fillStyle = '#eab308';
        ctx.fillRect(bx - 2.5, by - 2.5, 5, 5);
      } else if (blip.type === 'airdrop') {
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(bx, by, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 1;
        ctx.stroke();
      } else if (blip.type === 'ally') {
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(bx, by, 3.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Player view cone & marker
    const px = toX(hud.playerX);
    const py = toY(hud.playerZ);
    const dirAngle = -hud.playerYaw - Math.PI / 2;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.arc(px, py, 18, dirAngle - 0.42, dirAngle + 0.42);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(px, py, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#111827';
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }, [hud, size]);

  return (
    <canvas
      ref={canvasRef}
      width={size}
      height={size}
      className="block rounded border border-[#d4a84b]/40"
    />
  );
}
