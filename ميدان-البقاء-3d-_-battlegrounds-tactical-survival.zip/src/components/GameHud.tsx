import { useState } from 'react';
import {
  Backpack,
  ChevronDown,
  ChevronUp,
  Crosshair,
  Heart,
  Map as MapIcon,
  Mic,
  MicOff,
  Pause,
  Play,
  Radio,
  RotateCcw,
  Shield,
  Skull,
  Trophy,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import type {
  ControlScheme,
  GameSettings,
  GraphicsQuality,
  GraphicsStyle,
  HudSnapshot,
  MedType,
  MuzzleType,
  ScopeType,
  TargetFps,
} from '../game/types';
import {
  AMMO_LABELS,
  MED_INFO,
  SCOPE_INFO,
  THROWABLE_INFO,
  WEAPONS,
} from '../game/weaponsData';
import { MinimapCanvas } from './MinimapCanvas';
import { TouchControls, type TouchControlCallbacks } from './TouchControls';

interface GameHudProps {
  hud: HudSnapshot;
  settings: GameSettings;
  isTouchMode: boolean;
  showInventory: boolean;
  showFullMap: boolean;
  touchCallbacks: TouchControlCallbacks;
  onToggleInventory: () => void;
  onToggleFullMap: () => void;
  onPauseToggle: () => void;
  onUpdateSettings: (s: GameSettings) => void;
  onJumpFromPlane: () => void;
  onSelectWeaponSlot: (slot: 0 | 1 | 2) => void;
  onUseMed: (t: MedType) => void;
  onAttachScope: (s: ScopeType) => void;
  onAttachMuzzle: (m: MuzzleType) => void;
  onAttachExtMag: () => void;
  onRestart: () => void;
  onExitToMenu: () => void;
  onEnableMic: () => void;
  onCycleVoiceChannel: () => void;
  onToggleMicMode: () => void;
  onToggleVoiceTest: () => void;
}

function compassLabel(deg: number): string {
  const dirs = ['شمال N', 'شمال شرق NE', 'شرق E', 'جنوب شرق SE', 'جنوب S', 'جنوب غرب SW', 'غرب W', 'شمال غرب NW'];
  const idx = Math.round(((deg % 360) + 360) % 360 / 45) % 8;
  return dirs[idx];
}

function formatTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function formatDistance(meters: number): string {
  if (meters >= 1000) {
    return `${(meters / 1000).toFixed(2)} كم`;
  }
  return `${meters} م`;
}

function computeMatchTier(rank: number, kills: number): { tier: string; labelAr: string } {
  if (rank === 1) return { tier: 'S+', labelAr: 'الناجي الأسطوري' };
  if (rank <= 3 || kills >= 6) return { tier: 'S', labelAr: 'مقاتل النخبة' };
  if (rank <= 8 || kills >= 3) return { tier: 'A', labelAr: 'محارب متمرس' };
  if (rank <= 15 || kills >= 1) return { tier: 'B', labelAr: 'مقاتل صامد' };
  return { tier: 'C', labelAr: 'مبتدئ الميدان' };
}

export function GameHud({
  hud,
  settings,
  isTouchMode,
  showInventory,
  showFullMap,
  touchCallbacks,
  onToggleInventory,
  onToggleFullMap,
  onPauseToggle,
  onUpdateSettings,
  onJumpFromPlane,
  onSelectWeaponSlot,
  onUseMed,
  onAttachScope,
  onAttachMuzzle,
  onAttachExtMag,
  onRestart,
  onExitToMenu,
  onEnableMic,
  onCycleVoiceChannel,
  onToggleMicMode,
  onToggleVoiceTest,
}: GameHudProps) {
  const [voiceExpandedOnTouch, setVoiceExpandedOnTouch] = useState(false);
  const activeWeapon = hud.weapons[hud.activeSlot];
  const activeWeaponDef = activeWeapon ? WEAPONS[activeWeapon.defId] : null;
  const isScopedOverlay =
    hud.phase === 'playing' &&
    hud.isAds &&
    !hud.inVehicle &&
    (hud.activeScope === '4x' || hud.activeScope === '8x');
  const is2xOverlay =
    hud.phase === 'playing' &&
    hud.isAds &&
    !hud.inVehicle &&
    hud.activeScope === '2x';
  const showVoiceBody = !isTouchMode || voiceExpandedOnTouch;

  return (
    <div className="fixed inset-0 z-10 pointer-events-none select-none">
      {/* Damage / Bluezone Vignette */}
      {(hud.damageFlashTime > 0 || hud.outsideZone) && (
        <div
          className="fixed inset-0 pointer-events-none"
          style={{
            boxShadow: hud.damageFlashTime > 0
              ? 'inset 0 0 90px rgba(220, 38, 38, 0.7)'
              : 'inset 0 0 70px rgba(37, 99, 235, 0.55)',
          }}
        />
      )}

      {/* Stun Flash Overlay */}
      {hud.stunFlashAlpha > 0.02 && (
        <div
          className="fixed inset-0 bg-white pointer-events-none"
          style={{ opacity: Math.min(0.9, hud.stunFlashAlpha) }}
        />
      )}

      {/* High-Magnification Scope Overlay (4x / 8x) */}
      {isScopedOverlay && (
        <div className="fixed inset-0 flex items-center justify-center pointer-events-none">
          <svg viewBox="0 0 400 400" className="w-[92vmin] h-[92vmin]">
            <defs>
              <mask id="scopeMask">
                <rect width="400" height="400" fill="white" />
                <circle cx="200" cy="200" r="145" fill="black" />
              </mask>
            </defs>
            <rect width="400" height="400" fill="rgba(5, 7, 10, 0.94)" mask="url(#scopeMask)" />
            <circle cx="200" cy="200" r="145" fill="none" stroke="#111827" strokeWidth="5" />
            <line x1="55" y1="200" x2="345" y2="200" stroke="#0b0e11" strokeWidth="1.5" />
            <line x1="200" y1="55" x2="200" y2="345" stroke="#0b0e11" strokeWidth="1.5" />
            {/* Mildot ticks */}
            {[-45, -30, -15, 15, 30, 45].map((off) => (
              <g key={off}>
                <line x1={200 + off} y1="196" x2={200 + off} y2="204" stroke="#0b0e11" strokeWidth="1.5" />
                <line x1="196" y1={200 + off} x2="204" y2={200 + off} stroke="#0b0e11" strokeWidth="1.5" />
              </g>
            ))}
            <circle cx="200" cy="200" r="2.2" fill="#ef4444" />
          </svg>
        </div>
      )}

      {/* 2x Optical Scope Ring Overlay */}
      {is2xOverlay && (
        <div className="fixed inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-44 h-44 rounded-full border-2 border-[#d4a84b]/70 flex items-center justify-center shadow-[0_0_24px_rgba(0,0,0,0.65)]">
            <div className="w-28 h-28 rounded-full border border-emerald-400/55 flex items-center justify-center">
              <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
            </div>
          </div>
        </div>
      )}

      {/* Center Crosshair & Hitmarker */}
      {hud.phase === 'playing' && !isScopedOverlay && !is2xOverlay && !hud.inVehicle && (
        <div className="fixed inset-0 flex items-center justify-center pointer-events-none">
          <div className="relative w-12 h-12 flex items-center justify-center">
            {hud.activeScope === 'reddot' && hud.isAds ? (
              <div className="w-9 h-9 rounded-lg border border-red-400/55 flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]" />
              </div>
            ) : (
              <>
                <span
                  className="absolute w-0.5 h-2.5 bg-white/90"
                  style={{ transform: `translateY(-${hud.crosshairSpread}px)` }}
                />
                <span
                  className="absolute w-0.5 h-2.5 bg-white/90"
                  style={{ transform: `translateY(${hud.crosshairSpread}px)` }}
                />
                <span
                  className="absolute h-0.5 w-2.5 bg-white/90"
                  style={{ transform: `translateX(-${hud.crosshairSpread}px)` }}
                />
                <span
                  className="absolute h-0.5 w-2.5 bg-white/90"
                  style={{ transform: `translateX(${hud.crosshairSpread}px)` }}
                />
                <span className="w-1 h-1 rounded-full bg-[#d4a84b]" />
              </>
            )}

            {/* Hitmarker X */}
            {hud.hitmarkerTime > 0 && (
              <svg viewBox="0 0 28 28" className="absolute w-7 h-7">
                <line
                  x1="4"
                  y1="4"
                  x2="10"
                  y2="10"
                  stroke={hud.hitmarkerHeadshot ? '#ef4444' : '#ffffff'}
                  strokeWidth="2.4"
                />
                <line
                  x1="24"
                  y1="4"
                  x2="18"
                  y2="10"
                  stroke={hud.hitmarkerHeadshot ? '#ef4444' : '#ffffff'}
                  strokeWidth="2.4"
                />
                <line
                  x1="4"
                  y1="24"
                  x2="10"
                  y2="18"
                  stroke={hud.hitmarkerHeadshot ? '#ef4444' : '#ffffff'}
                  strokeWidth="2.4"
                />
                <line
                  x1="24"
                  y1="24"
                  x2="18"
                  y2="18"
                  stroke={hud.hitmarkerHeadshot ? '#ef4444' : '#ffffff'}
                  strokeWidth="2.4"
                />
              </svg>
            )}
          </div>
        </div>
      )}

      {/* Dynamic Kill-Feed Overlay — Pinned Strictly to Physical Top-Right Corner */}
      {hud.killfeed.length > 0 && (
        <div
          dir="rtl"
          className="fixed top-3 right-3 z-25 pointer-events-none flex flex-col items-end gap-1.5 max-w-[270px] sm:max-w-[340px]"
        >
          <div className="text-[10px] font-extrabold tracking-wide text-[#d4a84b] bg-[#0b0e11]/88 border border-[#d4a84b]/35 px-2.5 py-0.5 rounded">
            سجل الإقصاءات المباشر
          </div>
          {hud.killfeed.map((k, idx) => {
            const ageSec = Math.max(0, hud.survivalTimeSec - k.timestamp);
            const fadeOpacity = ageSec > 9.5 ? Math.max(0.2, 1 - (ageSec - 9.5) / 2.5) : 1;
            const borderClass = k.isPlayerKiller
              ? 'border-r-[#d4a84b]'
              : k.isPlayerVictim
                ? 'border-r-red-500'
                : k.isAllyKiller
                  ? 'border-r-sky-400'
                  : 'border-r-white/35';
            return (
              <div
                key={k.id}
                style={{ opacity: fadeOpacity }}
                className={`bg-[#0b0e11]/88 border border-white/12 border-r-3 ${borderClass} px-2.5 py-1.5 rounded-md text-[11px] flex items-center gap-1.5 shadow-lg transition-all duration-200 ${
                  idx === 0 ? 'ring-1 ring-[#d4a84b]/25' : ''
                }`}
              >
                <span
                  className={
                    k.isPlayerKiller
                      ? 'text-[#d4a84b] font-black'
                      : k.isAllyKiller
                        ? 'text-sky-300 font-bold'
                        : 'text-[#f3f0e6] font-bold'
                  }
                >
                  {k.killer}
                </span>
                <span className="bg-[#161c24] border border-white/10 text-[#cbd5e1] px-1.5 py-0.5 rounded text-[10px] font-mono-num">
                  {k.weaponName}
                </span>
                {k.isHeadshot && (
                  <span className="inline-flex items-center gap-0.5 text-red-400 font-black text-[10px]">
                    <Skull className="w-3 h-3" />
                    رأس
                  </span>
                )}
                <span className="text-[#6b7280] text-[10px]">←</span>
                <span
                  className={
                    k.isPlayerVictim
                      ? 'text-red-400 font-black'
                      : 'text-[#d1d5db] font-semibold'
                  }
                >
                  {k.victim}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {/* Physical Top-Left: Minimap + Alive/Kills + Quick Controls + Voice Chat */}
      <div
        dir="rtl"
        className="fixed top-3 left-3 z-15 flex flex-col items-start gap-2 max-w-[330px]"
      >
        <div className="flex items-start gap-2">
          {/* Minimap & Zone Timer */}
          <div className="bg-[#0b0e11]/88 border border-[#d4a84b]/40 rounded-lg p-1.5 shrink-0">
            <MinimapCanvas hud={hud} size={isTouchMode ? 112 : 148} />
            <div className="mt-1 flex items-center justify-between px-1 text-[10px]">
              <span className={hud.zoneShrinking ? 'text-sky-400 font-bold' : 'text-[#d1d5db] font-bold'}>
                {hud.zoneShrinking ? 'تقلص الدائرة' : `المرحلة ${hud.zonePhase}`}
              </span>
              <span className="font-mono-num font-bold text-[#d4a84b]">
                {formatTime(hud.zoneTimerSec)}
              </span>
            </div>
          </div>

          {/* Alive/Kills + Action Buttons */}
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-1.5">
              <div className="bg-[#0b0e11]/88 border border-[#d4a84b]/40 rounded px-2.5 py-1 flex items-center gap-1.5">
                <span className="text-[10px] text-[#9ca3af] font-bold">الأحياء</span>
                <span className="text-base font-black font-mono-num text-[#f3f0e6]">
                  {hud.aliveCount}
                </span>
              </div>
              <div className="bg-[#0b0e11]/88 border border-[#d4a84b]/40 rounded px-2.5 py-1 flex items-center gap-1.5">
                <span className="text-[10px] text-[#9ca3af] font-bold">القتلى</span>
                <span className="text-base font-black font-mono-num text-[#d4a84b]">{hud.kills}</span>
              </div>
              <div className="bg-[#0b0e11]/88 border border-white/15 rounded px-2 py-1 text-[10px] font-bold">
                {hud.networkMode === 'online' ? (
                  <span className="text-emerald-400">أونلاين</span>
                ) : hud.networkMode === 'local' ? (
                  <span className="text-sky-400 font-mono-num">غرفة {hud.roomCode}</span>
                ) : (
                  <span className="text-amber-300">أوفلاين</span>
                )}
              </div>
            </div>

            <div className="pointer-events-auto flex items-center gap-1">
              <button
                type="button"
                onClick={onToggleFullMap}
                className="bg-[#0b0e11]/88 hover:bg-[#1a2029] border border-white/15 rounded px-2 py-1 text-[11px] font-bold flex items-center gap-1 text-[#f3f0e6] cursor-pointer"
                title="الخريطة الكاملة (M)"
              >
                <MapIcon className="w-3.5 h-3.5 text-[#d4a84b]" />
                <span>M</span>
              </button>
              <button
                type="button"
                onClick={onToggleInventory}
                className="bg-[#0b0e11]/88 hover:bg-[#1a2029] border border-white/15 rounded px-2 py-1 text-[11px] font-bold flex items-center gap-1 text-[#f3f0e6] cursor-pointer"
                title="الحقيبة والمعدات (Tab)"
              >
                <Backpack className="w-3.5 h-3.5 text-[#d4a84b]" />
                <span>Tab</span>
              </button>
              <button
                type="button"
                onClick={() => onUpdateSettings({ ...settings, muted: !settings.muted })}
                className="bg-[#0b0e11]/88 hover:bg-[#1a2029] border border-white/15 rounded p-1 text-[#f3f0e6] cursor-pointer"
                title="الصوت"
              >
                {settings.muted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-[#d4a84b]" />}
              </button>
              <button
                type="button"
                onClick={onPauseToggle}
                className="bg-[#0b0e11]/88 hover:bg-[#1a2029] border border-white/15 rounded p-1 text-[#f3f0e6] cursor-pointer"
                title="إيقاف مؤقت (Esc)"
              >
                <Pause className="w-3.5 h-3.5 text-[#f3f0e6]" />
              </button>
            </div>

            {/* Teammates in Duo / Squad */}
            {hud.teammates.length > 0 && (
              <div className="space-y-1">
                {hud.teammates.map((tm, idx) => (
                  <div
                    key={idx}
                    className="bg-[#0b0e11]/82 border border-sky-500/35 rounded px-2 py-0.5 flex items-center justify-between gap-2 text-[10px]"
                  >
                    <span className={tm.alive ? 'text-sky-300 font-bold' : 'text-gray-500 line-through'}>
                      {tm.name}
                    </span>
                    <div className="w-12 h-1.5 bg-gray-800 rounded overflow-hidden">
                      <div
                        className="h-full bg-sky-400"
                        style={{ width: `${Math.max(0, tm.health)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Proximity Voice Chat Panel (Compact/Collapsible on Touch Mode) */}
        <div className="pointer-events-auto bg-[#0b0e11]/88 border border-white/15 rounded-lg p-2 space-y-1.5 text-[11px] w-full max-w-[270px]">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 font-bold text-[#f3f0e6]">
              {hud.voice.isMicActive ? (
                <Mic className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <MicOff className="w-3.5 h-3.5 text-[#9ca3af]" />
              )}
              <span>الدردشة الصوتية</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="font-mono-num text-[10px] text-[#9ca3af]">
                {hud.voice.connected ? `${hud.voice.peerCount + 1}` : 'أوفلاين'}
              </span>
              {isTouchMode && (
                <button
                  type="button"
                  onClick={() => setVoiceExpandedOnTouch((v) => !v)}
                  className="p-0.5 rounded bg-white/10 text-[#d4a84b] cursor-pointer"
                  aria-label="توسيع الصوت"
                >
                  {voiceExpandedOnTouch ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
              )}
            </div>
          </div>

          {showVoiceBody && (
            <>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 bg-gray-800 rounded overflow-hidden">
                  <div
                    className={`h-full ${hud.voice.isMicActive ? 'bg-emerald-400' : 'bg-gray-600'}`}
                    style={{ width: `${Math.round(hud.voice.micLevel * 100)}%` }}
                  />
                </div>
                <span className="font-mono-num text-[10px] text-[#d4a84b]">
                  {hud.voice.channel === 'all'
                    ? 'الكل (48م)'
                    : hud.voice.channel === 'team'
                      ? 'الفريق فقط'
                      : 'مكتوم'}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                {hud.voice.micPermission !== 'granted' ? (
                  <button
                    type="button"
                    onClick={onEnableMic}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-2 py-1 rounded text-[10px] cursor-pointer"
                  >
                    {hud.voice.micPermission === 'denied' ? 'الميكروفون مرفوض' : 'تفعيل الميكروفون'}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onToggleMicMode}
                    className={`px-2 py-1 rounded text-[10px] font-bold border cursor-pointer ${
                      hud.voice.micMode === 'open'
                        ? 'bg-emerald-900/60 border-emerald-400/60 text-emerald-200'
                        : hud.voice.isPttHeld
                          ? 'bg-[#d4a84b] border-[#d4a84b] text-[#0b0e11]'
                          : 'bg-[#161c24] border-white/15 text-[#d1d5db]'
                    }`}
                  >
                    {hud.voice.micMode === 'open' ? 'ميكروفون مفتوح' : 'اضغط [T] للتحدث'}
                  </button>
                )}

                <button
                  type="button"
                  onClick={onCycleVoiceChannel}
                  className="bg-[#161c24] hover:bg-[#1e2631] border border-white/15 text-[#f3f0e6] px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                  title="تبديل قناة الصوت [Y]"
                >
                  <Radio className="w-3 h-3 text-[#d4a84b]" />
                  <span>[Y] القناة</span>
                </button>

                <button
                  type="button"
                  onClick={onToggleVoiceTest}
                  className={`px-2 py-1 rounded text-[10px] font-bold border cursor-pointer ${
                    hud.voice.testLoopback
                      ? 'bg-sky-900/70 border-sky-400 text-sky-200'
                      : 'bg-[#161c24] border-white/15 text-[#9ca3af]'
                  }`}
                >
                  اختبار الصوت
                </button>
              </div>

              {hud.voice.nearbySpeakers.length > 0 && (
                <div className="pt-1 border-t border-white/10 space-y-1">
                  {hud.voice.nearbySpeakers.slice(0, 4).map((sp) => (
                    <div
                      key={sp.id}
                      className="flex items-center justify-between gap-2 bg-[#161c24] px-2 py-1 rounded"
                    >
                      <div className="flex items-center gap-1.5 truncate">
                        <Volume2
                          className={`w-3 h-3 shrink-0 ${
                            sp.speaking
                              ? sp.isAlly
                                ? 'text-sky-400'
                                : 'text-amber-400'
                              : 'text-gray-500'
                          }`}
                        />
                        <span className={sp.isAlly ? 'text-sky-300 font-bold' : 'text-amber-200 font-bold'}>
                          {sp.name}
                        </span>
                        <span className="text-[9px] text-[#9ca3af]">
                          {sp.isAlly ? '(فريق)' : '(عدو قريب)'}
                        </span>
                      </div>
                      <span className="font-mono-num text-[10px] text-[#d4a84b] shrink-0">
                        {sp.distance}م
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Physical Top-Center: Compass + Zone Alerts + Plane/Skydive Banner */}
      <div className="fixed top-3 left-1/2 -translate-x-1/2 z-15 flex flex-col items-center gap-2 pointer-events-none">
        <div className="bg-[#0b0e11]/84 border border-white/15 rounded px-3.5 py-1 flex items-center gap-2.5 text-xs font-mono-num">
          <span className="text-[#d4a84b] font-bold">{Math.round(hud.compassDeg)}°</span>
          <span className="text-[#f3f0e6] font-bold">{compassLabel(hud.compassDeg)}</span>
          <span className="hidden sm:inline text-[#9ca3af]">|</span>
          <span className="hidden sm:inline text-[#9ca3af] font-sans">{hud.weatherLabel}</span>
        </div>

        {hud.phase === 'plane' && !isTouchMode && (
          <div className="pointer-events-auto bg-[#0b0e11]/92 border border-[#d4a84b] rounded-lg px-5 py-3 text-center shadow-xl">
            <div className="text-sm font-extrabold text-[#f3f0e6]">
              أنت على متن الطائرة العسكرية — اختر موقع الهبوط!
            </div>
            <button
              type="button"
              onClick={onJumpFromPlane}
              className="mt-2 bg-[#d4a84b] hover:bg-[#e3ba5d] text-[#0b0e11] font-black text-xs px-4 py-1.5 rounded cursor-pointer"
            >
              اقفز بالمظلة الآن (Space)
            </button>
          </div>
        )}

        {hud.phase === 'skydiving' && (
          <div className="bg-[#0b0e11]/88 border border-sky-400/50 rounded-lg px-4 py-1.5 text-center">
            <div className="text-xs font-bold text-sky-300">
              {hud.isParachuteOpen
                ? isTouchMode
                  ? 'المظلة مفتوحة — وجّه الهبوط بعصا اليسار'
                  : 'المظلة مفتوحة — وجّه الهبوط بـ WASD'
                : isTouchMode
                  ? 'سقوط حر — اضغط فتح المظلة'
                  : 'سقوط حر — اضغط Space لفتح المظلة'}
            </div>
            <div className="text-sm font-black font-mono-num text-white mt-0.5">
              الارتفاع: {hud.altitude} م
            </div>
          </div>
        )}

        {hud.airdropAnnounce && (
          <div className="bg-[#7f1d1d]/92 border border-amber-400/70 rounded px-4 py-1.5 text-xs font-bold text-amber-200">
            {hud.airdropAnnounce}
          </div>
        )}

        {hud.inRedzone && (
          <div className="bg-red-900/92 border border-red-400 rounded px-4 py-1.5 text-xs font-extrabold text-white">
            تحذير: أنت داخل منطقة القصف الجوي! احتمِ داخل مبنى!
          </div>
        )}

        {hud.outsideZone && hud.phase === 'playing' && (
          <div className="bg-blue-900/92 border border-blue-400 rounded px-4 py-1.5 text-xs font-extrabold text-white">
            خارج المنطقة الآمنة! العاصفة المغناطيسية تستنزف صحتك!
          </div>
        )}
      </div>

      {/* Dedicated Android / Mobile Multi-Touch Controls */}
      {isTouchMode &&
        !showInventory &&
        !showFullMap &&
        hud.phase !== 'paused' &&
        hud.phase !== 'victory' &&
        hud.phase !== 'gameover' && (
          <TouchControls hud={hud} callbacks={touchCallbacks} />
        )}

      {/* Mid-Bottom Prompts: Interaction, Reload/Med Progress, PointerHint */}
      <div className="fixed bottom-32 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 pointer-events-none">
        {hud.promptText && !isTouchMode && (
          <div className="bg-[#0b0e11]/92 border border-[#d4a84b] text-[#f3f0e6] px-4 py-1.5 rounded-md text-sm font-extrabold shadow-lg">
            {hud.promptText}
          </div>
        )}

        {(hud.isReloading || hud.isUsingMed) && (
          <div className="bg-[#0b0e11]/92 border border-white/20 rounded-md px-4 py-2 w-60">
            <div className="flex justify-between text-xs font-bold mb-1">
              <span>{hud.isReloading ? 'جاري إعادة التعبئة...' : `استخدام: ${hud.medUseLabel}`}</span>
              <span className="font-mono-num text-[#d4a84b]">
                {Math.round((hud.isReloading ? hud.reloadProgress : hud.medUseProgress) * 100)}%
              </span>
            </div>
            <div className="h-1.5 bg-gray-800 rounded overflow-hidden">
              <div
                className="h-full bg-[#d4a84b]"
                style={{
                  width: `${Math.round((hud.isReloading ? hud.reloadProgress : hud.medUseProgress) * 100)}%`,
                }}
              />
            </div>
          </div>
        )}

        {hud.phase === 'playing' && !hud.pointerLocked && !isTouchMode && !showInventory && !showFullMap && (
          <div className="bg-[#0b0e11]/80 border border-white/15 text-[#b8b5aa] px-3 py-1 rounded text-[11px]">
            انقر داخل الساحة للتحكم الحر بالماوس (أو اسحب للالتفاف / الأسهم)
          </div>
        )}
      </div>

      {/* Bottom HUD Cluster: Compact Bar for Touch Mode, Full 3-Column Bar for Desktop */}
      {hud.phase === 'playing' && (
        isTouchMode ? (
          <div className="fixed bottom-2 left-1/2 -translate-x-1/2 w-[calc(100%-1rem)] max-w-md px-1 pointer-events-none">
            {hud.inVehicle && (
              <div className="mb-1.5 mx-auto w-fit bg-[#0b0e11]/90 border border-[#d4a84b]/50 rounded-lg px-3 py-1 flex items-center gap-3 text-[11px]">
                <span className="font-extrabold text-[#d4a84b]">{hud.vehicleName}</span>
                <span className="font-mono-num font-bold text-white">{hud.vehicleSpeedKmh} كم/س</span>
                <span className="font-mono-num text-[#9ca3af]">هيكل: {hud.vehicleHp}</span>
              </div>
            )}
            <div className="bg-[#0b0e11]/90 border border-white/15 rounded-xl px-2.5 py-1.5 flex items-center justify-between gap-2 pointer-events-auto">
              {/* Compact Health + Armor */}
              <div className="w-28 shrink-0 space-y-1">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="font-bold text-[#f3f0e6] flex items-center gap-1">
                    <Heart className="w-3 h-3 text-red-400" />
                    {hud.health}
                  </span>
                  <span className="font-mono-num text-[#d4a84b]">
                    خ{hud.helmetLevel} د{hud.vestLevel}
                  </span>
                </div>
                <div className="h-2 bg-gray-800 rounded overflow-hidden">
                  <div
                    className={`h-full ${
                      hud.health > 45 ? 'bg-emerald-500' : hud.health > 20 ? 'bg-amber-400' : 'bg-red-500'
                    }`}
                    style={{ width: `${hud.health}%` }}
                  />
                </div>
              </div>

              {/* Compact Tappable Weapon Slots */}
              <div className="flex-1 grid grid-cols-3 gap-1">
                {([0, 1, 2] as const).map((slot) => {
                  const w = hud.weapons[slot];
                  const def = w ? WEAPONS[w.defId] : null;
                  const active = hud.activeSlot === slot;
                  return (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => onSelectWeaponSlot(slot)}
                      className={`px-1.5 py-1 rounded border text-right cursor-pointer ${
                        active
                          ? 'bg-[#1f2730] border-[#d4a84b]'
                          : 'bg-[#12161c] border-white/10 opacity-75'
                      }`}
                    >
                      <div className="text-[10px] font-extrabold text-[#f3f0e6] truncate">
                        {def ? def.name : 'فارغ'}
                      </div>
                      <div className="text-[9px] font-mono-num text-[#d4a84b]">
                        {w ? `${w.ammoInMag}/${activeWeaponDef && active ? hud.ammoBag[activeWeaponDef.ammoType] : ''}` : `[${slot + 1}]`}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          <div className="fixed bottom-3 left-1/2 -translate-x-1/2 w-full max-w-4xl px-4">
            {/* Vehicle Dashboard */}
            {hud.inVehicle && (
              <div className="mb-2 mx-auto w-fit bg-[#0b0e11]/90 border border-[#d4a84b]/50 rounded-lg px-4 py-1.5 flex items-center gap-4 text-xs">
                <span className="font-extrabold text-[#d4a84b]">{hud.vehicleName}</span>
                <span className="font-mono-num font-bold text-white">
                  {hud.vehicleSpeedKmh} كم/س
                </span>
                <span className="font-mono-num text-[#9ca3af]">هيكل: {hud.vehicleHp}</span>
                <span className="text-[#d4a84b]">[F] نزول</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-end">
              {/* Left: Gear & Stance */}
              <div className="md:col-span-3 bg-[#0b0e11]/88 border border-white/15 rounded-lg p-2.5 flex items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <div
                    className={`px-2 py-1 rounded border text-[11px] font-bold ${
                      hud.helmetLevel > 0 ? 'border-[#d4a84b]/70 text-[#d4a84b]' : 'border-white/10 text-gray-500'
                    }`}
                  >
                    خوذة {hud.helmetLevel || '-'}
                  </div>
                  <div
                    className={`px-2 py-1 rounded border text-[11px] font-bold ${
                      hud.vestLevel > 0 ? 'border-[#d4a84b]/70 text-[#d4a84b]' : 'border-white/10 text-gray-500'
                    }`}
                  >
                    درع {hud.vestLevel || '-'}
                  </div>
                  {hud.hasPan && (
                    <div className="px-1.5 py-1 rounded border border-amber-400/60 text-amber-300 text-[11px] font-bold">
                      مقلاة
                    </div>
                  )}
                </div>
                <div className="text-[11px] font-mono-num text-[#9ca3af]">
                  {hud.perspective.toUpperCase()} ·{' '}
                  {hud.stance === 'prone' ? 'انبطاح' : hud.stance === 'crouch' ? 'انحناء' : 'وقوف'}
                </div>
              </div>

              {/* Center: Health & Boost */}
              <div className="md:col-span-4 bg-[#0b0e11]/88 border border-white/15 rounded-lg p-2.5 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1 font-bold text-[#f3f0e6]">
                    <Heart className="w-3.5 h-3.5 text-red-400" />
                    الصحة
                  </span>
                  <span className="font-mono-num font-black text-sm text-[#f3f0e6]">
                    {hud.health} / {hud.maxHealth}
                  </span>
                </div>
                <div className="h-2.5 bg-gray-800 rounded overflow-hidden">
                  <div
                    className={`h-full transition-all duration-150 ${
                      hud.health > 45 ? 'bg-emerald-500' : hud.health > 20 ? 'bg-amber-400' : 'bg-red-500'
                    }`}
                    style={{ width: `${hud.health}%` }}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-3 h-3 text-amber-400 shrink-0" />
                  <div className="flex-1 h-1.5 bg-gray-800 rounded overflow-hidden">
                    <div
                      className="h-full bg-amber-400"
                      style={{ width: `${hud.boost}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-mono-num text-amber-300">{hud.boost}%</span>
                </div>
              </div>

              {/* Right: Active Weapons & Throwables (Tappable slots for Android touch + PC) */}
              <div className="md:col-span-5 bg-[#0b0e11]/88 border border-white/15 rounded-lg p-2 flex items-center justify-between gap-2 pointer-events-auto">
                <div className="flex-1 grid grid-cols-3 gap-1.5">
                  {([0, 1, 2] as const).map((slot) => {
                    const w = hud.weapons[slot];
                    const def = w ? WEAPONS[w.defId] : null;
                    const active = hud.activeSlot === slot;
                    return (
                      <button
                        key={slot}
                        type="button"
                        onClick={() => onSelectWeaponSlot(slot)}
                        className={`px-2 py-1.5 rounded border text-right cursor-pointer transition-colors ${
                          active
                            ? 'bg-[#1f2730] border-[#d4a84b]'
                            : 'bg-[#12161c] border-white/10 opacity-75 hover:opacity-100'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[10px] text-[#9ca3af] font-mono-num">
                          <span>[{slot + 1}]</span>
                          {w && <span>{SCOPE_INFO[def?.builtInScope ?? w.scope].zoomLabel}</span>}
                        </div>
                        <div className="text-xs font-extrabold text-[#f3f0e6] truncate">
                          {def ? def.name : 'فارغ'}
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="border-r border-white/10 pr-2.5 text-left shrink-0">
                  <div className="text-lg font-black font-mono-num text-[#d4a84b] leading-none">
                    {activeWeapon ? activeWeapon.ammoInMag : 0}
                    <span className="text-xs text-[#9ca3af] font-normal">
                      {' '}
                      / {activeWeaponDef ? hud.ammoBag[activeWeaponDef.ammoType] : 0}
                    </span>
                  </div>
                  <div className="mt-1 text-[10px] text-[#b8b5aa]">
                    [G] {THROWABLE_INFO[hud.activeThrowable].shortAr}:{' '}
                    <span className="font-mono-num text-white">
                      {hud.throwables[hud.activeThrowable]}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )
      )}

      {/* Inventory & Attachments Modal (Tab) */}
      {showInventory && hud.phase === 'playing' && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-[#0b0e11]/78 pointer-events-auto p-4">
          <div className="bg-[#12171e] border border-[#d4a84b]/50 rounded-xl w-full max-w-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h2 className="text-lg font-black text-[#d4a84b] flex items-center gap-2">
                <Backpack className="w-5 h-5" />
                الحقيبة والعتاد والتعديلات
              </h2>
              <button
                type="button"
                onClick={onToggleInventory}
                className="text-xs bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded font-bold cursor-pointer"
              >
                إغلاق (Tab)
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              {/* Meds */}
              <div className="bg-[#0b0e11]/80 border border-white/10 rounded-lg p-3 space-y-2">
                <div className="font-bold text-[#d4a84b]">المستلزمات الطبية (اضغط للاستخدام)</div>
                {(Object.keys(MED_INFO) as MedType[]).map((mt) => (
                  <button
                    key={mt}
                    type="button"
                    disabled={hud.meds[mt] <= 0}
                    onClick={() => onUseMed(mt)}
                    className="w-full flex items-center justify-between bg-[#161c24] hover:bg-[#1e2631] disabled:opacity-40 px-2.5 py-2 rounded border border-white/10 cursor-pointer"
                  >
                    <span className="font-bold">{MED_INFO[mt].labelAr}</span>
                    <span className="font-mono-num text-[#d4a84b]">x{hud.meds[mt]}</span>
                  </button>
                ))}
              </div>

              {/* Attachments */}
              <div className="bg-[#0b0e11]/80 border border-white/10 rounded-lg p-3 space-y-2">
                <div className="font-bold text-[#d4a84b]">العدسات والإضافات للسلاح النشط</div>
                {activeWeaponDef ? (
                  <div className="text-[11px] text-[#9ca3af] mb-2">
                    السلاح الحالي: <span className="text-white font-bold">{activeWeaponDef.nameAr}</span>
                  </div>
                ) : (
                  <div className="text-[11px] text-gray-500">لا يوجد سلاح نشط</div>
                )}

                {hud.spareAttachments.scopes.map((sc, i) => (
                  <button
                    key={`${sc}_${i}`}
                    type="button"
                    onClick={() => onAttachScope(sc)}
                    className="w-full flex items-center justify-between bg-[#161c24] hover:bg-[#1e2631] px-2.5 py-1.5 rounded border border-purple-500/30 cursor-pointer"
                  >
                    <span>تركيب {SCOPE_INFO[sc].labelAr}</span>
                    <span className="text-purple-300">تركيب</span>
                  </button>
                ))}
                {hud.spareAttachments.muzzles.map((mz, i) => (
                  <button
                    key={`${mz}_${i}`}
                    type="button"
                    onClick={() => onAttachMuzzle(mz)}
                    className="w-full flex items-center justify-between bg-[#161c24] hover:bg-[#1e2631] px-2.5 py-1.5 rounded border border-purple-500/30 cursor-pointer"
                  >
                    <span>تركيب كاتم صوت</span>
                    <span className="text-purple-300">تركيب</span>
                  </button>
                ))}
                {hud.spareAttachments.extMags > 0 && (
                  <button
                    type="button"
                    onClick={onAttachExtMag}
                    className="w-full flex items-center justify-between bg-[#161c24] hover:bg-[#1e2631] px-2.5 py-1.5 rounded border border-purple-500/30 cursor-pointer"
                  >
                    <span>مخزن ذخيرة موسع</span>
                    <span className="text-purple-300">x{hud.spareAttachments.extMags}</span>
                  </button>
                )}
              </div>

              {/* Ammo & Gear Summary */}
              <div className="bg-[#0b0e11]/80 border border-white/10 rounded-lg p-3 space-y-2">
                <div className="font-bold text-[#d4a84b]">الذخيرة والعتاد</div>
                <div className="grid grid-cols-2 gap-1.5">
                  {(Object.keys(AMMO_LABELS) as Array<keyof typeof AMMO_LABELS>).map((a) => (
                    <div
                      key={a}
                      className="flex justify-between bg-[#161c24] px-2 py-1 rounded text-[11px]"
                    >
                      <span className="text-[#9ca3af]">{AMMO_LABELS[a]}</span>
                      <span className="font-mono-num font-bold">{hud.ammoBag[a]}</span>
                    </div>
                  ))}
                </div>
                <div className="pt-2 border-t border-white/10 text-[11px] space-y-1 text-[#d1d5db]">
                  <div>حقيبة الظهر: المستوى {hud.backpackLevel || 'لا يوجد'}</div>
                  <div>متانة الخوذة: {hud.helmetLevel ? `${hud.helmetDurability}%` : 'بدون'}</div>
                  <div>متانة الدرع: {hud.vestLevel ? `${hud.vestDurability}%` : 'بدون'}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Full Tactical Map Modal (M) */}
      {showFullMap && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-[#0b0e11]/82 pointer-events-auto p-4">
          <div className="bg-[#12171e] border border-[#d4a84b]/50 rounded-xl p-4 shadow-2xl flex flex-col items-center gap-3">
            <div className="w-full flex items-center justify-between">
              <span className="font-black text-[#d4a84b]">الخريطة التكتيكية الشاملة</span>
              <button
                type="button"
                onClick={onToggleFullMap}
                className="text-xs bg-white/10 hover:bg-white/20 px-3 py-1 rounded font-bold cursor-pointer"
              >
                إغلاق (M)
              </button>
            </div>
            <MinimapCanvas hud={hud} size={440} />
            <div className="flex flex-wrap gap-4 text-[11px] text-[#b8b5aa]">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-white inline-block" /> موقعك
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-400 inline-block" /> الحلفاء / الدائرة الزرقاء
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-yellow-400 inline-block" /> المركبات
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" /> صندوق الدعم / القصف
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Pause Modal */}
      {hud.phase === 'paused' && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#0b0e11]/84 pointer-events-auto p-4">
          <div className="bg-[#12171e] border border-[#d4a84b]/50 rounded-xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-black text-[#f3f0e6] flex items-center gap-2">
                <Shield className="w-5 h-5 text-[#d4a84b]" />
                إيقاف مؤقت وإعدادات الجودة
              </h2>
              <span className="font-mono-num text-xs text-[#d4a84b] bg-[#0b0e11] px-2.5 py-1 rounded border border-white/10">
                {hud.liveFps} FPS · {hud.renderResolution.width}×{hud.renderResolution.height}
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <div className="text-[#9ca3af] mb-1">جودة الرسوميات (4K UHD)</div>
                <div className="grid grid-cols-5 gap-1">
                  {(['smooth', 'balanced', 'hd', 'hdr', 'ultra'] as GraphicsQuality[]).map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => onUpdateSettings({ ...settings, quality: q })}
                      className={`py-1.5 px-1 rounded border font-bold text-[10px] cursor-pointer ${
                        settings.quality === q
                          ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                          : 'bg-[#1a2029] text-white border-white/10'
                      }`}
                    >
                      {q === 'smooth'
                        ? 'سلسة'
                        : q === 'balanced'
                          ? 'متوازنة'
                          : q === 'hd'
                            ? 'HD'
                            : q === 'hdr'
                              ? 'HDR'
                              : '4K UHD'}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-[#9ca3af] mb-1">نظام التحكم (أندرويد / كمبيوتر)</div>
                <div className="grid grid-cols-3 gap-1.5">
                  {([
                    ['auto', 'تلقائي'],
                    ['touch', 'أندرويد (لمس)'],
                    ['pc', 'كمبيوتر'],
                  ] as Array<[ControlScheme, string]>).map(([val, lbl]) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => onUpdateSettings({ ...settings, controlScheme: val })}
                      className={`py-1.5 px-1 rounded border font-bold text-[11px] cursor-pointer ${
                        (settings.controlScheme ?? 'auto') === val
                          ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                          : 'bg-[#1a2029] text-white border-white/10'
                      }`}
                    >
                      {lbl}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-[#9ca3af] mb-1">نمط الألوان</div>
                <div className="grid grid-cols-5 gap-1">
                  {(['classic', 'colorful', 'realistic', 'soft', 'movie'] as GraphicsStyle[]).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => onUpdateSettings({ ...settings, style: st })}
                      className={`py-1.5 px-1 rounded border font-bold text-[11px] cursor-pointer ${
                        settings.style === st
                          ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                          : 'bg-[#1a2029] text-white border-white/10'
                      }`}
                    >
                      {st === 'classic'
                        ? 'كلاسيكي'
                        : st === 'colorful'
                          ? 'ملون'
                          : st === 'realistic'
                            ? 'واقعي'
                            : st === 'soft'
                              ? 'ناعم'
                              : 'فيلم'}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-[#9ca3af] mb-1">معدل الإطارات (FPS)</div>
                <div className="grid grid-cols-4 gap-1.5">
                  {([30, 60, 90, 120] as TargetFps[]).map((f) => (
                    <button
                      key={f}
                      type="button"
                      onClick={() => onUpdateSettings({ ...settings, targetFps: f })}
                      className={`py-1.5 rounded border font-mono-num font-bold cursor-pointer ${
                        settings.targetFps === f
                          ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                          : 'bg-[#1a2029] text-white border-white/10'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <button
                type="button"
                onClick={onPauseToggle}
                className="w-full bg-[#d4a84b] hover:bg-[#e3ba5d] text-[#0b0e11] font-black py-2.5 rounded-lg flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-4 h-4" />
                استئناف المعركة
              </button>
              <button
                type="button"
                onClick={onExitToMenu}
                className="w-full bg-[#1f2630] hover:bg-[#2a3340] text-white font-bold py-2.5 rounded-lg cursor-pointer"
              >
                العودة إلى القائمة الرئيسية
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Victory / Game Over Post-Match Statistics Modal */}
      {(hud.phase === 'victory' || hud.phase === 'gameover') && (() => {
        const tierInfo = computeMatchTier(hud.rank, hud.kills);
        return (
          <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#0b0e11]/88 pointer-events-auto p-4">
            <div className="bg-[#12171e] border-2 border-[#d4a84b] rounded-2xl w-full max-w-2xl p-6 md:p-7 text-center shadow-2xl space-y-5">
              {hud.phase === 'victory' ? (
                <>
                  <Trophy className="w-12 h-12 text-[#d4a84b] mx-auto" />
                  <div className="text-xs font-mono-num tracking-widest text-[#d4a84b]">
                    WINNER WINNER CHICKEN DINNER
                  </div>
                  <h2 className="text-2xl md:text-3xl font-black text-[#f3f0e6]">
                    انتصار حاسم — الناجي الأخير!
                  </h2>
                </>
              ) : (
                <>
                  <Crosshair className="w-11 h-11 text-red-400 mx-auto" />
                  <div className="text-xs font-mono-num text-red-400">MATCH SUMMARY</div>
                  <h2 className="text-2xl font-black text-[#f3f0e6]">
                    ملخص إحصائيات الجولة
                  </h2>
                </>
              )}

              {/* Primary 4 Requested Stat Cards: Rank Tier, Kills, Distance Traveled, Loot Collected */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-right">
                <div className="bg-[#0b0e11]/90 border border-[#d4a84b]/45 rounded-xl p-3.5">
                  <div className="text-[11px] text-[#9ca3af] font-bold">مستوى الترتيب</div>
                  <div className="mt-1 flex items-baseline justify-between">
                    <span className="text-2xl font-black font-mono-num text-[#d4a84b]">
                      #{hud.rank}
                    </span>
                    <span className="text-xs font-mono-num text-[#9ca3af]">
                      / {hud.totalCount}
                    </span>
                  </div>
                  <div className="mt-1 text-[11px] font-bold text-amber-200">
                    التقييم {tierInfo.tier} · {tierInfo.labelAr}
                  </div>
                </div>

                <div className="bg-[#0b0e11]/90 border border-white/15 rounded-xl p-3.5">
                  <div className="text-[11px] text-[#9ca3af] font-bold">عدد القتلى</div>
                  <div className="mt-1 text-2xl font-black font-mono-num text-white">
                    {hud.kills}
                  </div>
                  <div className="mt-1 text-[11px] text-[#b8b5aa]">
                    إصابات الرأس: <span className="font-mono-num text-red-400">{hud.headshots}</span>
                  </div>
                </div>

                <div className="bg-[#0b0e11]/90 border border-white/15 rounded-xl p-3.5">
                  <div className="text-[11px] text-[#9ca3af] font-bold">المسافة المقطوعة</div>
                  <div className="mt-1 text-2xl font-black font-mono-num text-sky-300">
                    {formatDistance(hud.distanceTraveledMeters)}
                  </div>
                  <div className="mt-1 text-[11px] text-[#b8b5aa]">
                    زمن الصمود: <span className="font-mono-num text-white">{formatTime(hud.survivalTimeSec)}</span>
                  </div>
                </div>

                <div className="bg-[#0b0e11]/90 border border-white/15 rounded-xl p-3.5">
                  <div className="text-[11px] text-[#9ca3af] font-bold">العتاد المجموع</div>
                  <div className="mt-1 text-2xl font-black font-mono-num text-emerald-400">
                    {hud.lootCollected.total}
                  </div>
                  <div className="mt-1 text-[11px] text-[#b8b5aa]">
                    إجمالي الضرر: <span className="font-mono-num text-white">{hud.damageDealt}</span>
                  </div>
                </div>
              </div>

              {/* Loot Breakdown Strip */}
              <div className="bg-[#0b0e11]/75 border border-white/10 rounded-xl px-4 py-3 flex flex-wrap items-center justify-around gap-3 text-xs">
                <div>
                  <span className="text-[#9ca3af]">الأسلحة: </span>
                  <span className="font-mono-num font-bold text-[#f3f0e6]">
                    {hud.lootCollected.weapons}
                  </span>
                </div>
                <div>
                  <span className="text-[#9ca3af]">الدروع والخوذ: </span>
                  <span className="font-mono-num font-bold text-[#f3f0e6]">
                    {hud.lootCollected.armor}
                  </span>
                </div>
                <div>
                  <span className="text-[#9ca3af]">المستلزمات الطبية: </span>
                  <span className="font-mono-num font-bold text-[#f3f0e6]">
                    {hud.lootCollected.meds}
                  </span>
                </div>
                <div>
                  <span className="text-[#9ca3af]">الذخيرة والتعديلات: </span>
                  <span className="font-mono-num font-bold text-[#f3f0e6]">
                    {hud.lootCollected.ammoAndMods}
                  </span>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={onRestart}
                  className="flex-1 bg-[#d4a84b] hover:bg-[#e3ba5d] text-[#0b0e11] font-black py-3 rounded-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  جولة جديدة
                </button>
                <button
                  type="button"
                  onClick={onExitToMenu}
                  className="flex-1 bg-[#1f2630] hover:bg-[#2a3340] text-white font-bold py-3 rounded-lg cursor-pointer"
                >
                  القائمة الرئيسية
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
