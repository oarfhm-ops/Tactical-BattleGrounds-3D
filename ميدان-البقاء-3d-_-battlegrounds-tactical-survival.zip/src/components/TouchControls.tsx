import { useCallback, useEffect, useRef, useState } from 'react';
import type { PointerEvent as ReactPointerEvent } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Car,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Crosshair,
  Eye,
  Flame,
  HeartPulse,
  Mic,
  PackageOpen,
  RotateCw,
  Target,
} from 'lucide-react';
import { SCOPE_INFO, WEAPONS } from '../game/weaponsData';
import type { HudSnapshot } from '../game/types';

export interface TouchControlCallbacks {
  onTouchMove: (x: number, y: number, sprint: boolean) => void;
  onTouchLook: (dx: number, dy: number) => void;
  onTouchFire: (firing: boolean) => void;
  onTouchVehicleInput: (throttle: number, steer: number, brake: boolean) => void;
  onToggleAds: () => void;
  onTogglePerspective: () => void;
  onToggleLean: (dir: -1 | 1) => void;
  onToggleStance: (target: 'crouch' | 'prone') => void;
  onJumpOrParachute: () => void;
  onInteract: () => void;
  onReload: () => void;
  onThrowGrenade: () => void;
  onCycleThrowable: () => void;
  onQuickMed: () => void;
  onVoicePtt: (held: boolean) => void;
}

interface TouchControlsProps {
  hud: HudSnapshot;
  callbacks: TouchControlCallbacks;
}

function trySetPointerCapture(el: Element, pointerId: number) {
  try {
    el.setPointerCapture?.(pointerId);
  } catch {
    // Window-level pointer listeners handle tracking when capture is unavailable
  }
}

function tryReleasePointerCapture(el: Element, pointerId: number) {
  try {
    if (el.hasPointerCapture?.(pointerId)) {
      el.releasePointerCapture(pointerId);
    }
  } catch {
    // ignore
  }
}

export function TouchControls({ hud, callbacks }: TouchControlsProps) {
  const callbacksRef = useRef(callbacks);
  callbacksRef.current = callbacks;

  // Left Virtual Analog Joystick
  const joyPadRef = useRef<HTMLDivElement | null>(null);
  const joyPointerId = useRef<number | null>(null);
  const joyCenter = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const [knobOffset, setKnobOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [sprinting, setSprinting] = useState(false);

  // Right Look Pad (multi-touch safe)
  const lookPointerId = useRef<number | null>(null);
  const lastLookPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Fire Buttons (main drag-to-aim right button + left secondary button)
  const firePointerId = useRef<number | null>(null);
  const lastFirePos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const leftFirePointerId = useRef<number | null>(null);
  const [isFiringUi, setIsFiringUi] = useState(false);

  // Dedup tap timestamp guard so pointerdown + click never double-fires
  const lastTapMap = useRef<Record<string, number>>({});
  const runTapAction = useCallback((key: string, fn: () => void) => {
    const now = performance.now();
    const prev = lastTapMap.current[key] ?? 0;
    if (now - prev < 220) return;
    lastTapMap.current[key] = now;
    fn();
  }, []);

  // Vehicle Touch State
  const vehRef = useRef({ throttle: 0, steer: 0, brake: false });
  const syncVehicle = useCallback(() => {
    callbacksRef.current.onTouchVehicleInput(
      vehRef.current.throttle,
      vehRef.current.steer,
      vehRef.current.brake,
    );
  }, []);

  const MAX_JOY_RADIUS = 48;

  const updateJoystick = useCallback((clientX: number, clientY: number) => {
    const dx = clientX - joyCenter.current.x;
    const dy = clientY - joyCenter.current.y;
    const dist = Math.hypot(dx, dy);
    const clamped = Math.min(dist, MAX_JOY_RADIUS);
    const angle = Math.atan2(dy, dx);
    const kx = dist > 0.001 ? Math.cos(angle) * clamped : 0;
    const ky = dist > 0.001 ? Math.sin(angle) * clamped : 0;
    setKnobOffset({ x: kx, y: ky });

    // Boost initial tap near center slightly so even small finger nudges register cleanly
    const normX = kx / MAX_JOY_RADIUS;
    const normForward = -ky / MAX_JOY_RADIUS;
    const isSprint = normForward > 0.72 && dist >= MAX_JOY_RADIUS * 0.72;
    setSprinting(isSprint);
    callbacksRef.current.onTouchMove(normX, normForward, isSprint);
  }, []);

  const resetJoystick = useCallback(() => {
    joyPointerId.current = null;
    setKnobOffset({ x: 0, y: 0 });
    setSprinting(false);
    callbacksRef.current.onTouchMove(0, 0, false);
  }, []);

  // Global window pointer tracking so dragging past button bounds never drops movement, firing, or camera look
  useEffect(() => {
    const onWinPointerMove = (e: PointerEvent) => {
      if (joyPointerId.current === e.pointerId) {
        if (joyPadRef.current) {
          const rect = joyPadRef.current.getBoundingClientRect();
          joyCenter.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
        }
        updateJoystick(e.clientX, e.clientY);
      }
      if (lookPointerId.current === e.pointerId) {
        const dx = e.clientX - lastLookPos.current.x;
        const dy = e.clientY - lastLookPos.current.y;
        lastLookPos.current = { x: e.clientX, y: e.clientY };
        callbacksRef.current.onTouchLook(dx, dy);
      }
      if (firePointerId.current === e.pointerId) {
        const dx = e.clientX - lastFirePos.current.x;
        const dy = e.clientY - lastFirePos.current.y;
        lastFirePos.current = { x: e.clientX, y: e.clientY };
        callbacksRef.current.onTouchLook(dx * 0.9, dy * 0.9);
      }
    };

    const onWinPointerEnd = (e: PointerEvent) => {
      if (joyPointerId.current === e.pointerId) {
        resetJoystick();
      }
      if (lookPointerId.current === e.pointerId) {
        lookPointerId.current = null;
      }
      if (firePointerId.current === e.pointerId) {
        firePointerId.current = null;
        if (leftFirePointerId.current === null) {
          setIsFiringUi(false);
          callbacksRef.current.onTouchFire(false);
        }
      }
      if (leftFirePointerId.current === e.pointerId) {
        leftFirePointerId.current = null;
        if (firePointerId.current === null) {
          setIsFiringUi(false);
          callbacksRef.current.onTouchFire(false);
        }
      }
    };

    const onWinBlur = () => {
      resetJoystick();
      lookPointerId.current = null;
      firePointerId.current = null;
      leftFirePointerId.current = null;
      setIsFiringUi(false);
      callbacksRef.current.onTouchFire(false);
      callbacksRef.current.onVoicePtt(false);
      vehRef.current = { throttle: 0, steer: 0, brake: false };
      syncVehicle();
    };

    window.addEventListener('pointermove', onWinPointerMove, { passive: true });
    window.addEventListener('pointerup', onWinPointerEnd);
    window.addEventListener('pointercancel', onWinPointerEnd);
    window.addEventListener('blur', onWinBlur);
    return () => {
      window.removeEventListener('pointermove', onWinPointerMove);
      window.removeEventListener('pointerup', onWinPointerEnd);
      window.removeEventListener('pointercancel', onWinPointerEnd);
      window.removeEventListener('blur', onWinBlur);
    };
  }, [resetJoystick, syncVehicle, updateJoystick]);

  const handleJoyDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    trySetPointerCapture(e.currentTarget, e.pointerId);
    joyPointerId.current = e.pointerId;
    const rect = e.currentTarget.getBoundingClientRect();
    joyCenter.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== e.pointerId) return;
    e.stopPropagation();
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyUp = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== e.pointerId) return;
    e.stopPropagation();
    tryReleasePointerCapture(e.currentTarget, e.pointerId);
    resetJoystick();
  };

  const handleLookDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    lookPointerId.current = e.pointerId;
    lastLookPos.current = { x: e.clientX, y: e.clientY };
    trySetPointerCapture(e.currentTarget, e.pointerId);
  };

  const handleLookMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (lookPointerId.current !== e.pointerId) return;
    const dx = e.clientX - lastLookPos.current.x;
    const dy = e.clientY - lastLookPos.current.y;
    lastLookPos.current = { x: e.clientX, y: e.clientY };
    callbacks.onTouchLook(dx, dy);
  };

  const handleLookUp = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (lookPointerId.current !== e.pointerId) return;
    tryReleasePointerCapture(e.currentTarget, e.pointerId);
    lookPointerId.current = null;
  };

  const handleFireDown = (e: ReactPointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    trySetPointerCapture(e.currentTarget, e.pointerId);
    firePointerId.current = e.pointerId;
    lastFirePos.current = { x: e.clientX, y: e.clientY };
    setIsFiringUi(true);
    callbacks.onTouchFire(true);
  };

  const handleFireMove = (e: ReactPointerEvent<HTMLButtonElement>) => {
    if (firePointerId.current !== e.pointerId) return;
    e.stopPropagation();
    const dx = e.clientX - lastFirePos.current.x;
    const dy = e.clientY - lastFirePos.current.y;
    lastFirePos.current = { x: e.clientX, y: e.clientY };
    callbacks.onTouchLook(dx * 0.9, dy * 0.9);
  };

  const handleFireUp = (e: ReactPointerEvent<HTMLButtonElement>) => {
    if (firePointerId.current !== e.pointerId) return;
    e.stopPropagation();
    tryReleasePointerCapture(e.currentTarget, e.pointerId);
    firePointerId.current = null;
    if (leftFirePointerId.current === null) {
      setIsFiringUi(false);
      callbacks.onTouchFire(false);
    }
  };

  const activeWeapon = hud.weapons[hud.activeSlot];
  const activeWeaponDef = activeWeapon ? WEAPONS[activeWeapon.defId] : null;
  const scopeLabel = activeWeapon
    ? SCOPE_INFO[activeWeaponDef?.builtInScope ?? activeWeapon.scope].zoomLabel
    : '1x';

  return (
    <div
      className="fixed inset-0 z-20 pointer-events-none touch-none select-none"
      style={{ touchAction: 'none' }}
    >
      {/* Full Right-Half Camera Drag Look Zone */}
      <div
        onPointerDown={handleLookDown}
        onPointerMove={handleLookMove}
        onPointerUp={handleLookUp}
        onPointerCancel={handleLookUp}
        className="fixed top-20 bottom-20 right-0 w-1/2 pointer-events-auto"
        style={{ touchAction: 'none' }}
      />

      {/* Plane & Skydiving Touch Controls */}
      {(hud.phase === 'plane' || hud.phase === 'skydiving') && (
        <>
          {hud.phase === 'skydiving' && (
            <div
              ref={joyPadRef}
              onPointerDown={handleJoyDown}
              onPointerMove={handleJoyMove}
              onPointerUp={handleJoyUp}
              onPointerCancel={handleJoyUp}
              className="fixed bottom-14 left-5 w-34 h-34 rounded-full bg-[#0b0e11]/55 border-2 border-white/30 flex items-center justify-center pointer-events-auto shadow-xl"
              style={{ touchAction: 'none' }}
              aria-label="التوجيه أثناء الهبوط"
            >
              <ChevronUp className="w-4 h-4 text-white/45 absolute top-2" />
              <ChevronDown className="w-4 h-4 text-white/45 absolute bottom-2" />
              <ChevronLeft className="w-4 h-4 text-white/45 absolute left-2" />
              <ChevronRight className="w-4 h-4 text-white/45 absolute right-2" />
              <div
                className="w-13 h-13 rounded-full bg-[#d4a84b]/95 border-2 border-white shadow-lg pointer-events-none"
                style={{ transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)` }}
              />
            </div>
          )}

          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              runTapAction('jump_plane', callbacks.onJumpOrParachute);
            }}
            onClick={(e) => {
              e.stopPropagation();
              runTapAction('jump_plane', callbacks.onJumpOrParachute);
            }}
            className="fixed bottom-16 right-6 pointer-events-auto bg-[#d4a84b] active:scale-95 text-[#0b0e11] font-black text-sm px-6 py-4 rounded-2xl border-2 border-white/70 shadow-2xl cursor-pointer"
          >
            {hud.phase === 'plane'
              ? 'اقفز الآن'
              : hud.isParachuteOpen
                ? 'توجيه الهبوط'
                : 'افتح المظلة'}
          </button>
        </>
      )}

      {/* Ground / Vehicle Combat Controls */}
      {hud.phase === 'playing' && (
        <>
          {/* Highlighted Context Action Button (Pickup / Crate / Enter or Exit Vehicle) */}
          {hud.promptText && (
            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                runTapAction('interact', callbacks.onInteract);
              }}
              onClick={(e) => {
                e.stopPropagation();
                runTapAction('interact', callbacks.onInteract);
              }}
              className="fixed bottom-52 left-1/2 -translate-x-1/2 pointer-events-auto flex items-center gap-2 bg-[#d4a84b] active:scale-95 text-[#0b0e11] font-black text-xs px-4 py-2.5 rounded-xl border-2 border-white/75 shadow-2xl cursor-pointer"
            >
              {hud.inVehicle ? (
                <Car className="w-4 h-4" />
              ) : (
                <PackageOpen className="w-4 h-4" />
              )}
              <span>{hud.promptText.replace('[F] ', '')}</span>
            </button>
          )}

          {hud.inVehicle ? (
            /* Vehicle Touch Steering & Pedals */
            <>
              <div className="fixed bottom-20 left-4 flex items-center gap-3 pointer-events-auto">
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    trySetPointerCapture(e.currentTarget, e.pointerId);
                    vehRef.current.steer = 1;
                    syncVehicle();
                  }}
                  onPointerUp={() => {
                    vehRef.current.steer = 0;
                    syncVehicle();
                  }}
                  onPointerCancel={() => {
                    vehRef.current.steer = 0;
                    syncVehicle();
                  }}
                  className="w-16 h-16 rounded-2xl bg-[#0b0e11]/80 active:bg-[#d4a84b] active:text-[#0b0e11] border-2 border-white/30 text-white flex items-center justify-center shadow-lg cursor-pointer"
                >
                  <ArrowLeft className="w-7 h-7" />
                </button>
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    trySetPointerCapture(e.currentTarget, e.pointerId);
                    vehRef.current.steer = -1;
                    syncVehicle();
                  }}
                  onPointerUp={() => {
                    vehRef.current.steer = 0;
                    syncVehicle();
                  }}
                  onPointerCancel={() => {
                    vehRef.current.steer = 0;
                    syncVehicle();
                  }}
                  className="w-16 h-16 rounded-2xl bg-[#0b0e11]/80 active:bg-[#d4a84b] active:text-[#0b0e11] border-2 border-white/30 text-white flex items-center justify-center shadow-lg cursor-pointer"
                >
                  <ArrowRight className="w-7 h-7" />
                </button>
              </div>

              <div className="fixed bottom-20 right-4 flex items-end gap-2.5 pointer-events-auto">
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    runTapAction('veh_exit', callbacks.onInteract);
                  }}
                  onClick={(e) => {
                    e.stopPropagation();
                    runTapAction('veh_exit', callbacks.onInteract);
                  }}
                  className="w-12 h-12 rounded-xl bg-red-900/85 border border-red-400/50 text-white text-[11px] font-black flex items-center justify-center cursor-pointer"
                >
                  نزول
                </button>
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    trySetPointerCapture(e.currentTarget, e.pointerId);
                    vehRef.current.throttle = -1;
                    vehRef.current.brake = true;
                    syncVehicle();
                  }}
                  onPointerUp={() => {
                    vehRef.current.throttle = 0;
                    vehRef.current.brake = false;
                    syncVehicle();
                  }}
                  onPointerCancel={() => {
                    vehRef.current.throttle = 0;
                    vehRef.current.brake = false;
                    syncVehicle();
                  }}
                  className="w-16 h-16 rounded-2xl bg-[#0b0e11]/85 active:bg-red-600 border-2 border-red-400/55 text-white font-black text-xs flex flex-col items-center justify-center cursor-pointer"
                >
                  <ArrowDown className="w-5 h-5" />
                  <span>فرامل</span>
                </button>
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    trySetPointerCapture(e.currentTarget, e.pointerId);
                    vehRef.current.throttle = 1;
                    syncVehicle();
                  }}
                  onPointerUp={() => {
                    vehRef.current.throttle = 0;
                    syncVehicle();
                  }}
                  onPointerCancel={() => {
                    vehRef.current.throttle = 0;
                    syncVehicle();
                  }}
                  className="w-18 h-24 rounded-2xl bg-emerald-600/90 active:bg-emerald-500 border-2 border-emerald-300/75 text-white font-black text-xs flex flex-col items-center justify-center shadow-xl cursor-pointer"
                >
                  <ArrowUp className="w-6 h-6" />
                  <span>سرعة</span>
                </button>
              </div>
            </>
          ) : (
            /* On-Foot Combat Touch Controls */
            <>
              {/* Left Cluster: Lean/FPP + Secondary Fire + Utility + Movement Joystick */}
              <div className="fixed bottom-20 left-3 flex flex-col items-start gap-2">
                {/* Quick Utility Row (Med, Grenade, PTT Mic) */}
                <div className="flex items-center gap-1.5 pointer-events-auto">
                  <button
                    type="button"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      runTapAction('quick_med', callbacks.onQuickMed);
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      runTapAction('quick_med', callbacks.onQuickMed);
                    }}
                    className="w-10 h-10 rounded-xl bg-[#0b0e11]/80 active:bg-emerald-600 border border-emerald-400/45 text-emerald-300 flex items-center justify-center cursor-pointer"
                    title="علاج سريع"
                  >
                    <HeartPulse className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      runTapAction('grenade', callbacks.onThrowGrenade);
                    }}
                    onDoubleClick={(e) => {
                      e.stopPropagation();
                      callbacks.onCycleThrowable();
                    }}
                    className="w-10 h-10 rounded-xl bg-[#0b0e11]/80 active:bg-amber-600 border border-amber-400/45 text-amber-300 flex flex-col items-center justify-center text-[10px] font-mono-num cursor-pointer"
                    title="رمي قنبلة"
                  >
                    <Flame className="w-3.5 h-3.5" />
                    <span>{hud.throwables[hud.activeThrowable]}</span>
                  </button>
                  <button
                    type="button"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      trySetPointerCapture(e.currentTarget, e.pointerId);
                      callbacks.onVoicePtt(true);
                    }}
                    onPointerUp={(e) => {
                      e.stopPropagation();
                      tryReleasePointerCapture(e.currentTarget, e.pointerId);
                      callbacks.onVoicePtt(false);
                    }}
                    onPointerCancel={() => callbacks.onVoicePtt(false)}
                    className={`w-10 h-10 rounded-xl border flex items-center justify-center cursor-pointer ${
                      hud.voice.isMicActive
                        ? 'bg-emerald-600 text-white border-emerald-300'
                        : 'bg-[#0b0e11]/80 text-white border-white/25'
                    }`}
                    title="اضغط للتحدث"
                  >
                    <Mic className="w-4 h-4" />
                  </button>
                </div>

                {/* Lean + Perspective Row */}
                <div className="flex items-center gap-1.5 pointer-events-auto">
                  <button
                    type="button"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      runTapAction('lean_l', () => callbacks.onToggleLean(-1));
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      runTapAction('lean_l', () => callbacks.onToggleLean(-1));
                    }}
                    className={`w-9 h-9 rounded-xl border text-xs font-black cursor-pointer ${
                      hud.lean === -1
                        ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                        : 'bg-[#0b0e11]/75 text-white border-white/25'
                    }`}
                  >
                    Q
                  </button>
                  <button
                    type="button"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      runTapAction('lean_r', () => callbacks.onToggleLean(1));
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      runTapAction('lean_r', () => callbacks.onToggleLean(1));
                    }}
                    className={`w-9 h-9 rounded-xl border text-xs font-black cursor-pointer ${
                      hud.lean === 1
                        ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                        : 'bg-[#0b0e11]/75 text-white border-white/25'
                    }`}
                  >
                    E
                  </button>
                  <button
                    type="button"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      runTapAction('persp', callbacks.onTogglePerspective);
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      runTapAction('persp', callbacks.onTogglePerspective);
                    }}
                    className="px-2.5 h-9 rounded-xl bg-[#0b0e11]/75 border border-white/25 text-white text-[11px] font-black flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-[#d4a84b]" />
                    <span>{hud.perspective.toUpperCase()}</span>
                  </button>
                </div>

                {/* Left Secondary Fire Button */}
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    trySetPointerCapture(e.currentTarget, e.pointerId);
                    leftFirePointerId.current = e.pointerId;
                    setIsFiringUi(true);
                    callbacks.onTouchFire(true);
                  }}
                  onPointerUp={(e) => {
                    e.stopPropagation();
                    tryReleasePointerCapture(e.currentTarget, e.pointerId);
                    leftFirePointerId.current = null;
                    if (firePointerId.current === null) {
                      setIsFiringUi(false);
                      callbacks.onTouchFire(false);
                    }
                  }}
                  onPointerCancel={() => {
                    leftFirePointerId.current = null;
                    if (firePointerId.current === null) {
                      setIsFiringUi(false);
                      callbacks.onTouchFire(false);
                    }
                  }}
                  className={`pointer-events-auto w-14 h-14 rounded-full border-2 text-white flex items-center justify-center shadow-lg cursor-pointer ${
                    isFiringUi
                      ? 'bg-red-500 border-white scale-95'
                      : 'bg-red-600/85 border-white/60'
                  }`}
                  style={{ touchAction: 'none' }}
                  aria-label="إطلاق نار"
                >
                  <Crosshair className="w-6 h-6" />
                </button>

                {/* Analog Movement Joystick (Move Pad) */}
                <div
                  ref={joyPadRef}
                  onPointerDown={handleJoyDown}
                  onPointerMove={handleJoyMove}
                  onPointerUp={handleJoyUp}
                  onPointerCancel={handleJoyUp}
                  className="pointer-events-auto relative w-34 h-34 rounded-full bg-[#0b0e11]/60 border-2 border-white/35 flex items-center justify-center shadow-2xl cursor-grab active:cursor-grabbing"
                  style={{ touchAction: 'none' }}
                  aria-label="عصا التحرك"
                >
                  {sprinting && (
                    <span className="absolute -top-5 text-[10px] font-black text-[#d4a84b] bg-[#0b0e11]/85 px-2 py-0.5 rounded">
                      ركض سريع
                    </span>
                  )}
                  <ChevronUp className="w-4 h-4 text-white/45 absolute top-1.5 pointer-events-none" />
                  <ChevronDown className="w-4 h-4 text-white/45 absolute bottom-1.5 pointer-events-none" />
                  <ChevronLeft className="w-4 h-4 text-white/45 absolute left-1.5 pointer-events-none" />
                  <ChevronRight className="w-4 h-4 text-white/45 absolute right-1.5 pointer-events-none" />
                  <div
                    className="w-13 h-13 rounded-full bg-[#f3f0e6]/90 border-2 border-[#d4a84b] shadow-lg flex items-center justify-center pointer-events-none"
                    style={{ transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)` }}
                  >
                    <span className="text-[9px] font-black text-[#0b0e11]">تحرك</span>
                  </div>
                </div>
              </div>

              {/* Right Tactical Cluster: Scope (ADS), Reload, Crouch/Prone, Jump, Main Aim-Fire Button */}
              <div className="fixed bottom-20 right-3 flex items-end gap-2.5">
                {/* Secondary Tactical Column */}
                <div className="flex flex-col items-center gap-2 pointer-events-auto">
                  {/* Prominent Scope / ADS Toggle Button */}
                  <button
                    type="button"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      runTapAction('scope_ads', callbacks.onToggleAds);
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      runTapAction('scope_ads', callbacks.onToggleAds);
                    }}
                    className={`w-15 h-15 rounded-full border-2 flex flex-col items-center justify-center shadow-xl cursor-pointer transition-transform active:scale-95 ${
                      hud.isAds
                        ? 'bg-[#d4a84b] text-[#0b0e11] border-white'
                        : 'bg-[#0b0e11]/85 text-white border-[#d4a84b]/60'
                    }`}
                    aria-label="تصويب المنظار"
                  >
                    <Target className="w-5 h-5" />
                    <span className="text-[9px] font-black leading-none mt-0.5">
                      منظار {scopeLabel}
                    </span>
                  </button>

                  <button
                    type="button"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      runTapAction('reload', callbacks.onReload);
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      runTapAction('reload', callbacks.onReload);
                    }}
                    className="w-12 h-12 rounded-full bg-[#0b0e11]/80 active:bg-[#d4a84b] active:text-[#0b0e11] border border-white/30 text-white flex items-center justify-center cursor-pointer"
                    aria-label="تعبئة"
                  >
                    <RotateCw className="w-5 h-5" />
                  </button>

                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        runTapAction('crouch', () => callbacks.onToggleStance('crouch'));
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        runTapAction('crouch', () => callbacks.onToggleStance('crouch'));
                      }}
                      className={`px-2.5 h-10 rounded-xl border text-[11px] font-black cursor-pointer ${
                        hud.stance === 'crouch'
                          ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                          : 'bg-[#0b0e11]/80 text-white border-white/25'
                      }`}
                    >
                      انحناء
                    </button>
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        runTapAction('prone', () => callbacks.onToggleStance('prone'));
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        runTapAction('prone', () => callbacks.onToggleStance('prone'));
                      }}
                      className={`px-2.5 h-10 rounded-xl border text-[11px] font-black cursor-pointer ${
                        hud.stance === 'prone'
                          ? 'bg-[#d4a84b] text-[#0b0e11] border-[#d4a84b]'
                          : 'bg-[#0b0e11]/80 text-white border-white/25'
                      }`}
                    >
                      انبطاح
                    </button>
                  </div>
                </div>

                {/* Jump + Main Drag-to-Aim Fire Button */}
                <div className="flex flex-col items-center gap-2.5 pointer-events-auto">
                  <button
                    type="button"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      runTapAction('jump', callbacks.onJumpOrParachute);
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      runTapAction('jump', callbacks.onJumpOrParachute);
                    }}
                    className="w-14 h-14 rounded-full bg-[#0b0e11]/80 active:bg-[#d4a84b] active:text-[#0b0e11] border-2 border-white/30 text-white text-xs font-black flex items-center justify-center shadow-lg cursor-pointer"
                  >
                    قفز
                  </button>

                  <button
                    type="button"
                    onPointerDown={handleFireDown}
                    onPointerMove={handleFireMove}
                    onPointerUp={handleFireUp}
                    onPointerCancel={handleFireUp}
                    className={`w-21 h-21 rounded-full border-3 text-white flex flex-col items-center justify-center shadow-2xl cursor-pointer transition-transform ${
                      isFiringUi
                        ? 'bg-red-500 border-white scale-95'
                        : 'bg-red-600/90 border-white/80'
                    }`}
                    style={{ touchAction: 'none' }}
                    aria-label="إطلاق نار وتصويب"
                  >
                    <Crosshair className="w-8 h-8" />
                    <span className="text-[11px] font-black mt-0.5">إطلاق</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}
