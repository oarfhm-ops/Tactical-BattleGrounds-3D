import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { GameHud } from './components/GameHud';
import { OfflineIndicator } from './components/PWAInstallButton';
import { TitleScreen } from './components/TitleScreen';
import type { TouchControlCallbacks } from './components/TouchControls';
import { BattleRoyaleEngine } from './game/engine';
import type {
  DiscoveredLocalRoom,
  GameMode,
  GameSettings,
  HudSnapshot,
  MapId,
  NetworkMode,
} from './game/types';

const DEFAULT_SETTINGS: GameSettings = {
  quality: 'hdr',
  style: 'colorful',
  targetFps: 60,
  audioQuality: 'ultra',
  muted: false,
  antiAliasing: true,
  mouseSensitivity: 1.0,
  controlScheme: 'auto',
};

const SETTINGS_KEY = 'br3d_settings_v1';
const PLAYER_NAME_KEY = 'br3d_player_name_v1';

function loadSavedSettings(): GameSettings {
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function loadSavedPlayerName(): string {
  try {
    const raw = window.localStorage.getItem(PLAYER_NAME_KEY);
    return raw && raw.trim() ? raw.trim().slice(0, 18) : 'مقاتل';
  } catch {
    return 'مقاتل';
  }
}

function getInitialRoomAndMode(): { networkMode: NetworkMode; roomCode: string } {
  try {
    const params = new URLSearchParams(window.location.search);
    const r = params.get('room');
    if (r && r.trim()) {
      return {
        networkMode: 'local',
        roomCode: r.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 12) || 'ROOM1',
      };
    }
  } catch {
    // ignore URL read failure
  }
  const suffix = Math.floor(100 + Math.random() * 900);
  return {
    networkMode: 'online',
    roomCode: `BR${suffix}`,
  };
}

function detectTouchHardware(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(pointer: coarse)').matches ||
    'ontouchstart' in window ||
    navigator.maxTouchPoints > 0
  );
}

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<BattleRoyaleEngine | null>(null);
  const initialNet = useRef(getInitialRoomAndMode());

  const [selectedMap, setSelectedMap] = useState<MapId>('classic');
  const [selectedMode, setSelectedMode] = useState<GameMode>('solo');
  const [networkMode, setNetworkMode] = useState<NetworkMode>(initialNet.current.networkMode);
  const [roomCode, setRoomCode] = useState<string>(initialNet.current.roomCode);
  const [hostingLocalRoom, setHostingLocalRoom] = useState<boolean>(false);
  const [localRooms, setLocalRooms] = useState<DiscoveredLocalRoom[]>([]);
  const [searchingRooms, setSearchingRooms] = useState<boolean>(false);
  const [playerName, setPlayerName] = useState<string>(loadSavedPlayerName);
  const [fillWithBots, setFillWithBots] = useState<boolean>(true);
  const [settings, setSettings] = useState<GameSettings>(loadSavedSettings);
  const [hud, setHud] = useState<HudSnapshot | null>(null);
  const [showInventory, setShowInventory] = useState(false);
  const [showFullMap, setShowFullMap] = useState(false);
  const [hasTouchHw, setHasTouchHw] = useState<boolean>(detectTouchHardware);

  useEffect(() => {
    const mq = window.matchMedia('(pointer: coarse)');
    const updateTouch = () => setHasTouchHw(detectTouchHardware());
    mq.addEventListener?.('change', updateTouch);
    window.addEventListener('resize', updateTouch);
    return () => {
      mq.removeEventListener?.('change', updateTouch);
      window.removeEventListener('resize', updateTouch);
    };
  }, []);

  const isTouchMode = useMemo(() => {
    const scheme = settings.controlScheme ?? 'auto';
    if (scheme === 'touch') return true;
    if (scheme === 'pc') return false;
    return hasTouchHw;
  }, [settings.controlScheme, hasTouchHw]);

  // Initialize isolated 3D WebGL engine once
  useEffect(() => {
    if (!mountRef.current) return;
    const initSettings = loadSavedSettings();
    const engine = new BattleRoyaleEngine(mountRef.current, initSettings, (snap) => {
      setHud(snap);
    });
    engine.voice.onLocalRoomsChanged = (rooms) => {
      setLocalRooms(rooms);
    };
    engineRef.current = engine;
    engine.updateSettings(initSettings);
    engine.setTouchModeEnabled(detectTouchHardware() || initSettings.controlScheme === 'touch');
    engine.setLobbyNetworkConfig(
      initialNet.current.networkMode,
      initialNet.current.roomCode,
      loadSavedPlayerName(),
      true,
      false,
    );

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    engineRef.current?.setTouchModeEnabled(isTouchMode);
  }, [isTouchMode]);

  const handleRefreshLocalRooms = useCallback(async (query = '') => {
    setSearchingRooms(true);
    engineRef.current?.voice.requestLocalRooms(query);
    try {
      const qParam = query.trim() ? `?q=${encodeURIComponent(query.trim())}` : '';
      const res = await fetch(`/api/local-rooms${qParam}`);
      if (res.ok) {
        const data = (await res.json()) as { rooms?: DiscoveredLocalRoom[] };
        if (Array.isArray(data.rooms)) {
          setLocalRooms(data.rooms);
        }
      }
    } catch {
      // ignore when offline
    } finally {
      setSearchingRooms(false);
    }
  }, []);

  // Keep engine settings synchronized whenever settings change
  useEffect(() => {
    try {
      window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      // ignore storage quota errors
    }
    engineRef.current?.updateSettings(settings);
  }, [settings]);

  // Keep lobby room & player identity synchronized while in menu
  useEffect(() => {
    try {
      window.localStorage.setItem(PLAYER_NAME_KEY, playerName);
    } catch {
      // ignore
    }
    if (!hud || hud.phase === 'menu') {
      engineRef.current?.setLobbyNetworkConfig(
        networkMode,
        roomCode,
        playerName,
        fillWithBots,
        hostingLocalRoom,
      );
    }
  }, [networkMode, roomCode, playerName, fillWithBots, hostingLocalRoom, hud?.phase]);

  // Fetch live open local rooms whenever entering Local tab
  useEffect(() => {
    if (networkMode === 'local' && (!hud || hud.phase === 'menu')) {
      void handleRefreshLocalRooms('');
    }
  }, [networkMode, hud?.phase, handleRefreshLocalRooms]);

  const handleSelectMap = useCallback((map: MapId) => {
    setSelectedMap(map);
    engineRef.current?.loadMapPreview(map);
  }, []);

  const handleUpdateSettings = useCallback((next: GameSettings) => {
    setSettings(next);
    engineRef.current?.updateSettings(next);
  }, []);

  const handleSelectNetworkMode = useCallback((mode: NetworkMode) => {
    setNetworkMode(mode);
    if (mode !== 'local') {
      setHostingLocalRoom(false);
    }
  }, []);

  const handleStart = useCallback(() => {
    setShowInventory(false);
    setShowFullMap(false);
    engineRef.current?.startMatch(selectedMap, selectedMode, {
      networkMode,
      roomCode,
      playerName,
      fillWithBots,
      hostingRoom: networkMode === 'local' ? hostingLocalRoom : false,
    });
  }, [selectedMap, selectedMode, networkMode, roomCode, playerName, fillWithBots, hostingLocalRoom]);

  const handleJoinLocalRoom = useCallback(
    (room: DiscoveredLocalRoom) => {
      setShowInventory(false);
      setShowFullMap(false);
      setNetworkMode('local');
      setRoomCode(room.roomCode);
      setSelectedMap(room.mapId);
      setSelectedMode(room.mode);
      setHostingLocalRoom(false);
      engineRef.current?.startMatch(room.mapId, room.mode, {
        networkMode: 'local',
        roomCode: room.roomCode,
        playerName,
        fillWithBots,
        hostingRoom: false,
      });
    },
    [playerName, fillWithBots],
  );

  const handleExitToMenu = useCallback(() => {
    setShowInventory(false);
    setShowFullMap(false);
    engineRef.current?.loadMapPreview(selectedMap);
    engineRef.current?.setLobbyNetworkConfig(
      networkMode,
      roomCode,
      playerName,
      fillWithBots,
      hostingLocalRoom,
    );
  }, [selectedMap, networkMode, roomCode, playerName, fillWithBots, hostingLocalRoom]);

  // Global keyboard shortcuts for Tab (Inventory), M (Full Map), Esc (Pause), Enter (Start on Menu)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isTyping =
        target?.tagName === 'INPUT' ||
        target?.tagName === 'TEXTAREA' ||
        target?.isContentEditable;
      if (isTyping) return;

      const phase = hud?.phase ?? 'menu';
      if (phase === 'menu' && (e.code === 'Enter' || e.code === 'Space')) {
        e.preventDefault();
        handleStart();
        return;
      }
      if (e.code === 'Tab' && phase === 'playing') {
        e.preventDefault();
        setShowInventory((prev) => {
          const next = !prev;
          if (next) {
            setShowFullMap(false);
            engineRef.current?.releasePointerLock();
          } else if (!isTouchMode) {
            engineRef.current?.requestPointerLock();
          }
          return next;
        });
      } else if (e.code === 'KeyM' && (phase === 'playing' || phase === 'skydiving' || phase === 'plane')) {
        e.preventDefault();
        setShowFullMap((prev) => {
          const next = !prev;
          if (next) {
            setShowInventory(false);
            engineRef.current?.releasePointerLock();
          } else if (!isTouchMode) {
            engineRef.current?.requestPointerLock();
          }
          return next;
        });
      } else if (e.code === 'Escape') {
        if (showInventory || showFullMap) {
          setShowInventory(false);
          setShowFullMap(false);
          if (!isTouchMode) engineRef.current?.requestPointerLock();
        } else if (phase === 'playing' || phase === 'skydiving' || phase === 'plane') {
          engineRef.current?.setPaused(true);
        } else if (phase === 'paused') {
          engineRef.current?.setPaused(false);
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [hud?.phase, handleStart, showInventory, showFullMap, isTouchMode]);

  const touchCallbacks = useMemo<TouchControlCallbacks>(
    () => ({
      onTouchMove: (x, y, sprint) => engineRef.current?.setTouchMove(x, y, sprint),
      onTouchLook: (dx, dy) => engineRef.current?.addTouchLook(dx, dy),
      onTouchFire: (firing) => engineRef.current?.setTouchFire(firing),
      onTouchVehicleInput: (t, s, b) => engineRef.current?.setTouchVehicleInput(t, s, b),
      onToggleAds: () => engineRef.current?.toggleAds(),
      onTogglePerspective: () => engineRef.current?.togglePerspective(),
      onToggleLean: (dir) => engineRef.current?.toggleLean(dir),
      onToggleStance: (target) => engineRef.current?.toggleStance(target),
      onJumpOrParachute: () => engineRef.current?.triggerJumpOrParachute(),
      onInteract: () => engineRef.current?.triggerInteract(),
      onReload: () => engineRef.current?.triggerReload(),
      onThrowGrenade: () => engineRef.current?.throwActiveGrenade(),
      onCycleThrowable: () => engineRef.current?.cycleThrowable(),
      onQuickMed: () => engineRef.current?.triggerQuickMed(),
      onVoicePtt: (held) => engineRef.current?.setVoicePtt(held),
    }),
    [],
  );

  const phase = hud?.phase ?? 'menu';

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#0b0e11] touch-none select-none">
      {/* Isolated WebGL Mount Container */}
      <div ref={mountRef} className="fixed inset-0 w-full h-full" />

      <OfflineIndicator />

      {phase === 'menu' && (
        <TitleScreen
          selectedMap={selectedMap}
          selectedMode={selectedMode}
          networkMode={networkMode}
          roomCode={roomCode}
          hostingLocalRoom={hostingLocalRoom}
          localRooms={localRooms}
          searchingRooms={searchingRooms}
          playerName={playerName}
          fillWithBots={fillWithBots}
          multiplayer={
            hud?.multiplayer ?? {
              connected: false,
              networkMode,
              roomCode,
              roomPeers: [],
            }
          }
          settings={settings}
          isTouchMode={isTouchMode}
          liveFps={hud?.liveFps ?? settings.targetFps}
          renderResolution={hud?.renderResolution ?? { width: 1920, height: 1080, is4k: false }}
          onSelectMap={handleSelectMap}
          onSelectMode={setSelectedMode}
          onSelectNetworkMode={handleSelectNetworkMode}
          onChangeRoomCode={setRoomCode}
          onToggleHostLocalRoom={setHostingLocalRoom}
          onRefreshLocalRooms={handleRefreshLocalRooms}
          onJoinLocalRoom={handleJoinLocalRoom}
          onChangePlayerName={setPlayerName}
          onToggleFillWithBots={setFillWithBots}
          onUpdateSettings={handleUpdateSettings}
          onStart={handleStart}
        />
      )}

      {hud && phase !== 'menu' && (
        <GameHud
          hud={hud}
          settings={settings}
          isTouchMode={isTouchMode}
          showInventory={showInventory}
          showFullMap={showFullMap}
          touchCallbacks={touchCallbacks}
          onToggleInventory={() => {
            setShowInventory((v) => {
              const next = !v;
              if (next) engineRef.current?.releasePointerLock();
              else if (!isTouchMode) engineRef.current?.requestPointerLock();
              return next;
            });
          }}
          onToggleFullMap={() => {
            setShowFullMap((v) => {
              const next = !v;
              if (next) engineRef.current?.releasePointerLock();
              else if (!isTouchMode) engineRef.current?.requestPointerLock();
              return next;
            });
          }}
          onPauseToggle={() => engineRef.current?.setPaused(phase !== 'paused')}
          onUpdateSettings={handleUpdateSettings}
          onJumpFromPlane={() => engineRef.current?.jumpFromPlane()}
          onSelectWeaponSlot={(slot) => engineRef.current?.selectWeaponSlot(slot)}
          onUseMed={(t) => engineRef.current?.startUseMed(t)}
          onAttachScope={(s) => engineRef.current?.attachSpareScope(s)}
          onAttachMuzzle={(m) => engineRef.current?.attachSpareMuzzle(m)}
          onAttachExtMag={() => engineRef.current?.attachSpareExtMag()}
          onRestart={handleStart}
          onExitToMenu={handleExitToMenu}
          onEnableMic={() => void engineRef.current?.voice.enableMic()}
          onCycleVoiceChannel={() => engineRef.current?.voice.cycleChannel()}
          onToggleMicMode={() => {
            const v = engineRef.current?.voice;
            if (!v) return;
            v.setMicMode(v.micMode === 'ptt' ? 'open' : 'ptt');
          }}
          onToggleVoiceTest={() => engineRef.current?.voice.toggleTestLoopback()}
        />
      )}
    </div>
  );
}
